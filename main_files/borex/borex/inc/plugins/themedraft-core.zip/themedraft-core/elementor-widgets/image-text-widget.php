<?php
namespace Elementor;

class ThemeDraft_Image_Icon_And_Text_Widget extends Widget_Base {

	public function get_name() {

		return 'themedraft_image_icon_and_text';
	}

	public function get_title() {
		return esc_html__( 'Image Icon & Text', 'themedraft-core' );
	}

	public function get_icon() {

		return 'eicon-image-box';
	}

	public function get_categories() {
		return [ 'themedraft_elements' ];
	}


	protected function register_controls() {

		//Content tab start
		$this->start_controls_section(
			'image_icon_text_settings',
			[
				'label' => esc_html__( 'Image Icon & Text', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
		    'main_image',
		    [
		        'label'       => __( 'Image', 'themedraft-core' ),
		        'type'        => Controls_Manager::MEDIA,
		        'label_block' => true,
		        'default'     => [
		            'url' => Utils::get_placeholder_image_src(),
		        ],
		    ]
		);

		$this->add_control(
			'type',
			[
				'label'       => __( 'Icon Type', 'themedraft-core' ),
				'type'        => Controls_Manager::CHOOSE,
				'label_block' => false,
				'options'     => [
					'icon'  => [
						'title' => __( 'Icon', 'themedraft-core' ),
						'icon'  => 'fa fa-smile-o',
					],
					'image' => [
						'title' => __( 'Image', 'themedraft-core' ),
						'icon'  => 'fa fa-image',
					],
				],
				'default'     => 'icon',
				'toggle'      => false,
			]
		);

		$this->add_control(
			'selected_icon',
			[
				'label'       => __( 'Select Icon', 'themedraft-core' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'label_block'      => true,
				'default'          => [
					'value'   => 'flaticon-business-success-1',
					'library' => 'themedraft-flaticon',
				],
				'condition'        => [
					'type' => 'icon'
				]
			]
		);

		$this->add_control(
			'image',
			[
				'label'     => __( 'Image', 'themedraft-core' ),
				'type'      => Controls_Manager::MEDIA,
				'default'   => [
					'url' => Utils::get_placeholder_image_src(),
				],
				'condition' => [
					'type' => 'image'
				],
				'dynamic'   => [
					'active' => true,
				]
			]
		);

		$this->add_control(
		    'text',
		    [
		        'label'       => __( 'Text', 'themedraft-core' ),
		        'type'        => Controls_Manager::TEXTAREA,
		        'rows'        => 5,
		        'default'     => __( '<strong>25</strong> years of experience', 'themedraft-core' ),
		        'description' => esc_html__( 'Use <strong> for bold text.', 'themedraft-core' ),
		    ]
		);


		$this->add_control(
			'box_animation',
			[
				'label' => __( 'Entrance Animation', 'themedraft-core' ),
				'type' => Controls_Manager::ANIMATION,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'box_animation_duration',
			[
				'label'     => __( 'Animation Duration', 'themedraft-core' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'data-wow-duration="1.25s"',
				'options'   => [
					'data-wow-duration="2s"'    => __( 'Slow', 'themedraft-core' ),
					'data-wow-duration="1.25s"' => __( 'Normal', 'themedraft-core' ),
					'data-wow-duration=".75s"'  => __( 'Fast', 'themedraft-core' ),
				],
				'condition' => [
					'box_animation!' => '',
				]
			]
		);

		$this->add_control(
			'box_animation_delay',
			[
				'label'       => esc_html__('Animation Delay (ms)', 'themedraft-core'),
				'type'        => Controls_Manager::NUMBER,
				'min'         => 0,
				'max'         => 100000,
				'step'        => 1,
				'default'        => 0,
				'condition' => [
					'box_animation!' => '',
				]
			]
		);

		$this->add_responsive_control(
		    'image_align',
		    [
		        'label'       => esc_html__('Image Align', 'themedraft-core'),
		        'description' => esc_html__('', 'themedraft-core'),
		        'type'        => Controls_Manager::CHOOSE,
		        'label_block' => false,

		        'options' => [
		            'left' => [
		                'title' => __('Left', 'themedraft-core'),
		                'icon'  => 'fa fa-align-left',
		            ],

		            'center' => [
		                'title' => __('Center', 'themedraft-core'),
		                'icon'  => 'fa fa-align-center',
		            ],

		            'right' => [
		                'title' => __('Right', 'themedraft-core'),
		                'icon'  => 'fa fa-align-right',
		            ],
		        ],

		        'devices' => ['desktop', 'tablet', 'mobile'],

		        'selectors' => [
		            '{{WRAPPER}} .td-image-icon-text-wrapper' => 'text-align: {{VALUE}};',
		        ],

		    ]
		);

		$this->end_controls_section();

		$this->start_controls_section(
		    'colors_settings',
		    [
		        'label' => esc_html__( 'Colors', 'themedraft-core' ),
		        'tab'   => Controls_Manager::TAB_STYLE,
		    ]
		);

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'background',
                'label' => esc_html__( 'Background', 'themedraft-core' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .td-image-icon-text:before',
                'exclude' => [
                        'image'
                ]
            ]
        );

        $this->add_control(
            'text_color',
            [
                'label'       => esc_html__('Text Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .td-image-icon-text .td-left-icon,{{WRAPPER}} .td-image-icon-text .td-right-text,{{WRAPPER}} .td-image-icon-text .td-right-text strong' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .td-image-icon-text .td-left-icon svg' => 'fill: {{VALUE}};',
                ],
            ]
        );

		$this->end_controls_section();

	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();
		if($settings['box_animation']){
			$box_animation = 'wow'.' ' . $settings['box_animation'];
			$box_animation_duration = $settings['box_animation_duration'];
			$box_animation_delay = ' data-wow-delay="'.$settings['box_animation_delay'].'ms"';
		}else{
			$box_animation ='';
			$box_animation_duration ='';
			$box_animation_delay ='';
		}
		?>
		
		<div class="td-image-icon-text-wrapper <?php echo $box_animation;?>" <?php echo $box_animation_duration . $box_animation_delay;?>>
            <div class="td-image-icon-text">
                <div class="td-image">
                    <img src="<?php echo esc_url($settings['main_image']['url']);?>" alt="<?php echo get_post_meta( $settings['main_image']['id'], '_wp_attachment_image_alt', true ); ?>">
                </div>

                <div class="td-icon-and-text-wrapper">
                    <div class="td-icon-and-text">
                        <div class="td-left-icon">
                            <?php if ( $settings['type'] === 'image' ) :
                                if ( $settings['image']['url'] || $settings['image']['id'] ) :
                                    ?>
                                    <div class="td-icon-wrapper td-image-icon">
                                        <img src="<?php echo $settings['image']['url']; ?>"
                                             alt="<?php echo get_post_meta( $settings['image']['id'], '_wp_attachment_image_alt', true ); ?>">
                                    </div>
                                <?php endif;
                            elseif ( ! empty( $settings['icon'] ) || ! empty( $settings['selected_icon'] ) ) : ?>
                                <div class="td-icon-wrapper td-font-icon">
                                    <?php themedraft_custom_icon_render( $settings, 'icon', 'selected_icon' ); ?>
                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="td-right-text">
                            <?php echo nl2br($settings['text']);?>
                        </div>
                    </div>
                </div>
            </div>
		</div>

		<?php

	}
}

Plugin::instance()->widgets_manager->register( new ThemeDraft_Image_Icon_And_Text_Widget );