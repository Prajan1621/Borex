<?php

namespace Elementor;

class ThemeDraft_Button_Widget extends Widget_Base {

	public function get_name() {

		return "themedraft_button";
	}

	public function get_title() {
		return __( "Button", "themedraft-core" );
	}

	public function get_icon() {

		return "eicon-button";
	}

	public function get_categories() {
		return [ 'themedraft_elements' ];
	}


	protected function register_controls() {
		//Content tab start
		$this->start_controls_section(
			'button_1_content',
			[
				'label' => __( 'Button One', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'button_1_text',
			[
				'label'   => esc_html__( 'Button Text', 'themedraft-core' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( 'Button Text', 'themedraft-core' ),
                'label_block' => true,
			]
		);

		$this->add_control(
			'btn_1_url',
			[
				'label'         => __( 'Button URL', 'themedraft-core' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => __( 'https://your-link.com', 'themedraft-core' ),
				'show_external' => true,
				'default'       => [
					'url'         => '#',
					'is_external' => false,
					'nofollow'    => false,
				],
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'button_2_content',
			[
				'label' => __( 'Button Two', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'button_2_text',
			[
				'label'   => esc_html__( 'Button Text', 'themedraft-core' ),
				'type'    => Controls_Manager::TEXT,
				'label_block' => true,
			]
		);

		$this->add_control(
			'btn_2_url',
			[
				'label'         => __( 'Button URL', 'themedraft-core' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => __( 'https://your-link.com', 'themedraft-core' ),
				'show_external' => true,
				'default'       => [
					'url'         => '',
					'is_external' => false,
					'nofollow'    => false,
				],
			]
		);

		$this->end_controls_section();

		// Button Style
		$this->start_controls_section(
		    'btn_1_style',
		    [
		        'label' => esc_html__( 'Button One', 'themedraft-core' ),
		        'tab'   => Controls_Manager::TAB_STYLE,
		    ]
		);

		$this->add_group_control(
		    Group_Control_Typography::get_type(),
		    [
		        'name' => 'btn_1_typography',
		        'label' => __( 'Typography', 'themedraft-core' ),
		        'selector' => '{{WRAPPER}} .td-button.td-el-btn-one, {{WRAPPER}} .td-button.td-el-btn-one i',
		    ]
		);

		$this->start_controls_tabs('td-button_1_style_tabs');

		//Default style start
		$this->start_controls_tab(
		    'td_btn_1_normal',
		    [
		        'label' => esc_html__('Normal', 'themedraft-core'),
		    ]
		);

		$this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
		        'name' => 'button_one_normal_background',
		        'label' => esc_html__( 'Background', 'themedraft-core' ),
		        'types' => [ 'classic', 'gradient'],
		        'selector' => '{{WRAPPER}} .td-button.td-el-btn-one',
                'exclude' => [
                        'image'
                ]
		    ]
		);

		$this->add_control(
		    'button_one_normal_text_color',
		    [
		        'label'       => esc_html__('Text Color', 'themedraft-core'),
		        'type'        => Controls_Manager::COLOR,
		        'selectors'   => [
		            '{{WRAPPER}} .td-button.td-el-btn-one' => 'color: {{VALUE}};',
		        ],

                'separator' => 'before',
		    ]
		);


		$this->end_controls_tab();//Default style tab end

		//Hover style tab start
		$this->start_controls_tab(
		    'td_btn_1_style_hover',
		    [
		        'label' => esc_html__('Hover', 'themedraft-core'),
		    ]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'button_one_hover_background',
				'label' => esc_html__( 'Background', 'themedraft-core' ),
				'types' => [ 'classic', 'gradient'],
				'selector' => '{{WRAPPER}} .td-button.td-el-btn-one:hover',
				'exclude' => [
					'image'
				]
			]
		);

		$this->add_control(
			'button_one_hover_text_color',
			[
				'label'       => esc_html__('Text Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-button.td-el-btn-one:hover' => 'color: {{VALUE}};',
				],

				'separator' => 'before',
			]
		);

		$this->add_control(
		    'btn_one_border_color',
		    [
		        'label'       => esc_html__('Border Color', 'themedraft-core'),
		        'type'        => Controls_Manager::COLOR,
		        'selectors'   => [
		            '{{WRAPPER}} .td-button.td-el-btn-one:before' => 'border-color: {{VALUE}};',
		        ],
		        'separator' => 'before',
		    ]
		);


		$this->end_controls_tabs();//Hover style tab end

		$this->end_controls_section();

		// Button 2 Style
		$this->start_controls_section(
			'btn_2_style',
			[
				'label' => esc_html__( 'Button Two', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
					'button_2_text!' => '',
				]
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'btn_2_typography',
				'label' => __( 'Typography', 'themedraft-core' ),
				'selector' => '{{WRAPPER}} .td-button.td-el-btn-two,{{WRAPPER}} .td-button.td-el-btn-two i',
			]
		);

		$this->start_controls_tabs('td-button_2_style_tabs');

		//Default style start
		$this->start_controls_tab(
			'td_btn_2_normal',
			[
				'label' => esc_html__('Normal', 'themedraft-core'),
			]
		);


		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'button_two_normal_background',
				'label' => esc_html__( 'Background', 'themedraft-core' ),
				'types' => [ 'classic', 'gradient'],
				'selector' => '{{WRAPPER}} .td-button.td-el-btn-two',
			]
		);

		$this->add_control(
			'button_two_normal_text_color',
			[
				'label'       => esc_html__('Text Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-button.td-el-btn-two' => 'color: {{VALUE}};',
				],

				'separator' => 'before',
			]
		);


		$this->end_controls_tab();//Default style tab end

		//Hover style tab start
		$this->start_controls_tab(
			'td_btn_2_style_hover',
			[
				'label' => esc_html__('Hover', 'themedraft-core'),
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'button_two_hover_background',
				'label' => esc_html__( 'Background', 'themedraft-core' ),
				'types' => [ 'classic', 'gradient'],
				'selector' => '{{WRAPPER}} .td-button.td-el-btn-two:hover',
				'exclude' => [
					'image'
				]
			]
		);

		$this->add_control(
			'button_two_hover_text_color',
			[
				'label'       => esc_html__('Text Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-button.td-el-btn-two:hover' => 'color: {{VALUE}};',
				],

				'separator' => 'before',
			]
		);

		$this->add_control(
			'btn_two_border_color',
			[
				'label'       => esc_html__('Border Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-button.td-el-btn-two:before' => 'border-color: {{VALUE}};',
				],
				'separator' => 'before',
			]
		);

		$this->end_controls_tabs();//Hover style tab end

		$this->end_controls_section();

		$this->start_controls_section(
		    'btn_other_style',
		    [
		        'label' => esc_html__( 'Others', 'themedraft-core' ),
		        'tab'   => Controls_Manager::TAB_STYLE,
		    ]
		);

		$this->add_responsive_control(
		    'button_align',
		    [
		        'label'       => esc_html__('Button Align', 'themedraft-core'),
		        'type'        => Controls_Manager::CHOOSE,
		        'label_block' => false,
		        'options' => [
		            'left' => [
		                'title' => __('Left', 'themedraft-core'),
		                'icon'  => 'fa fa-align-left',
		            ],

		            'center' => [
		                'title' => __('Center', 'themedraft-core'),
		                'icon'  => 'fa fa-align-center',
		            ],

		            'right' => [
		                'title' => __('Right', 'themedraft-core'),
		                'icon'  => 'fa fa-align-right',
		            ],
		        ],

		        'default' => 'left',
		        'devices' => ['desktop', 'tablet', 'mobile'],

		        'selectors' => [
		            '{{WRAPPER}} .td-button-el-widget' => 'text-align: {{VALUE}};',
		        ],
		    ]
		);

		$this->add_responsive_control(
			'button_margin',
			[
				'label'      => esc_html__( 'Margin', 'themedraft-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .td-button-el-widget' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
		    'button_padding',
		    [
		        'label'      => esc_html__( 'Padding', 'themedraft-core' ),
		        'type'       => Controls_Manager::DIMENSIONS,
		        'size_units' => [ 'px', '%', 'em' ],
		        'selectors'  => [
		            '{{WRAPPER}} .td-button.td-el-btn-one,{{WRAPPER}} .td-button.td-el-btn-two' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
		        ],
		    ]
		);

		$this->add_control(
			'button_border_radius',
			[
				'label' => __( 'Border Radius', 'themedraft-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .td-button.td-el-btn-one,{{WRAPPER}} .td-button.td-el-btn-two' => 'border-radius: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'button_animation',
			[
				'label' => __( 'Entrance Animation', 'themedraft-core' ),
				'type' => Controls_Manager::ANIMATION,
				'prefix_class' => 'animated ',
			]
		);

		$this->add_control(
			'button_animation_duration',
			[
				'label'     => __( 'Animation Duration', 'themedraft-core' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'data-wow-duration="1.25s"',
				'options'   => [
					'data-wow-duration="2s"'    => __( 'Slow', 'themedraft-core' ),
					'data-wow-duration="1.25s"' => __( 'Normal', 'themedraft-core' ),
					'data-wow-duration=".75s"'  => __( 'Fast', 'themedraft-core' ),
				],
				'condition' => [
					'button_animation!' => '',
				]
			]
		);

		$this->add_control(
			'button_animation_delay',
			[
				'label'       => esc_html__('Animation Delay (ms)', 'themedraft-core'),
				'type'        => Controls_Manager::NUMBER,
				'min'         => 0,
				'max'         => 100000,
				'step'        => 1,
				'default'        => 0,
				'condition' => [
					'button_animation!' => '',
				]
			]
		);

		$this->end_controls_section();
	}


	//Render In HTML
	protected function render() {
		$settings         = $this->get_settings_for_display();
		$btn_one_target   = $settings['btn_1_url']['is_external'] ? ' target="_blank"' : '';
		$btn_one_nofollow = $settings['btn_1_url']['nofollow'] ? ' rel="nofollow"' : '';

		$btn_two_target   = $settings['btn_2_url']['is_external'] ? ' target="_blank"' : '';
		$btn_two_nofollow = $settings['btn_2_url']['nofollow'] ? ' rel="nofollow"' : '';

		if($settings['button_animation']){
			$td_animation = 'wow'.' ' . $settings['button_animation'];
			$td_animation_duration = $settings['button_animation_duration'];
			$td_animation_delay = ' data-wow-delay="'.$settings['button_animation_delay'].'ms"';
		}else{
			$td_animation ='';
			$td_animation_duration ='';
			$td_animation_delay ='';
		}

		?>
        <div class="td-button-el-widget <?php echo $td_animation;?>" <?php echo $td_animation_duration . $td_animation_delay;?>>

            <a href="<?php echo esc_url( $settings['btn_1_url']['url'] ); ?>"
               class="td-button td-el-btn-one" <?php echo $btn_one_target . $btn_one_nofollow; ?>><?php echo esc_html( $settings['button_1_text']);?>
                <i class="fas fa-long-arrow-alt-right"></i>
            </a>

			<?php if ( $settings['button_2_text'] ) : ?>
                <a href="<?php echo esc_url( $settings['btn_2_url']['url'] ); ?>"
                   class="td-button td-el-btn-two" <?php echo $btn_two_target . $btn_two_nofollow; ?>><?php echo esc_html( $settings['button_2_text'] ); ?>
                    <i class="fas fa-long-arrow-alt-right"></i>
                </a>
			<?php endif; ?>
        </div>

		<?php
	}
}

Plugin::instance()->widgets_manager->register( new ThemeDraft_Button_Widget );