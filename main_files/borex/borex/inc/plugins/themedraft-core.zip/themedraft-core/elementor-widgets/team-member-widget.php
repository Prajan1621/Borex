<?php
namespace Elementor;


class ThemeDraft_Team_Member_Widget extends Widget_Base {

	public function get_name() {

		return 'themedraft_team_member';
	}

	public function get_title() {
		return esc_html__( 'Team Member', 'themedraft-core' );
	}

	public function get_icon() {

		return 'flaticon-business-professions-and-jobs';
	}

	public function get_categories() {
		return [ 'themedraft_elements' ];
	}


	protected function register_controls() {

		//Content tab start
		$this->start_controls_section(
			'team_member_settings',
			[
				'label' => esc_html__( 'Members', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'team_style',
			[
				'label'   => __( 'Team Style', 'themedraft-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'style-1',
				'options' => [
					'style-1' => __( 'Style One', 'themedraft-core' ),
					'style-2'  => __( 'Style Two', 'themedraft-core' ),
				],
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'name',
			[
				'label'       => __('Name', 'themedraft-core'),
				'type'        => Controls_Manager::TEXT,
				'default'     => __('Nadim Khan', 'themedraft-core'),
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'designation',
			[
				'label'       => __('Designation', 'themedraft-core'),
				'type'        => Controls_Manager::TEXT,
				'default'     => __('Web Developer', 'themedraft-core'),
				'label_block' => true,
			]
		);


		$repeater->add_control(
			'image',
			[
				'label'       => __( 'Image', 'themedraft-core' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
				'default'     => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);

		$repeater->add_control(
			'details',
			[
				'label'         => __( 'Details URL', 'themedraft-core' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => __( 'https://your-link.com', 'themedraft-core' ),
				'show_external' => true,
				'default'       => [
					'url'         => '',
					'is_external' => false,
					'nofollow'    => false,
				],
			]
		);

		$repeater->add_control(
			'box_animation',
			[
				'label' => __( 'Entrance Animation', 'themedraft-core' ),
				'type' => Controls_Manager::ANIMATION,
				'separator' => 'before',
			]
		);

		$repeater->add_control(
			'box_animation_duration',
			[
				'label'     => __( 'Animation Duration', 'themedraft-core' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'data-wow-duration="1.25s"',
				'options'   => [
					'data-wow-duration="2s"'    => __( 'Slow', 'themedraft-core' ),
					'data-wow-duration="1.25s"' => __( 'Normal', 'themedraft-core' ),
					'data-wow-duration=".75s"'  => __( 'Fast', 'themedraft-core' ),
				],
				'condition' => [
					'box_animation!' => '',
				]
			]
		);

		$repeater->add_control(
			'box_animation_delay',
			[
				'label'       => esc_html__('Animation Delay (ms)', 'themedraft-core'),
				'type'        => Controls_Manager::NUMBER,
				'min'         => 0,
				'max'         => 100000,
				'step'        => 1,
				'default'        => 0,
				'condition' => [
					'box_animation!' => '',
				]
			]
		);



		$this->add_control(
			'members',
			[
				'label'       => __('Members List', 'themedraft-core'),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'name'        => __('Nadim Khan', 'themedraft-core'),
						'designation'        => __('Web Developer', 'themedraft-core'),
					],
				],
				'title_field' => '{{{ name }}}',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'team_column_settings',
			[
				'label' => esc_html__( 'Column', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'desktop_col',
			[
				'label'   => __( 'Column On Desktop', 'themedraft-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'col-lg-3',
				'options' => [
					'col-lg-12' => __( '1 Column', 'themedraft-core' ),
					'col-lg-6'  => __( '2 Column', 'themedraft-core' ),
					'col-lg-4'  => __( '3 Column', 'themedraft-core' ),
					'col-lg-3'  => __( '4 Column', 'themedraft-core' ),
				],
			]
		);

		$this->add_control(
			'tab_col',
			[
				'label'   => __( 'Column On Tablet', 'themedraft-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'col-md-6',
				'options' => [
					'col-md-12' => __( '1 Column', 'themedraft-core' ),
					'col-md-6'  => __( '2 Column', 'themedraft-core' ),
					'col-md-4'  => __( '3 Column', 'themedraft-core' ),
					'col-md-3'  => __( '4 Column', 'themedraft-core' ),
				],
			]
		);
		$this->end_controls_section();


		$this->start_controls_section(
			'team_style_options',
			[
				'label' => esc_html__( 'Style', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'name_typo',
				'label' => __( 'Name Typography', 'themedraft-core' ),
				'selector' => '{{WRAPPER}} .td-member-name',
			]
		);

		$this->add_control(
			'name_color',
			[
				'label'       => esc_html__('Name Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-member-name' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'designation_typo',
				'label' => __( 'Designation Typography', 'themedraft-core' ),
				'selector' => '{{WRAPPER}} .td-member-designation',
			]
		);

		$this->add_control(
			'designation_color',
			[
				'label'       => esc_html__('Designation Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-member-designation' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();



	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();
		$item_col = $settings['desktop_col'] . ' '. $settings['tab_col'];
		?>

        <div class="td-team-member-wrapper <?php echo $settings['team_style'];?>">
            <div class="container">
                <div class="row">
					<?php if($settings['members']){
						foreach ( $settings['members'] as $member ) {
							$target   = $member['details']['is_external'] ? ' target="_blank"' : '';
							$nofollow = $member['details']['nofollow'] ? ' rel="nofollow"' : '';

							if($member['box_animation']){
								$box_animation = 'wow'.' ' . $member['box_animation'];
								$box_animation_duration = $member['box_animation_duration'];
								$box_animation_delay = ' data-wow-delay="'.$member['box_animation_delay'].'ms"';
							}else{
								$box_animation ='';
								$box_animation_duration ='';
								$box_animation_delay ='';
							}
							?>
                            <div class="<?php echo $item_col;?>">
                                <div class="td-single-member <?php echo $box_animation;?>" <?php echo $box_animation_duration . $box_animation_delay;?>>
                                    <div class="td-member-image">
										<?php if($member['details']['url']) : ?>
                                        <a href="<?php echo esc_url( $member['details']['url'] ); ?>" <?php echo $target . $nofollow; ?>>
											<?php endif; ?>
                                            <img src="<?php echo $member['image']['url'];?>" alt="<?php echo get_post_meta( $member['image']['id'], '_wp_attachment_image_alt', true ); ?>">
											<?php if($member['details']['url']) : ?>
                                        </a>
									<?php endif; ?>
                                    </div>

                                    <div class="td-member-name-designation">
										<?php if($member['details']['url']) : ?>
                                        <a href="<?php echo esc_url( $member['details']['url'] ); ?>" <?php echo $target . $nofollow; ?>>
											<?php endif; ?>
                                            <h5 class="td-member-name"><?php echo $member['name'];?></h5>
											<?php if($member['details']['url']) : ?>
                                        </a>
									<?php endif; ?>
                                        <span class="td-member-designation"><?php echo $member['designation'];?></span>
                                    </div>
                                </div>
                            </div>
							<?php
						}
					} ?>
                </div>
            </div>
        </div>

		<?php

	}

}

Plugin::instance()->widgets_manager->register( new ThemeDraft_Team_Member_Widget );