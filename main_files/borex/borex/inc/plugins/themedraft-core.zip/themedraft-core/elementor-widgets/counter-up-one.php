<?php
namespace Elementor;
use Themedraft_Gradient_Color;
class ThemeDraft_Counter_Up_One_Widget extends Widget_Base {

	public function get_name() {

		return 'themedraft_counter_up_one';
	}

	public function get_title() {
		return esc_html__( 'Counter Up One', 'themedraft-core' );
	}

	public function get_icon() {

		return 'eicon-counter';
	}

	public function get_categories() {
		return [ 'themedraft_elements' ];
	}

	public function get_script_depends() {
		return ['counterup'];
	}


	protected function register_controls() {

		//Content tab start
		$this->start_controls_section(
			'counter_up_one_settings',
			[
				'label' => esc_html__( 'Count Up', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'count_number',
			[
				'label'   => __( 'Count Number', 'themedraft-core' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => __( '100', 'themedraft-core' ),
			]
		);

		$this->add_control(
			'count_unit',
			[
				'label'   => __( 'Counter Unit', 'themedraft-core' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( '+', 'themedraft-core' ),
			]
		);

		$this->add_control(
			'count_title',
			[
				'label'       => __( 'Count Title', 'themedraft-core' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Happy Customers', 'themedraft-core' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'box_animation',
			[
				'label' => __( 'Entrance Animation', 'themedraft-core' ),
				'type' => Controls_Manager::ANIMATION,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'box_animation_duration',
			[
				'label'     => __( 'Animation Duration', 'themedraft-core' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'data-wow-duration="1.25s"',
				'options'   => [
					'data-wow-duration="2s"'    => __( 'Slow', 'themedraft-core' ),
					'data-wow-duration="1.25s"' => __( 'Normal', 'themedraft-core' ),
					'data-wow-duration=".75s"'  => __( 'Fast', 'themedraft-core' ),
				],
				'condition' => [
					'box_animation!' => '',
				]
			]
		);

		$this->add_control(
			'box_animation_delay',
			[
				'label'       => esc_html__('Animation Delay (ms)', 'themedraft-core'),
				'type'        => Controls_Manager::NUMBER,
				'min'         => 0,
				'max'         => 100000,
				'step'        => 1,
				'default'        => 0,
				'condition' => [
					'box_animation!' => '',
				]
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
		    'count_up_one_style',
		    [
		        'label' => esc_html__( 'Number & Unit', 'themedraft-core' ),
		        'tab'   => Controls_Manager::TAB_STYLE,
		    ]
		);

		$this->add_group_control(
		    Group_Control_Typography::get_type(),
		    [
		        'name' => 'number_and_unit_typo',
		        'label' => __( 'Number & Unit Typography', 'themedraft-core' ),
		        'selector' => '{{WRAPPER}} .td-single-count-box-one .td-count-number,{{WRAPPER}} .td-single-count-box-one .td-count-unit',
		    ]
		);

		$this->add_group_control(
			Themedraft_Gradient_Color::get_type(),
			[
				'name' => 'number_and_unit_color_type',
				'selector' => '{{WRAPPER}} .td-single-count-box-one .td-count-number,{{WRAPPER}} .td-single-count-box-one .td-count-unit',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
		    'title_style',
		    [
		        'label' => esc_html__( 'Title', 'themedraft-core' ),
		        'tab'   => Controls_Manager::TAB_STYLE,
		    ]
		);

		$this->add_group_control(
		    Group_Control_Typography::get_type(),
		    [
		        'name' => 'title_typo',
		        'label' => __( 'Typography', 'themedraft-core' ),
		        'selector' => '{{WRAPPER}} .td-single-count-box-one .td-count-title',
		    ]
		);

		$this->add_control(
		    'title_color',
		    [
		        'label'       => esc_html__('Title Color', 'themedraft-core'),
		        'type'        => Controls_Manager::COLOR,
		        'selectors'   => [
		            '{{WRAPPER}} .td-single-count-box-one .td-count-title' => 'color: {{VALUE}};',
		        ],
		    ]
		);

		$this->end_controls_section();


	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();

		$count_id = rand(100, 100000);

		if($settings['box_animation']){
			$box_animation = 'wow'.' ' . $settings['box_animation'];
			$box_animation_duration = $settings['box_animation_duration'];
			$box_animation_delay = ' data-wow-delay="'.$settings['box_animation_delay'].'ms"';
		}else{
			$box_animation ='';
			$box_animation_duration ='';
			$box_animation_delay ='';
		}
		?>

		<div class="td-single-count-box-one <?php echo $box_animation;?> td-counter-box-<?php echo esc_attr($count_id);?>" <?php echo $box_animation_duration . $box_animation_delay;?>>
			<div class="td-number-unit">
				<h6 class="td-count-number"><?php echo esc_html( $settings['count_number'] ) ?></h6>
				<h6 class="td-count-unit"><?php echo esc_html( $settings['count_unit'] ) ?></h6>
			</div>

			<h6 class="td-count-title"><?php echo esc_html( $settings['count_title'] ) ?></h6>
		</div>

        <script>
            (function ($) {
                "use strict";
                /*====  Document Ready Function =====*/
                jQuery(document).ready(function($){
                    $(".td-counter-box-<?php echo esc_attr($count_id);?> .td-count-number").counterUp({
                        delay: 10,
                        time: 2000
                    });
                });
            }(jQuery));
        </script>

		<?php

	}

}

Plugin::instance()->widgets_manager->register( new ThemeDraft_Counter_Up_One_Widget );