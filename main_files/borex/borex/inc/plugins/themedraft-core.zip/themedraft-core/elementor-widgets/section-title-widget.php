<?php
namespace Elementor;
use Themedraft_Gradient_Color;
class ThemeDraft_Section_Title_Widget extends Widget_Base {

	public function get_name() {

		return 'themedraft_section_title_widget';
	}

	public function get_title() {
		return esc_html__( 'Section Title', 'themedraft-core' );
	}

	public function get_icon() {

		return 'eicon-t-letter';
	}

	public function get_categories() {
		return [ 'themedraft_elements' ];
	}


	protected function register_controls() {

		//Content tab start


		$this->start_controls_section(
		    'section_title_settings',
		    [
		        'label' => esc_html__( 'Section Title', 'themedraft-core' ),
		        'tab'   => Controls_Manager::TAB_CONTENT,
		    ]
		);

		$this->add_control(
			'subtitle',
			[
				'label'       => __( 'Subtitle', 'themedraft-core' ),
				'label_block'       => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Why Choose Us', 'themedraft-core' ),
			]
		);

		$this->add_control(
			'border_type',
			[
				'label'   => __( 'Border Type', 'themedraft-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'td-border-right',
				'options' => [
					'td-border-left-right' => __( 'Left & Right', 'themedraft-core' ),
					'td-border-left'  => __( 'Left', 'themedraft-core' ),
					'td-border-right'  => __( 'Right', 'themedraft-core' ),
					'td-no-border'  => __( 'No Border', 'themedraft-core' ),
				],
                'condition' => [
                    'subtitle!' => '',
                ],
			]
		);

		$this->add_control(
		    'title',
		    [
		        'label'       => __( 'Title', 'themedraft-core' ),
		        'type'        => Controls_Manager::TEXTAREA,
		        'rows'        => 5,
		        'default'     => __( 'We help clients to get more', 'themedraft-core' ),
                'separator' => 'before',
		    ]
		);


		$this->add_control(
		    'desc',
		    [
		        'label'       => __( 'Description', 'themedraft-core' ),
		        'type'        => Controls_Manager::WYSIWYG,
		        'default'     => __( 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris', 'themedraft-core' ),
		        'label_block' => true,
		        'separator' => 'before',
		    ]
		);

		$this->add_control(
			'section_title_animation',
			[
				'label' => __( 'Entrance Animation', 'themedraft-core' ),
				'type' => Controls_Manager::ANIMATION,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'section_title_animation_duration',
			[
				'label'     => __( 'Animation Duration', 'themedraft-core' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'data-wow-duration="1.25s"',
				'options'   => [
					'data-wow-duration="2s"'    => __( 'Slow', 'themedraft-core' ),
					'data-wow-duration="1.25s"' => __( 'Normal', 'themedraft-core' ),
					'data-wow-duration=".75s"'  => __( 'Fast', 'themedraft-core' ),
				],
				'condition' => [
					'section_title_animation!' => '',
				]
			]
		);

		$this->add_control(
			'section_title_animation_delay',
			[
				'label'       => esc_html__('Animation Delay (ms)', 'themedraft-core'),
				'type'        => Controls_Manager::NUMBER,
				'min'         => 0,
				'max'         => 100000,
				'step'        => 1,
				'default'        => 0,
				'condition' => [
					'section_title_animation!' => '',
				]
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
		    'section_title_wrapper',
		    [
		        'label' => esc_html__( 'Wrapper & Content', 'themedraft-core' ),
		        'tab'   => Controls_Manager::TAB_STYLE,
		    ]
		);

		$this->add_responsive_control(
		    'content_width',
		    [
		        'label' => __( 'Width ( % )', 'themedraft-core' ),
		        'type' => Controls_Manager::SLIDER,
		        'size_units' => ['%'],
		        'range' => [
		            '%' => [
		                'min' => 0,
		                'max' => 100,
		            ],
		        ],
		        'devices' => [ 'desktop', 'tablet', 'mobile' ],
		        'selectors' => [
		            '{{WRAPPER}} .td-section-title-content' => 'width: {{SIZE}}%;',
		        ],
		    ]
		);

		$this->add_responsive_control(
		    'text_align',
		    [
		        'label'       => esc_html__('Text Align', 'themedraft-core'),
		        'type'        => Controls_Manager::CHOOSE,
		        'label_block' => false,

		        'options' => [
		            'left' => [
		                'title' => __('Left', 'themedraft-core'),
		                'icon'  => 'fa fa-align-left',
		            ],

		            'center' => [
		                'title' => __('Center', 'themedraft-core'),
		                'icon'  => 'fa fa-align-center',
		            ],

		            'right' => [
		                'title' => __('Right', 'themedraft-core'),
		                'icon'  => 'fa fa-align-right',
		            ],
		        ],

		        'devices' => ['desktop', 'tablet', 'mobile'],

		        'selectors' => [
		            '{{WRAPPER}} .td-section-title-wrapper' => 'text-align: {{VALUE}};',
		        ],

		    ]
		);

		$this->add_responsive_control(
		    'wrapper_margin',
		    [
		        'label'      => esc_html__( 'Wrapper Margin', 'themedraft-core' ),
		        'type'       => Controls_Manager::DIMENSIONS,
		        'size_units' => [ 'px', '%', 'em' ],
		        'selectors'  => [
		            '{{WRAPPER}} .td-section-title-content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
		        ],
		    ]
		);

		$this->end_controls_section();



		$this->start_controls_section(
			'section_subtitle_style',
			[
				'label' => esc_html__( 'Subtitle', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'subtitle!' => '',
                ],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'subtitle_typo',
				'label' => __( 'Subtitle Typography', 'themedraft-core' ),
				'selector' => '{{WRAPPER}} .td-subtitle',
			]
		);

		$this->add_group_control(
			Themedraft_Gradient_Color::get_type(),
			[
				'name' => 'subtitle_color_type',
				'selector' => '{{WRAPPER}} .td-section-subtitle .td-subtitle',
				'separator' => 'before',
			]
		);

		$this->add_control(
			'subtitle_border',
			[
				'label' => __( 'Subtitle Border', 'themedraft-core' ),
				'type' => Controls_Manager::RAW_HTML,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'border_background',
				'label' => esc_html__( 'Border Background', 'themedraft-core' ),
				'types' => [ 'classic', 'gradient'],
				'selector' => '{{WRAPPER}} .td-section-subtitle .td-subtitle:before,{{WRAPPER}} .td-section-subtitle .td-subtitle:after',
				'exclude' => [
					'image'
				],
                'separator' => 'before',
			]
		);

		$this->add_responsive_control(
		    'subtitle_margin',
		    [
		        'label'      => esc_html__( 'Margin', 'themedraft-core' ),
		        'type'       => Controls_Manager::DIMENSIONS,
		        'size_units' => [ 'px', '%', 'em' ],
		        'selectors'  => [
		            '{{WRAPPER}} .td-section-subtitle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
		        ],
		        'separator' => 'before',
		    ]
		);

		$this->end_controls_section();

		$this->start_controls_section(
		    'title_style_option',
		    [
		        'label' => esc_html__( 'Title', 'themedraft-core' ),
		        'tab'   => Controls_Manager::TAB_STYLE,
		    ]
		);

		$this->add_group_control(
		    Group_Control_Typography::get_type(),
		    [
		        'name' => 'title_typo',
		        'label' => __( 'Typography', 'themedraft-core' ),
		        'selector' => '{{WRAPPER}} .td-section-title .td-title',
		    ]
		);

		$this->add_control(
		    'title_color',
		    [
		        'label'       => esc_html__('Color', 'themedraft-core'),
		        'type'        => Controls_Manager::COLOR,
		        'selectors'   => [
		            '{{WRAPPER}} .td-section-title .td-title' => 'color: {{VALUE}};',
		        ],
		    ]
		);

		$this->add_responsive_control(
		    'title_margin',
		    [
		        'label'      => esc_html__( 'Margin', 'themedraft-core' ),
		        'type'       => Controls_Manager::DIMENSIONS,
		        'size_units' => [ 'px', '%', 'em' ],
		        'selectors'  => [
		            '{{WRAPPER}} .td-section-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
		        ],
		    ]
		);

		$this->end_controls_section();

		$this->start_controls_section(
		    'section_desc_wrapper',
		    [
		        'label' => esc_html__( 'Description', 'themedraft-core' ),
		        'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'desc!' => '',
                ],
		    ]
		);

		$this->add_group_control(
		    Group_Control_Typography::get_type(),
		    [
		        'name' => 'description_typo',
		        'label' => __( 'Typography', 'themedraft-core' ),
		        'selector' => '{{WRAPPER}} .td-section-description',
		    ]
		);

		$this->add_control(
		    'desc_color',
		    [
		        'label'       => esc_html__('Color', 'themedraft-core'),
		        'type'        => Controls_Manager::COLOR,
		        'selectors'   => [
		            '{{WRAPPER}} .td-section-description' => 'color: {{VALUE}};',
		        ],
		    ]
		);

		$this->add_responsive_control(
		    'desc_margin',
		    [
		        'label'      => esc_html__( 'Margin', 'themedraft-core' ),
		        'type'       => Controls_Manager::DIMENSIONS,
		        'size_units' => [ 'px', '%', 'em' ],
		        'selectors'  => [
		            '{{WRAPPER}} .td-section-description' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
		        ],
		    ]
		);

		$this->end_controls_section();

	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();
		if($settings['section_title_animation']){
			$td_animation = 'wow'.' ' . $settings['section_title_animation'];
			$td_animation_duration = $settings['section_title_animation_duration'];
			$td_animation_delay = ' data-wow-delay="'.$settings['section_title_animation_delay'].'ms"';
		}else{
			$td_animation ='';
			$td_animation_duration ='';
			$td_animation_delay ='';
		}
		?>

		<div class="td-section-title-wrapper <?php echo $td_animation;?>" <?php echo $td_animation_duration . $td_animation_delay;?>>
			<div class="td-section-title-content">
                <?php if($settings['subtitle']) : ?>
				<div class="td-section-subtitle <?php echo $settings['border_type'];?>">
					<h6 class="td-subtitle"><?php echo $settings['subtitle'];?></h6>
				</div>
                <?php endif;?>

				<div class="td-section-title">
					<h2 class="td-title"><?php echo nl2br($settings['title']);?></h2>
				</div>

                <?php if (!empty($settings['desc'])) : ?>
				<div class="td-section-description">
                    <?php echo $settings['desc'];?>
				</div>
                <?php endif; ?>
			</div>
		</div>

		<?php

	}
}

Plugin::instance()->widgets_manager->register( new ThemeDraft_Section_Title_Widget );