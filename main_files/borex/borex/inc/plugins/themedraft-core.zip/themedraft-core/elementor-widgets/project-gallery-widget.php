<?php
namespace Elementor;

class ThemeDraft_Project_Gallery_Widget extends Widget_Base {

	public function get_name() {

		return 'themedraft_project_gallery';
	}

	public function get_title() {
		return esc_html__( 'Project Gallery', 'themedraft-core' );
	}

	public function get_icon() {

		return 'eicon-gallery-grid';
	}

	public function get_categories() {
		return [ 'themedraft_elements' ];
	}


	protected function register_controls() {

		//Content tab start
		$this->start_controls_section(
			'project_gallery_settings',
			[
				'label' => esc_html__( 'Project Gallery', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
		    'image',
		    [
		        'label'       => __( 'Image', 'themedraft-core' ),
		        'type'        => Controls_Manager::MEDIA,
		        'label_block' => true,
		        'default'     => [
		            'url' => Utils::get_placeholder_image_src(),
		        ],
		    ]
		);

		$repeater->add_control(
		    'url',
		    [
		        'label'         => __( 'URL', 'themedraft-core' ),
		        'type'          => Controls_Manager::URL,
		        'placeholder'   => __( 'https://your-link.com', 'themedraft-core' ),
		        'show_external' => true,
		        'default'       => [
		            'url'         => '',
		            'is_external' => false,
		            'nofollow'    => false,
		        ],
		    ]
		);

		$this->add_control(
		    'projects',
		    [
		        'label'       => __('Project List', 'themedraft-core'),
		        'type'        => Controls_Manager::REPEATER,
		        'fields'      => $repeater->get_controls(),
		    ]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'slider_options',
			[
				'label' => esc_html__( 'Slider Options', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'autoplay',
			[
				'label'       => __( 'Autoplay', 'themedraft-core' ),
				'type'        => Controls_Manager::SWITCHER,
				'show_label'  => true,
				'label_block' => false,
				'default'     => 'yes',
			]
		);

		$this->add_control(
			'autoplay_interval',
			[
				'label'       => __( 'Autoplay Interval', 'themedraft-core' ),
				'type'        => Controls_Manager::SELECT,
				'show_label'  => true,
				'label_block' => false,
				'options'     => [
					'2000'  => __( '2 seconds', 'themedraft-core' ),
					'3000'  => __( '3 seconds', 'themedraft-core' ),
					'4000'  => __( '4 seconds', 'themedraft-core' ),
					'5000'  => __( '5 seconds', 'themedraft-core' ),
					'6000'  => __( '6 seconds', 'themedraft-core' ),
					'7000'  => __( '7 seconds', 'themedraft-core' ),
					'8000'  => __( '8 seconds', 'themedraft-core' ),
					'9000'  => __( '9 seconds', 'themedraft-core' ),
					'10000' => __( '10 seconds', 'themedraft-core' ),
				],
				'default'     => '4000',
				'condition' => [
					'autoplay' => 'yes',
				],
			]
		);

		$this->add_control(
			'infinity_loop',
			[
				'label'       => __( 'Loop', 'themedraft-core' ),
				'type'        => Controls_Manager::SWITCHER,
				'show_label'  => true,
				'label_block' => false,
				'default'     => 'yes',
			]
		);

		$this->add_control(
			'desktop_count',
			[
				'label'       => __( 'Column On Desktop', 'themedraft-core' ),
				'type'        => Controls_Manager::SELECT,
				'show_label'  => true,
				'label_block' => false,
				'options'     => [
					1 => __( '1 Column', 'themedraft-core' ),
					2 => __( '2 Column', 'themedraft-core' ),
					3 => __( '3 Column', 'themedraft-core' ),
					4 => __( '4 Column', 'themedraft-core' ),
					5 => __( '5 Column', 'themedraft-core' ),
					6 => __( '6 Column', 'themedraft-core' ),
				],
				'default'     => 5,
			]
		);

		$this->add_control(
			'tab_count',
			[
				'label'       => __( 'Column On Tablet', 'themedraft-core' ),
				'type'        => Controls_Manager::SELECT,
				'show_label'  => true,
				'label_block' => false,
				'options'     => [
					1 => __( '1 Column', 'themedraft-core' ),
					2 => __( '2 Column', 'themedraft-core' ),
					3 => __( '3 Column', 'themedraft-core' ),
					4 => __( '4 Column', 'themedraft-core' ),
					5 => __( '5 Column', 'themedraft-core' ),
				],
				'default'     => 3,
			]
		);

		$this->add_control(
			'mbl_count',
			[
				'label'       => __( 'Column On Mobile', 'themedraft-core' ),
				'type'        => Controls_Manager::SELECT,
				'show_label'  => true,
				'label_block' => false,
				'options'     => [
					1 => __( '1 Column', 'themedraft-core' ),
					2 => __( '2 Column', 'themedraft-core' ),
					3 => __( '3 Column', 'themedraft-core' ),
				],
				'default'     => 2,
			]
		);

		$this->end_controls_section();


	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();
		$slider_id = rand(100, 100000);
		?>
		<div id="td-project-gallery-slider-<?php echo $slider_id;?>" class="td-project-gallery-wrapper">

			<?php
			if ($settings['projects']) {
				foreach ($settings['projects'] as $project) {
				    $target   = $project['url']['is_external'] ? ' target="_blank"' : '';
				    $nofollow = $project['url']['nofollow'] ? ' rel="nofollow"' : '';
				    ?>
                    <div class="single-project-gallery-item">
                        <a href="<?php echo $project['url']['url'];?>" <?php echo $target . $nofollow; ?>>
                            <img src="<?php echo esc_url($project['image']['url']);?>" alt="<?php echo get_post_meta( $project['image']['id'], '_wp_attachment_image_alt', true ); ?>">
                        </a>
                    </div>
				<?php }
			}
			?>
		</div>

        <script>
            (function ($) {
                "use strict";
                $(document).ready(function () {
                    $("#td-project-gallery-slider-<?php echo $slider_id;?>").slick({
                        slidesToShow: <?php echo json_encode( $settings['desktop_count'] )?>,
                        autoplay: <?php echo json_encode( $settings['autoplay'] == 'yes' ? true : false ); ?>,
                        autoplaySpeed: <?php echo json_encode( $settings['autoplay_interval'] )?>, //interval
                        speed: 1500, // slide speed
                        dots: false,
                        arrows: false,
                        infinite: <?php echo json_encode( $settings['infinity_loop'] == 'yes' ? true : false ); ?>,
                        pauseOnHover: false,
                        centerMode: false,
                        responsive: [

                            {
                                breakpoint: 992,
                                settings: {
                                    slidesToShow: <?php echo json_encode( $settings['tab_count'] )?>, //768-991
                                    arrows: false
                                }
                            },
                            {
                                breakpoint: 768,
                                settings: {
                                    slidesToShow: <?php echo json_encode( $settings['mbl_count'] )?>, // 0 -767
                                    arrows: false
                                }
                            }
                        ]
                    });
                });
            })(jQuery);
        </script>

		<?php

	}
}

Plugin::instance()->widgets_manager->register( new ThemeDraft_Project_Gallery_Widget );