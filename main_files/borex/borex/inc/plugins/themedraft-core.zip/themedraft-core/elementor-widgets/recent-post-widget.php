<?php

namespace Elementor;

use WP_Query;

class ThemeDraft_Recent_Post_Widget extends Widget_Base {

	public function get_name() {

		return "themedraft_recent_post";
	}

	public function get_title() {
		return __( "Recent Posts", "themedraft-core" );
	}

	public function get_icon() {

		return "eicon-post-excerpt";
	}

	public function get_categories() {
		return [ 'themedraft_elements' ];
	}


	protected function register_controls() {
		//Content tab start
		$this->start_controls_section(
			'recent_post_settings',
			[
				'label' => __( 'Post Settings', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'post_count',
			[
				'label'   => __( 'Number Of Post To Show', 'themedraft-core' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => - 1,
				'max'     => '',
				'step'    => 1,
				'default' => 2,
			]
		);

		$this->add_control(
			'category',
			[
				'label'       => __( 'Categories', 'themedraft-core' ),
				'type'        => Controls_Manager::SELECT2,
				'label_block' => true,
				'multiple'    => true,
				'options'     => themedraft_post_categories(),
			]
		);

		$this->add_control(
			'exclude_post',
			[
				'label'       => __( 'Exclude Posts', 'themedraft-core' ),
				'type'        => Controls_Manager::SELECT2,
				'label_block' => true,
				'multiple'    => true,
				'description' => __( 'Select post id.', 'themedraft-core' ),
				'options'     => themedraft_post_list(),
			]
		);


		$this->add_control(
			'post_offset',
			[
				'label'   => __( 'Post Offset', 'themedraft-core' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 0,
				'max'     => '',
				'step'    => 1,
				'default' => 0,
			]
		);

		$this->add_control(
			'post_orderby',
			[
				'label'   => __( 'Order By', 'themedraft-core' ),
				'type'    => Controls_Manager::SELECT,
				'options' => themedraft_post_orderby_options(),
				'default' => 'date',

			]
		);

		$this->add_control(
			'post_order',
			[
				'label'   => __( 'Order', 'themedraft-core' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'asc'  => 'Ascending',
					'desc' => 'Descending'
				],
				'default' => 'desc',

			]
		);

		$this->add_control(
			'read_more',
			[
				'label'       => __( 'Read More Text', 'themedraft-core' ),
				'label_block'       => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Read More', 'themedraft-core' ),
			]
		);

		$this->add_control(
			'entrance_animation',
			[
				'label' => __( 'Entrance Animation', 'themedraft-core' ),
				'type' => Controls_Manager::ANIMATION,
				'prefix_class' => 'animated ',
			]
		);

		$this->add_control(
			'post_animation_duration',
			[
				'label'     => __( 'Animation Duration', 'themedraft-core' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'data-wow-duration="1.25s"',
				'options'   => [
					'data-wow-duration="2s"'    => __( 'Slow', 'themedraft-core' ),
					'data-wow-duration="1.25s"' => __( 'Normal', 'themedraft-core' ),
					'data-wow-duration=".75s"'  => __( 'Fast', 'themedraft-core' ),
				],
				'condition' => [
					'entrance_animation!' => '',
				]
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'recent_post_layout_settings',
			[
				'label' => __( 'Post Layout', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'show_excerpt',
			[
				'label'   => __( 'Excerpt', 'themedraft-core' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->add_control(
			'excerpt_lenth',
			[
				'label'     => __( 'Excerpt Lenth', 'themedraft-core' ),
				'type'      => Controls_Manager::NUMBER,
				'min'       => 0,
				'max'       => '',
				'step'      => 1,
				'default'   => 13,
				'condition' => [
					'show_excerpt' => 'yes',
				]
			]
		);

		$this->add_control(
			'title_word',
			[
				'label'   => __( 'Title Word Count', 'themedraft-core' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 0,
				'max'     => '',
				'step'    => 1,
				'default' => 6,
			]
		);

		$this->add_control(
			'show_date',
			[
				'label'   => __( 'Show Date', 'themedraft-core' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->add_control(
			'show_comment_count',
			[
				'label'   => __( 'Show Comment Count', 'themedraft-core' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
		    'post_style',
		    [
		        'label' => esc_html__( 'Colors', 'themedraft-core' ),
		        'tab'   => Controls_Manager::TAB_STYLE,
		    ]
		);

		$this->add_control(
		    'date_readmore_color',
		    [
		        'label'       => esc_html__('Date & Read More', 'themedraft-core'),
		        'type'        => Controls_Manager::COLOR,
		        'selectors'   => [
		            '{{WRAPPER}} .td-recent-post-el-widget .td-single-post-content li a,{{WRAPPER}} .td-recent-post-el-widget .td-text-button' => 'color: {{VALUE}};',
		        ],
		    ]
		);

		$this->add_control(
		    'title_hover',
		    [
		        'label'       => esc_html__('Title Hover Color', 'themedraft-core'),
		        'type'        => Controls_Manager::COLOR,
		        'selectors'   => [
		            '{{WRAPPER}} .td-recent-post-el-widget .td-post-title:hover' => 'color: {{VALUE}};',
		        ],
		    ]
		);

		$this->end_controls_section();


	}


	//Render In HTML
	protected function render() {
		$settings = $this->get_settings_for_display();
		if($settings['entrance_animation']){
			$td_animation = 'wow'.' ' . $settings['entrance_animation'];
			$td_animation_duration = $settings['post_animation_duration'];
		}else{
			$td_animation ='';
			$td_animation_duration ='';
		}
		?>

		<div class="td-recent-post-el-widget <?php echo $td_animation;?>" <?php echo $td_animation_duration;?>>

			<div class="container">

				<div class="row">

					<?php
					if ( ! empty( $settings['category'] ) ) {
						$post_query = new WP_Query( array(
							'post_type'           => 'post',
							'posts_per_page'      => $settings['post_count'],
							'ignore_sticky_posts' => 1,
							'offset'              => $settings['post_offset'],
							'orderby'             => $settings['post_orderby'],
							'order'               => $settings['post_order'],
							'post__not_in'        => $settings['exclude_post'],
							'tax_query'           => array(
								array(
									'taxonomy' => 'category',
									'terms'    => $settings['category'],
									'field'    => 'slug',
								)
							)
						) );
					} else {

						$post_query = new WP_Query(
							array(
								'posts_per_page'      => $settings['post_count'],
								'post_type'           => 'post',
								'ignore_sticky_posts' => 1,
								'offset'              => $settings['post_offset'],
								'orderby'             => $settings['post_orderby'],
								'order'               => $settings['post_order'],
								'post__not_in'        => $settings['exclude_post'],
							)
						);
					}
					while ( $post_query->have_posts() ) : $post_query->the_post();
						?>

                    <div class="col-lg-6">
                        <div class="td-single-post-item">
                            <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                                <div class="td-single-post-wrap">
                                    <div class="td-post-thumbnail td-cover-bg"
                                         style="background-image: url(<?php echo the_post_thumbnail_url( 'full' ) ?>)"></div>

                                    <div class="td-single-post-content">
                                        <div class="td-post-meta">
                                            <ul class="td-list-style td-list-inline">
	                                            <?php if($settings['show_date'] == 'yes') : ?>
		                                            <li><?php borex_posted_on(); ?></li>
	                                            <?php endif;?>

							                    <?php if($settings['show_comment_count'] == 'yes') : ?>
                                                    <li><?php borex_comment_count(); ?></li>
							                    <?php endif;?>
                                            </ul>
                                        </div>


                                        <a href="<?php echo esc_url( get_the_permalink() );?>">
                                            <h4 class="td-post-title"><?php echo wp_trim_words(get_the_title(), $settings['title_word'], ' ...');?></h4>
                                        </a>

					                    <?php if ( $settings['show_excerpt'] === 'yes' ) : ?>
                                            <div class="td-post-excerpt">
                                                <p><?php echo themedraft_get_excerpt( get_the_ID(), $settings['excerpt_lenth'] ); ?></p>
                                            </div>
					                    <?php endif; ?>


                                            <div class="td-post-read-more">
                                                <a class="td-text-button"
                                                   href="<?php echo esc_url( get_the_permalink() ) ?>">
                                                    <?php echo esc_html__($settings['read_more']); ?>
                                                </a>
                                            </div>


                                    </div>
                                </div>
                            </article><!-- #post-<?php the_ID(); ?> -->
                        </div>
                    </div>


					<?php
					endwhile;
					wp_reset_query();
					?>
				</div>
			</div>
		</div>
		<?php

	}
}

Plugin::instance()->widgets_manager->register( new ThemeDraft_Recent_Post_Widget );