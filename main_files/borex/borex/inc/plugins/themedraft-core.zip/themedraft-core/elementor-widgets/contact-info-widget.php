<?php
namespace Elementor;

class ThemeDraft_Contact_Info_Widget extends Widget_Base {

	public function get_name() {

		return 'themedraft_contact_info';
	}

	public function get_title() {
		return esc_html__( 'Contact Info', 'themedraft-core' );
	}

	public function get_icon() {

		return 'fas fa-info-circle';
	}

	public function get_categories() {
		return [ 'themedraft_elements' ];
	}


	protected function register_controls() {

		//Content tab start
		$this->start_controls_section(
			'contact_info_settings',
			[
				'label' => esc_html__( 'Contact Info', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
		    'title',
		    [
		        'label'       => __('Title', 'themedraft-core'),
		        'type'        => Controls_Manager::TEXT,
		        'default'     => 'Our Address',
		        'label_block' => true,
		    ]
		);


		$repeater->add_control(
		    'type',
		    [
		        'label'       => __( 'Icon Type', 'themedraft-core' ),
		        'type'        => Controls_Manager::CHOOSE,
		        'label_block' => false,
		        'options'     => [
		            'icon'  => [
		                'title' => __( 'Icon', 'themedraft-core' ),
		                'icon'  => 'fa fa-smile-o',
		            ],
		            'image' => [
		                'title' => __( 'Image', 'themedraft-core' ),
		                'icon'  => 'fa fa-image',
		            ],
		        ],
		        'default'     => 'icon',
		        'toggle'      => false,
		    ]
		);

		$repeater->add_control(
		    'selected_icon',
		    [
		        'label'       => __( 'Select Icon', 'themedraft-core' ),
		        'type'             => Controls_Manager::ICONS,
		        'fa4compatibility' => 'icon',
		        'label_block'      => true,
		        'default'          => [
		            'value'   => 'flaticon-business-placeholder',
		            'library' => 'themedraft-flaticon',
		        ],
		        'condition'        => [
		            'type' => 'icon'
		        ]
		    ]
		);

		$repeater->add_control(
		    'image',
		    [
		        'label'     => __( 'Image', 'themedraft-core' ),
		        'type'      => Controls_Manager::MEDIA,
		        'default'   => [
		            'url' => Utils::get_placeholder_image_src(),
		        ],
		        'condition' => [
		            'type' => 'image'
		        ],
		        'dynamic'   => [
		            'active' => true,
		        ]
		    ]
		);

		$repeater->add_control(
            'description',
            [
                'label'       => __( 'Description', 'themedraft-core' ),
                'type'        => Controls_Manager::WYSIWYG,
                'default'     => '99 S.T Seoul Park Pekanbaru Avenue. New York - 1200',
                'label_block' => true,
            ]
        );

		$this->add_control(
		    'contact_infos',
		    [
		        'label'       => __('Contact Information', 'themedraft-core'),
		        'type'        => Controls_Manager::REPEATER,
		        'fields'      => $repeater->get_controls(),
		        'default'     => [
		            [
		                'title'        => __('Our Address', 'themedraft-core'),
		                'description' => '99 S.T Seoul Park Pekanbaru Avenue. New York - 1200',
		            ],
		        ],
		        'title_field' => '{{{ title }}}',
		    ]
		);

		$this->end_controls_section();

		$this->start_controls_section(
		    'info_box_icon_style',
		    [
		        'label' => esc_html__( 'Icon Style', 'themedraft-core' ),
		        'tab'   => Controls_Manager::TAB_STYLE,
		    ]
		);

		$this->add_control(
		    'icon_color',
		    [
		        'label'       => esc_html__('Icon Color', 'themedraft-core'),
		        'type'        => Controls_Manager::COLOR,
		        'selectors'   => [
		            '{{WRAPPER}} .td-contact-info-icon' => 'color: {{VALUE}};',
		            '{{WRAPPER}} .td-contact-info-icon svg' => 'fill: {{VALUE}};',
		        ],
		    ]
		);

		$this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
		        'name' => 'icon_background',
		        'label' => esc_html__( 'Icon Background', 'themedraft-core' ),
		        'types' => [ 'classic', 'gradient'],
		        'selector' => '{{WRAPPER}} .td-contact-info-icon',
                'exclude' => [
                        'image'
                ]
		    ]
		);

		$this->end_controls_section();

	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();
		?>

		<div class="td-contact-info-wrapper">
			<div class="row">
                <?php
                if($settings['contact_infos']){
                    foreach ($settings['contact_infos'] as $contact_info){ ?>
                        <div class="col-lg-4 col-md-6">
                            <div class="td-single-contact-info">
                                <div class="td-contact-info-icon">
				                    <?php if ( $contact_info['type'] === 'image' ) :
					                    if ( $contact_info['image']['url'] || $contact_info['image']['id'] ) :
						                    ?>
                                            <div class="td-icon-wrapper td-image-icon">
                                                <img src="<?php echo $contact_info['image']['url']; ?>"
                                                     alt="<?php echo get_post_meta( $contact_info['image']['id'], '_wp_attachment_image_alt', true ); ?>">
                                            </div>
					                    <?php endif;
                                    elseif ( ! empty( $contact_info['icon'] ) || ! empty( $contact_info['selected_icon'] ) ) : ?>
                                        <div class="td-icon-wrapper td-font-icon">
						                    <?php themedraft_custom_icon_render( $contact_info, 'icon', 'selected_icon' ); ?>
                                        </div>
				                    <?php endif; ?>
                                </div>

                                <h4 class="td-info-title"><?php echo $contact_info['title'];?></h4>

                                <div class="td-info-desc"><?php echo $contact_info['description'];?></div>
                            </div>
                        </div>
                <?php    }
                }
                ?>




			</div>
		</div>

		<?php

	}
}

Plugin::instance()->widgets_manager->register( new ThemeDraft_Contact_Info_Widget );