<?php
namespace Elementor;

use Themedraft_Gradient_Color;

class ThemeDraft_Icon_Box_Widget extends Widget_Base {

	public function get_name() {

		return 'themedraft_icon_box';
	}

	public function get_title() {
		return esc_html__( 'Icon Box', 'themedraft-core' );
	}

	public function get_icon() {

		return 'eicon-icon-box';
	}

	public function get_categories() {
		return [ 'themedraft_elements' ];
	}


	protected function register_controls() {

		//Content tab start
		$this->start_controls_section(
			'icon_box_settings',
			[
				'label' => esc_html__( 'Icon Box', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
		    'type',
		    [
		        'label'       => __( 'Icon Type', 'themedraft-core' ),
		        'type'        => Controls_Manager::CHOOSE,
		        'label_block' => false,
		        'options'     => [
		            'icon'  => [
		                'title' => __( 'Icon', 'themedraft-core' ),
		                'icon'  => 'fa fa-smile-o',
		            ],
		            'image' => [
		                'title' => __( 'Image', 'themedraft-core' ),
		                'icon'  => 'fa fa-image',
		            ],
		        ],
		        'default'     => 'icon',
		        'toggle'      => false,
		    ]
		);

		$this->add_control(
		    'selected_icon',
		    [
		        'label'       => __( 'Select Icon', 'themedraft-core' ),
		        'type'             => Controls_Manager::ICONS,
		        'fa4compatibility' => 'icon',
		        'label_block'      => true,
		        'default'          => [
		            'value'   => 'flaticon-business-team-1',
		            'library' => 'themedraft-flaticon',
		        ],
		        'condition'        => [
		            'type' => 'icon'
		        ]
		    ]
		);

		$this->add_control(
		    'image',
		    [
		        'label'     => __( 'Image', 'themedraft-core' ),
		        'type'      => Controls_Manager::MEDIA,
		        'default'   => [
		            'url' => Utils::get_placeholder_image_src(),
		        ],
		        'condition' => [
		            'type' => 'image'
		        ],
		        'dynamic'   => [
		            'active' => true,
		        ]
		    ]
		);

		$this->add_control(
		    'title',
		    [
		        'label'       => __( 'Title', 'themedraft-core' ),
		        'type'        => Controls_Manager::TEXTAREA,
		        'rows'        => 5,
		        'default'     => __( 'Flexible Solutions', 'themedraft-core' ),
		    ]
		);

		$this->add_control(
		    'desc',
		    [
		        'label'       => __( 'Description', 'themedraft-core' ),
		        'type'        => Controls_Manager::TEXTAREA,
		        'rows'        => 5,
		        'default'     => __( 'Lorem ipsum dolor sit amet, consec tetur adipis.', 'themedraft-core' ),
		    ]
		);

		$this->add_control(
			'box_animation',
			[
				'label' => __( 'Entrance Animation', 'themedraft-core' ),
				'type' => Controls_Manager::ANIMATION,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'box_animation_duration',
			[
				'label'     => __( 'Animation Duration', 'themedraft-core' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'data-wow-duration="1.25s"',
				'options'   => [
					'data-wow-duration="2s"'    => __( 'Slow', 'themedraft-core' ),
					'data-wow-duration="1.25s"' => __( 'Normal', 'themedraft-core' ),
					'data-wow-duration=".75s"'  => __( 'Fast', 'themedraft-core' ),
				],
				'condition' => [
					'box_animation!' => '',
				]
			]
		);

		$this->add_control(
			'box_animation_delay',
			[
				'label'       => esc_html__('Animation Delay (ms)', 'themedraft-core'),
				'type'        => Controls_Manager::NUMBER,
				'min'         => 0,
				'max'         => 100000,
				'step'        => 1,
				'default'        => 0,
				'condition' => [
					'box_animation!' => '',
				]
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
		    'box_icon_option',
		    [
		        'label' => esc_html__( 'Icon', 'themedraft-core' ),
		        'tab'   => Controls_Manager::TAB_STYLE,
		    ]
		);

		$this->add_group_control(
			Themedraft_Gradient_Color::get_type(),
			[
				'name' => 'icon_color_type',
				'selector' => '{{WRAPPER}} .td-icon-box-icon .td-icon-wrapper,{{WRAPPER}} .td-icon-box-icon .td-icon-wrapper svg',
				'condition' => [
					'type!' => 'image',
				],
			]
		);

		$this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
		        'name' => 'background',
		        'label' => esc_html__( 'Icon Background', 'themedraft-core' ),
		        'types' => [ 'classic', 'gradient'],
		        'selector' => '{{WRAPPER}} .td-icon-box-icon',
		        'separator' => 'before',
		        'exclude' => [
		                'image'
                ],
		    ]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'title_and_desc_style_option',
			[
				'label' => esc_html__( 'Title & Description', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'       => esc_html__('Title Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-icon-box-title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
		    'desc_color',
		    [
		        'label'       => esc_html__('Description Color', 'themedraft-core'),
		        'type'        => Controls_Manager::COLOR,
		        'selectors'   => [
		            '{{WRAPPER}} .td-icon-box-desc' => 'color: {{VALUE}};',
		        ],
		    ]
		);

		$this->end_controls_section();


	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();
		if($settings['box_animation']){
			$box_animation = 'wow'.' ' . $settings['box_animation'];
			$box_animation_duration = $settings['box_animation_duration'];
			$box_animation_delay = ' data-wow-delay="'.$settings['box_animation_delay'].'ms"';
		}else{
			$box_animation ='';
			$box_animation_duration ='';
			$box_animation_delay ='';
		}
		?>

		<div class="td-icon-box-wrapper <?php echo $box_animation;?>" <?php echo $box_animation_duration . $box_animation_delay;?>>
			<div class="td-icon-box-icon">
				<?php if ( $settings['type'] === 'image' ) :
				    if ( $settings['image']['url'] || $settings['image']['id'] ) :
				        ?>
				        <div class="td-icon-wrapper td-image-icon">
				            <img src="<?php echo $settings['image']['url']; ?>"
				                 alt="<?php echo get_post_meta( $settings['image']['id'], '_wp_attachment_image_alt', true ); ?>">
				        </div>
				    <?php endif;
				elseif ( ! empty( $settings['icon'] ) || ! empty( $settings['selected_icon'] ) ) : ?>
				    <div class="td-icon-wrapper td-font-icon">
				        <?php themedraft_custom_icon_render( $settings, 'icon', 'selected_icon' ); ?>
				    </div>
				<?php endif; ?>
			</div>

			<h5 class="td-icon-box-title"><?php echo $settings['title'];?></h5>

			<div class="td-icon-box-desc">
				<?php echo $settings['desc'];?>
			</div>
		</div>

		<?php

	}
}

Plugin::instance()->widgets_manager->register( new ThemeDraft_Icon_Box_Widget );