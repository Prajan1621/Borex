<?php
namespace Elementor;

class ThemeDraft_Home_Banner_Widget extends Widget_Base {

	public function get_name() {

		return 'themedraft_home_banner';
	}

	public function get_title() {
		return esc_html__( 'Home Banner', 'themedraft-core' );
	}

	public function get_icon() {

		return 'far fa-flag';
	}

	public function get_categories() {
		return [ 'themedraft_elements' ];
	}


	protected function register_controls() {

	    $this->start_controls_section(
	        'banner',
	        [
	            'label' => esc_html__( 'Banner', 'themedraft-core' ),
	            'tab'   => Controls_Manager::TAB_CONTENT,
	        ]
	    );

	    $this->add_control(
	        'banner_image',
	        [
	            'label'       => __( 'Banner Image', 'themedraft-core' ),
	            'type'        => Controls_Manager::MEDIA,
	            'label_block' => true,
	            'default'     => [
	                'url' => Utils::get_placeholder_image_src(),
	            ],
	        ]
	    );

	    $this->add_responsive_control(
	        'banner_height',
	        [
	            'label' => __( 'Height', 'themedraft-core' ),
	            'type' => Controls_Manager::SLIDER,
	            'size_units' => ['px'],
	            'range' => [
	                'px' => [
	                    'min' => 100,
	                    'max' => 1200,
	                ],
	            ],
	            'devices' => [ 'desktop', 'tablet', 'mobile' ],
	            'selectors' => [
	                '{{WRAPPER}} .td-home-banner' => 'height: {{SIZE}}{{UNIT}};',
	            ],
	        ]
	    );

	    $this->end_controls_section();

		//Content tab start
		$this->start_controls_section(
			'home_banner_title_options',
			[
				'label' => esc_html__( 'Title', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
		    'title',
		    [
		        'label'       => __( 'Title', 'themedraft-core' ),
		        'type'        => Controls_Manager::TEXTAREA,
		        'rows'        => 5,
		        'default'     => __( 'Investment Planning', 'themedraft-core' ),
		    ]
		);

		$this->add_control(
			'title_animation',
			[
				'label' => __( 'Entrance Animation', 'themedraft-core' ),
				'type' => Controls_Manager::ANIMATION,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'title_animation_duration',
			[
				'label'     => __( 'Animation Duration', 'themedraft-core' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'data-wow-duration="1.25s"',
				'options'   => [
					'data-wow-duration="2s"'    => __( 'Slow', 'themedraft-core' ),
					'data-wow-duration="1.25s"' => __( 'Normal', 'themedraft-core' ),
					'data-wow-duration=".75s"'  => __( 'Fast', 'themedraft-core' ),
				],
				'condition' => [
					'title_animation!' => '',
				]
			]
		);

		$this->add_control(
		    'title_animation_delay',
		    [
		        'label'       => esc_html__('Animation Delay (ms)', 'themedraft-core'),
		        'type'        => Controls_Manager::NUMBER,
		        'min'         => 0,
		        'max'         => 100000,
		        'step'        => 1,
		        'default'        => 0,
		        'condition' => [
			        'title_animation!' => '',
		        ]
		    ]
		);

		$this->end_controls_section();

		$this->start_controls_section(
		    'banner_description_options',
		    [
		        'label' => esc_html__( 'Description', 'themedraft-core' ),
		        'tab'   => Controls_Manager::TAB_CONTENT,
		    ]
		);
		$this->add_control(
		    'desc',
		    [
		        'label'       => __( 'Description', 'themedraft-core' ),
		        'type'        => Controls_Manager::WYSIWYG,
		        'default'     => __( '<p>Dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>', 'themedraft-core' ),
		        'label_block' => true,
		    ]
		);

		$this->add_control(
			'desc_animation',
			[
				'label' => __( 'Entrance Animation', 'themedraft-core' ),
				'type' => Controls_Manager::ANIMATION,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'desc_animation_duration',
			[
				'label'     => __( 'Animation Duration', 'themedraft-core' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'data-wow-duration="1.25s"',
				'options'   => [
					'data-wow-duration="2s"'    => __( 'Slow', 'themedraft-core' ),
					'data-wow-duration="1.25s"' => __( 'Normal', 'themedraft-core' ),
					'data-wow-duration=".75s"'  => __( 'Fast', 'themedraft-core' ),
				],
				'condition' => [
					'desc_animation!' => '',
				]
			]
		);

		$this->add_control(
			'desc_animation_delay',
			[
				'label'       => esc_html__('Animation Delay (ms)', 'themedraft-core'),
				'type'        => Controls_Manager::NUMBER,
				'min'         => 0,
				'max'         => 100000,
				'step'        => 1,
				'default'        => 0,
				'condition' => [
					'desc_animation!' => '',
				]
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
		    'banner_button_options',
		    [
		        'label' => esc_html__( 'Button', 'themedraft-core' ),
		        'tab'   => Controls_Manager::TAB_CONTENT,
		    ]
		);

		$this->add_control(
			'btn1_text',
			[
				'label' => __( 'Button One Text', 'themedraft-core' ),
				'type' => Controls_Manager::TEXT,
				'separator' => 'before',
				'label_block' => true,
				'default' => __( 'Learn More', 'themedraft-core' ),
				'placeholder' => __( 'Type button text here.', 'themedraft-core' ),
			]
		);

		$this->add_control(
			'btn1_url',
			[
				'label' => __( 'Button One URL', 'themedraft-core' ),
				'type' => Controls_Manager::URL,
				'placeholder' => __( 'https://your-link.com', 'themedraft-core' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => false,
					'nofollow' => false,
				],
			]
		);

		//Button 2 Text
		$this->add_control(
			'btn2_text',
			[
				'label' => __( 'Button Two Text', 'themedraft-core' ),
				'type' => Controls_Manager::TEXT,
				'separator' => 'before',
				'label_block' => true,
				'placeholder' => __( 'Type button text here.', 'themedraft-core' ),
			]
		);

		//Button 2 Url
		$this->add_control(
			'btn2_url',
			[
				'label' => __( 'Button Two URL', 'themedraft-core' ),
				'type' => Controls_Manager::URL,
				'placeholder' => __( 'https://your-link.com', 'themedraft-core' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => false,
					'nofollow' => false,
				],
			]
		);

		$this->add_control(
			'btn_animation',
			[
				'label' => __( 'Entrance Animation', 'themedraft-core' ),
				'type' => Controls_Manager::ANIMATION,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'btn_animation_duration',
			[
				'label'     => __( 'Animation Duration', 'themedraft-core' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'data-wow-duration="1.25s"',
				'options'   => [
					'data-wow-duration="2s"'    => __( 'Slow', 'themedraft-core' ),
					'data-wow-duration="1.25s"' => __( 'Normal', 'themedraft-core' ),
					'data-wow-duration=".75s"'  => __( 'Fast', 'themedraft-core' ),
				],
				'condition' => [
					'btn_animation!' => '',
				]
			]
		);

		$this->add_control(
			'btn_animation_delay',
			[
				'label'       => esc_html__('Animation Delay (ms)', 'themedraft-core'),
				'type'        => Controls_Manager::NUMBER,
				'min'         => 0,
				'max'         => 100000,
				'step'        => 1,
				'default'        => 0,
				'condition' => [
					'btn_animation!' => '',
				]
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
		    'banner_title_style',
		    [
		        'label' => esc_html__( 'Title', 'themedraft-core' ),
		        'tab'   => Controls_Manager::TAB_STYLE,
		    ]
		);

		$this->add_group_control(
		    Group_Control_Typography::get_type(),
		    [
		        'name' => 'title_typo',
		        'label' => __( 'Typography', 'themedraft-core' ),
		        'selector' => '{{WRAPPER}} .td-home-banner .td-banner-title',
		    ]
		);

		$this->add_control(
		    'title_color',
		    [
		        'label'       => esc_html__('Color', 'themedraft-core'),
		        'type'        => Controls_Manager::COLOR,
		        'selectors'   => [
		            '{{WRAPPER}} .td-home-banner .td-banner-title' => 'color: {{VALUE}};',
		        ],
		    ]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'banner_desc_style',
			[
				'label' => esc_html__( 'Description', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'desc_typo',
				'label' => __( 'Typography', 'themedraft-core' ),
				'selector' => '{{WRAPPER}} .td-home-banner .td-banner-description',
			]
		);

		$this->add_control(
			'desc_color',
			[
				'label'       => esc_html__('Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-home-banner .td-banner-description' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
		    'desc_margin',
		    [
		        'label'      => esc_html__( 'Margin', 'themedraft-core' ),
		        'type'       => Controls_Manager::DIMENSIONS,
		        'size_units' => [ 'px', '%', 'em' ],
		        'selectors'  => [
		            '{{WRAPPER}} .td-home-banner .td-banner-description' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
		        ],
		    ]
		);

		$this->end_controls_section();




		// Start Button section
		$this->start_controls_section(
		    'td_button_style_options',
		    [
		        'label' => esc_html__('Button', 'themedraft-core'),
		        'tab'   => Controls_Manager::TAB_STYLE,
		    ]
		);

		$this->start_controls_tabs('td_button_style_tabs');

		//Default style tab start
		$this->start_controls_tab(
		    'td_btn_style_default',
		    [
		        'label' => esc_html__('Normal', 'themedraft-core'),
		    ]
		);

		$this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
		        'name' => 'button_default_bg',
		        'label' => esc_html__( 'Background', 'themedraft-core' ),
		        'types' => [ 'classic', 'gradient'],
		        'exclude' => [
			        'image',
		        ],
		        'selector' => '{{WRAPPER}} .td-button',
		    ]
		);


		$this->add_control(
		    'button_default_text_color',
		    [
		        'label'     => esc_html__('Text Color', 'themedraft-core'),
		        'type'      => Controls_Manager::COLOR,
		        'selectors' => [
		            '{{WRAPPER}} .td-button' => 'color: {{VALUE}};',
		        ],
		        'separator' => 'before',
		    ]
		);

		$this->end_controls_tab();//Default style tab end

		//Hover style tab start
		$this->start_controls_tab(
		    'td_btn_style_hover',
		    [
		        'label' => esc_html__('Hover', 'themedraft-core'),
		    ]
		);

		$this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
		        'name' => 'button_hover_bg',
		        'label' => esc_html__( 'Background', 'themedraft-core' ),
		        'types' => [ 'classic', 'gradient'],
		        'selector' => '{{WRAPPER}} .td-button:hover',
                'exclude' => [
                        'image',
                ],
		    ]
		);

		$this->add_control(
		    'button_hover_text_color',
		    [
		        'label'     => esc_html__('Text Color', 'themedraft-core'),
		        'type'      => Controls_Manager::COLOR,
		        'selectors' => [
		            '{{WRAPPER}} .td-button:hover' => 'color: {{VALUE}};',
		        ],
		        'separator' => 'before',
		    ]
		);

		$this->add_control(
			'btn_one_border_color',
			[
				'label'       => esc_html__('Border Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-button:before' => 'border-color: {{VALUE}};',
				],
				'separator' => 'before',
			]
		);

		$this->end_controls_tabs();//Hover style tab end

		$this->end_controls_section();// End Button section


	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();
		if($settings['title_animation']){
			$title_animation = 'wow'.' ' . $settings['title_animation'];
			$title_animation_duration = $settings['title_animation_duration'];
			$title_animation_delay = ' data-wow-delay="'.$settings['title_animation_delay'].'ms"';
		}else{
			$title_animation ='';
			$title_animation_duration ='';
			$title_animation_delay ='';
		}

		if($settings['desc_animation']){
			$desc_animation = 'wow'.' ' . $settings['desc_animation'];
			$desc_animation_duration = $settings['desc_animation_duration'];
			$desc_animation_delay = ' data-wow-delay="'.$settings['desc_animation_delay'].'ms"';
		}else{
			$desc_animation ='';
			$desc_animation_duration ='';
			$desc_animation_delay ='';
		}

		if($settings['btn_animation']){
			$btn_animation = 'wow'.' ' . $settings['btn_animation'];
			$btn_animation_duration = $settings['btn_animation_duration'];
			$btn_animation_delay = ' data-wow-delay="'.$settings['btn_animation_delay'].'ms"';
		}else{
			$btn_animation ='';
			$btn_animation_duration ='';
			$btn_animation_delay ='';
		}
		?>

		<div class="td-home-banner-wrapper">
			<div class="td-home-banner td-cover-bg" style="background-image: url(<?php echo esc_url($settings['banner_image']['url'])?>)">
                <div class="td-table">
                    <div class="td-table-cell">
                        <div class="container">
                            <div class="row">
                                <div class="col-xl-7 col-lg-8">
                                    <div class="banner-content-wrapper">
                                        <h2 class="td-banner-title <?php echo $title_animation;?>" <?php echo $title_animation_duration . $title_animation_delay;?>><?php echo $settings['title'];?></h2>

                                        <div class="td-banner-description  <?php echo $desc_animation;?>" <?php echo $desc_animation_duration . $desc_animation_delay;?>>
                                            <?php echo $settings['desc'];?>
                                        </div>

                                        <?php if(!empty($settings['btn1_text']) || !empty($settings['btn2_text'])) : ?>

                                        <div class="td-banner-button <?php echo $btn_animation;?>" <?php echo $btn_animation_duration . $btn_animation_delay;?>>

	                                        <?php if(!empty($settings['btn1_text'])) :
		                                        $target = $settings['btn1_url']['is_external'] ? ' target="_blank"' : '';
		                                        $nofollow = $settings['btn1_url']['nofollow'] ? ' rel="nofollow"' : '';
		                                        ?>
                                                <a href="<?php echo esc_url($settings['btn1_url']['url'])?>" class="td-button" <?php echo  $target . $nofollow?>><?php echo esc_html($settings['btn1_text']) ?> <i class="fas fa-long-arrow-alt-right"></i></a>
	                                        <?php endif;?>

	                                        <?php if(!empty($settings['btn2_text'])) :
		                                        $target2 = $settings['btn2_url']['is_external'] ? ' target="_blank"' : '';
		                                        $nofollow2 = $settings['btn2_url']['nofollow'] ? ' rel="nofollow"' : '';
		                                        ?>
                                                <a href="<?php echo esc_url($settings['btn2_url']['url'])?>" class="td-button banner-button-two" <?php echo  $target2 . $nofollow2?>><?php echo esc_html($settings['btn2_text']) ?> <i class="fas fa-long-arrow-alt-right"></i></a>
	                                        <?php endif;?>
                                        </div>

                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
			</div>
		</div>

		<?php

	}

}

Plugin::instance()->widgets_manager->register( new ThemeDraft_Home_Banner_Widget );