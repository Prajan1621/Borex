<?php
namespace Elementor;

class ThemeDraft_Service_Box_Two_Widget extends Widget_Base {

	public function get_name() {

		return 'themedraft_service_box_two';
	}

	public function get_title() {
		return esc_html__( 'Service Box Two', 'themedraft-core' );
	}

	public function get_icon() {

		return 'flaticon-business-suitcase';
	}

	public function get_categories() {
		return [ 'themedraft_elements' ];
	}


	protected function register_controls() {

		//Content tab start
		$this->start_controls_section(
			'service_box_two_settings',
			[
				'label' => esc_html__( 'Service Box', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'title',
			[
				'label'       => __( 'Title', 'themedraft-core' ),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 5,
				'default'     => __( 'Business Strategy', 'themedraft-core' ),
			]
		);

		$repeater->add_control(
			'desc',
			[
				'label'       => __( 'Description', 'themedraft-core' ),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 5,
				'default'     => __( 'Grow your business with our agency and save your time & money.', 'themedraft-core' ),
			]
		);

		$repeater->add_control(
			'type',
			[
				'label'       => __( 'Icon Type', 'themedraft-core' ),
				'type'        => Controls_Manager::CHOOSE,
				'label_block' => false,
				'options'     => [
					'icon'  => [
						'title' => __( 'Icon', 'themedraft-core' ),
						'icon'  => 'fa fa-smile-o',
					],
					'image' => [
						'title' => __( 'Image', 'themedraft-core' ),
						'icon'  => 'fa fa-image',
					],
				],
				'default'     => 'icon',
				'toggle'      => false,
			]
		);

		$repeater->add_control(
			'selected_icon',
			[
				'label'       => __( 'Select Icon', 'themedraft-core' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'label_block'      => true,
				'default'          => [
					'value'   => 'flaticon-business-wallet-1',
					'library' => 'themedraft-flaticon',
				],
				'condition'        => [
					'type' => 'icon'
				]
			]
		);

		$repeater->add_control(
			'image',
			[
				'label'     => __( 'Image', 'themedraft-core' ),
				'type'      => Controls_Manager::MEDIA,
				'default'   => [
					'url' => Utils::get_placeholder_image_src(),
				],
				'condition' => [
					'type' => 'image'
				],
				'dynamic'   => [
					'active' => true,
				]
			]
		);

		$repeater->add_control(
			'details_url',
			[
				'label'         => __( 'Details URL', 'themedraft-core' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => __( 'https://your-link.com', 'themedraft-core' ),
				'show_external' => true,
				'default'       => [
					'url'         => '',
					'is_external' => false,
					'nofollow'    => false,
				],
			]
		);

		$repeater->add_control(
			'btn_text',
			[
				'label'       => __( 'Button Text', 'themedraft-core' ),
				'label_block'       => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Read More', 'themedraft-core' ),
			]
		);

		$repeater->add_control(
			'box_animation',
			[
				'label' => __( 'Entrance Animation', 'themedraft-core' ),
				'type' => Controls_Manager::ANIMATION,
				'separator' => 'before',
			]
		);

		$repeater->add_control(
			'box_animation_duration',
			[
				'label'     => __( 'Animation Duration', 'themedraft-core' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'data-wow-duration="1.25s"',
				'options'   => [
					'data-wow-duration="2s"'    => __( 'Slow', 'themedraft-core' ),
					'data-wow-duration="1.25s"' => __( 'Normal', 'themedraft-core' ),
					'data-wow-duration=".75s"'  => __( 'Fast', 'themedraft-core' ),
				],
				'condition' => [
					'box_animation!' => '',
				]
			]
		);

		$repeater->add_control(
			'box_animation_delay',
			[
				'label'       => esc_html__('Animation Delay (ms)', 'themedraft-core'),
				'type'        => Controls_Manager::NUMBER,
				'min'         => 0,
				'max'         => 100000,
				'step'        => 1,
				'default'        => 0,
				'condition' => [
					'box_animation!' => '',
				]
			]
		);


		$this->add_control(
			'services',
			[
				'label'       => __('Service List', 'themedraft-core'),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'title'        => __('Business Strategy', 'themedraft-core'),
						'desc'        => __('Grow your business with our agency and save your time & money.', 'themedraft-core'),
						'btn_text'        => __('Read More', 'themedraft-core'),
					],
				],
				'title_field' => '{{{ title }}}',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'service_column_settings',
			[
				'label' => esc_html__( 'Column', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'desktop_col',
			[
				'label'   => __( 'Column On Desktop', 'themedraft-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'col-lg-4',
				'options' => [
					'col-lg-12' => __( '1 Column', 'themedraft-core' ),
					'col-lg-6'  => __( '2 Column', 'themedraft-core' ),
					'col-lg-4'  => __( '3 Column', 'themedraft-core' ),
					'col-lg-3'  => __( '4 Column', 'themedraft-core' ),
				],
			]
		);

		$this->add_control(
			'tab_col',
			[
				'label'   => __( 'Column On Tablet', 'themedraft-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'col-md-6',
				'options' => [
					'col-md-12' => __( '1 Column', 'themedraft-core' ),
					'col-md-6'  => __( '2 Column', 'themedraft-core' ),
					'col-md-4'  => __( '3 Column', 'themedraft-core' ),
					'col-md-3'  => __( '4 Column', 'themedraft-core' ),
				],
			]
		);
		$this->end_controls_section();

		// Start Color section
		$this->start_controls_section(
		    'service_color_style_options',
		    [
		        'label' => esc_html__('Colors', 'themedraft-core'),
		        'tab'   => Controls_Manager::TAB_STYLE,
		    ]
		);

		$this->start_controls_tabs('td_color_style_tabs');

		//Default style tab start
		$this->start_controls_tab(
		    'td_color_style_default',
		    [
		        'label' => esc_html__('Normal', 'themedraft-core'),
		    ]
		);

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'normal_background',
                'label' => esc_html__( 'Background', 'themedraft-core' ),
                'types' => [ 'classic', 'gradient'],
                'exclude' => [ 'image'],
                'selector' => '{{WRAPPER}} .td-service-two-wrapper .single-service-box',
            ]
        );

        $this->add_control(
            'normal_icon_bg',
            [
                'label'       => esc_html__('Icon Background', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .td-service-two-icon' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'normal_icon_color',
            [
                'label'       => esc_html__('Icon Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .td-service-two-icon' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .td-service-two-icon svg' => 'fill: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'normal_title_color',
            [
                'label'       => esc_html__('Title Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .td-service-two-wrapper .title' => 'color: {{VALUE}};',
                ],
            ]
        );

		$this->add_control(
			'normal_desc_color',
			[
				'label'       => esc_html__('Description Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-service-two-wrapper .service-two-desc' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
		    'normal_button_bg',
		    [
		        'label'       => esc_html__('Button Background', 'themedraft-core'),
		        'type'        => Controls_Manager::COLOR,
		        'selectors'   => [
		            '{{WRAPPER}} .service-two-button a' => 'background-color: {{VALUE}};',
		        ],
		    ]
		);

		$this->add_control(
			'normal_button_text_color',
			[
				'label'       => esc_html__('Button Text Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .service-two-button a' => 'color: {{VALUE}};',
				],
			]
		);


		$this->end_controls_tab();//Default style tab end

		//Hover style tab start
		$this->start_controls_tab(
		    'td_color_style_hover',
		    [
		        'label' => esc_html__('Hover', 'themedraft-core'),
		    ]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'hover_background',
				'label' => esc_html__( 'Background', 'themedraft-core' ),
				'types' => [ 'classic', 'gradient'],
				'exclude' => [ 'image'],
				'selector' => '{{WRAPPER}} .td-service-two-wrapper .single-service-box:before',
			]
		);

		$this->add_control(
			'hover_icon_bg',
			[
				'label'       => esc_html__('Icon Background', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-service-two-wrapper .single-service-box:hover .td-service-two-icon' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'hover_icon_color',
			[
				'label'       => esc_html__('Icon Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-service-two-wrapper .single-service-box:hover .td-service-two-icon' => 'color: {{VALUE}};',
					'{{WRAPPER}} .td-service-two-wrapper .single-service-box:hover .td-service-two-icon svg' => 'fill: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'hover_title_color',
			[
				'label'       => esc_html__('Title Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-service-two-wrapper .single-service-box:hover .title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'hover_desc_color',
			[
				'label'       => esc_html__('Description Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-service-two-wrapper .single-service-box:hover .service-two-desc' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'hover_button_bg',
			[
				'label'       => esc_html__('Button Background', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-service-two-wrapper .single-service-box:hover .service-two-button a' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'hover_button_text_color',
			[
				'label'       => esc_html__('Button Text Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-service-two-wrapper .single-service-box:hover .service-two-button a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tabs();//Hover style tab end

		$this->end_controls_section();

	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();
		$item_col = $settings['desktop_col'] . ' '. $settings['tab_col'];
		?>

		<div class="td-service-two-wrapper">
            <div class="container">
                <div class="row">

                    <?php if($settings['services']){
                        foreach ($settings['services'] as $service){
                            $target   = $service['details_url']['is_external'] ? ' target="_blank"' : '';
                            $nofollow = $service['details_url']['nofollow'] ? ' rel="nofollow"' : '';

                            if($service['box_animation']){
                                $box_animation = 'wow'.' ' . $service['box_animation'];
                                $box_animation_duration = $service['box_animation_duration'];
                                $box_animation_delay = ' data-wow-delay="'.$service['box_animation_delay'].'ms"';
                            }else{
                                $box_animation ='';
                                $box_animation_duration ='';
                                $box_animation_delay ='';
                            }
                            ?>
                            <div class="<?php echo $item_col;?>">
                                <div class="single-service-box <?php echo $box_animation;?>" <?php echo $box_animation_duration . $box_animation_delay;?>>
                                    <div class="td-service-two-icon">
                                        <?php if ( $service['type'] === 'image' ) :
                                            if ( $service['image']['url'] || $service['image']['id'] ) :
                                                ?>
                                                <div class="td-icon-wrapper td-image-icon">
                                                    <img src="<?php echo $service['image']['url']; ?>"
                                                         alt="<?php echo get_post_meta( $service['image']['id'], '_wp_attachment_image_alt', true ); ?>">
                                                </div>
                                            <?php endif;
                                        elseif ( ! empty( $service['icon'] ) || ! empty( $service['selected_icon'] ) ) : ?>
                                            <div class="td-icon-wrapper td-font-icon">
                                                <?php themedraft_custom_icon_render( $service, 'icon', 'selected_icon' ); ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>

                                    <h4 class="title"><?php echo $service['title'];?></h4>

                                    <div class="service-two-desc">
                                        <?php echo $service['desc'];?>
                                    </div>
                                    <?php if($service['btn_text']) :?>
                                    <div class="service-two-button">
                                        <a href="<?php echo $service['details_url']['url'];?>" <?php echo $target . $nofollow?>><?php echo $service['btn_text'];?></a>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                    <?php	}
                    } ?>

                </div>
            </div>
		</div>

		<?php

	}
}

Plugin::instance()->widgets_manager->register( new ThemeDraft_Service_Box_Two_Widget );