<?php
namespace Elementor;
use Themedraft_Gradient_Color;
class ThemeDraft_Service_Box_One_Widget extends Widget_Base {

	public function get_name() {

		return 'themedraft_service_box_one';
	}

	public function get_title() {
		return esc_html__( 'Service Box One', 'themedraft-core' );
	}

	public function get_icon() {

		return 'flaticon-business-suitcase';
	}

	public function get_categories() {
		return [ 'themedraft_elements' ];
	}


	protected function register_controls() {

		//Content tab start
		$this->start_controls_section(
			'service_box_settings',
			[
				'label' => esc_html__( 'Service Box', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
		    'title',
		    [
		        'label'       => __( 'Title', 'themedraft-core' ),
		        'type'        => Controls_Manager::TEXTAREA,
		        'rows'        => 5,
		        'default'     => __( 'Finance & business support', 'themedraft-core' ),
		        'placeholder' => __( '', 'themedraft-core' ),
		    ]
		);

		$repeater->add_control(
		    'thumb_image',
		    [
		        'label'       => __( 'Image', 'themedraft-core' ),
		        'description'       => __( 'Use 450px x 290px image for better user experience.', 'themedraft-core' ),
		        'type'        => Controls_Manager::MEDIA,
		        'label_block' => true,
		        'default'     => [
		            'url' => Utils::get_placeholder_image_src(),
		        ],
		    ]
		);

		$repeater->add_control(
		    'type',
		    [
		        'label'       => __( 'Icon Type', 'themedraft-core' ),
		        'type'        => Controls_Manager::CHOOSE,
		        'label_block' => false,
		        'options'     => [
		            'icon'  => [
		                'title' => __( 'Icon', 'themedraft-core' ),
		                'icon'  => 'fa fa-smile-o',
		            ],
		            'image' => [
		                'title' => __( 'Image', 'themedraft-core' ),
		                'icon'  => 'fa fa-image',
		            ],
		        ],
		        'default'     => 'icon',
		        'toggle'      => false,
		    ]
		);

		$repeater->add_control(
		    'selected_icon',
		    [
		        'label'       => __( 'Select Icon', 'themedraft-core' ),
		        'type'             => Controls_Manager::ICONS,
		        'fa4compatibility' => 'icon',
		        'label_block'      => true,
		        'default'          => [
		            'value'   => 'flaticon-business-wallet-1',
		            'library' => 'themedraft-flaticon',
		        ],
		        'condition'        => [
		            'type' => 'icon'
		        ]
		    ]
		);

		$repeater->add_control(
		    'image',
		    [
		        'label'     => __( 'Image', 'themedraft-core' ),
		        'type'      => Controls_Manager::MEDIA,
		        'default'   => [
		            'url' => Utils::get_placeholder_image_src(),
		        ],
		        'condition' => [
		            'type' => 'image'
		        ],
		        'dynamic'   => [
		            'active' => true,
		        ]
		    ]
		);

		$repeater->add_control(
			'details_url',
			[
				'label'         => __( 'Details URL', 'themedraft-core' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => __( 'https://your-link.com', 'themedraft-core' ),
				'show_external' => true,
				'default'       => [
					'url'         => '',
					'is_external' => false,
					'nofollow'    => false,
				],
			]
		);

		$repeater->add_control(
			'btn_text',
			[
				'label'       => __( 'Button Text', 'themedraft-core' ),
				'label_block'       => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Read More', 'themedraft-core' ),
			]
		);

		$repeater->add_control(
			'box_animation',
			[
				'label' => __( 'Entrance Animation', 'themedraft-core' ),
				'type' => Controls_Manager::ANIMATION,
				'separator' => 'before',
			]
		);

		$repeater->add_control(
			'box_animation_duration',
			[
				'label'     => __( 'Animation Duration', 'themedraft-core' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'data-wow-duration="1.25s"',
				'options'   => [
					'data-wow-duration="2s"'    => __( 'Slow', 'themedraft-core' ),
					'data-wow-duration="1.25s"' => __( 'Normal', 'themedraft-core' ),
					'data-wow-duration=".75s"'  => __( 'Fast', 'themedraft-core' ),
				],
				'condition' => [
					'box_animation!' => '',
				]
			]
		);

		$repeater->add_control(
			'box_animation_delay',
			[
				'label'       => esc_html__('Animation Delay (ms)', 'themedraft-core'),
				'type'        => Controls_Manager::NUMBER,
				'min'         => 0,
				'max'         => 100000,
				'step'        => 1,
				'default'        => 0,
				'condition' => [
					'box_animation!' => '',
				]
			]
		);


		$this->add_control(
		    'services',
		    [
		        'label'       => __('Service List', 'themedraft-core'),
		        'type'        => Controls_Manager::REPEATER,
		        'fields'      => $repeater->get_controls(),
		        'default'     => [
		            [
		                'title'        => __('Finance & business support', 'themedraft-core'),
		                'btn_text'        => __('Read More', 'themedraft-core'),
		            ],
		        ],
		        'title_field' => '{{{ title }}}',
		    ]
		);

		$this->end_controls_section();

		$this->start_controls_section(
		    'service_column_settings',
		    [
		        'label' => esc_html__( 'Column', 'themedraft-core' ),
		        'tab'   => Controls_Manager::TAB_CONTENT,
		    ]
		);

		$this->add_control(
			'desktop_col',
			[
				'label'   => __( 'Column On Desktop', 'themedraft-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'col-lg-4',
				'options' => [
					'col-lg-12' => __( '1 Column', 'themedraft-core' ),
					'col-lg-6'  => __( '2 Column', 'themedraft-core' ),
					'col-lg-4'  => __( '3 Column', 'themedraft-core' ),
					'col-lg-3'  => __( '4 Column', 'themedraft-core' ),
				],
			]
		);

		$this->add_control(
			'tab_col',
			[
				'label'   => __( 'Column On Tablet', 'themedraft-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'col-md-6',
				'options' => [
					'col-md-12' => __( '1 Column', 'themedraft-core' ),
					'col-md-6'  => __( '2 Column', 'themedraft-core' ),
					'col-md-4'  => __( '3 Column', 'themedraft-core' ),
					'col-md-3'  => __( '4 Column', 'themedraft-core' ),
				],
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
		    'service_box_icon_style',
		    [
		        'label' => esc_html__( 'Icon', 'themedraft-core' ),
		        'tab'   => Controls_Manager::TAB_STYLE,
		    ]
		);

		$this->add_group_control(
		    Themedraft_Gradient_Color::get_type(),
		    [
		        'name' => 'icon_color_type',
		        'selector' => '{{WRAPPER}} .td-service-icon, {{WRAPPER}} .td-service-icon svg',
		    ]
		);

		$this->end_controls_section();

		$this->start_controls_section(
		    'service_box_title_style',
		    [
		        'label' => esc_html__( 'Title', 'themedraft-core' ),
		        'tab'   => Controls_Manager::TAB_STYLE,
		    ]
		);

		$this->add_group_control(
		    Group_Control_Typography::get_type(),
		    [
		        'name' => 'title_typo',
		        'label' => __( 'Typography', 'themedraft-core' ),
		        'selector' => '{{WRAPPER}} .td-service-title',
		    ]
		);

		$this->add_control(
		    'title_color',
		    [
		        'label'       => esc_html__('Color', 'themedraft-core'),
		        'type'        => Controls_Manager::COLOR,
		        'selectors'   => [
		            '{{WRAPPER}} .td-service-title' => 'color: {{VALUE}};',
		        ],
		    ]
		);

		$this->end_controls_section();

		$this->start_controls_section(
		    'read_more_style',
		    [
		        'label' => esc_html__( 'Read More', 'themedraft-core' ),
		        'tab'   => Controls_Manager::TAB_STYLE,
		    ]
		);

		$this->add_group_control(
		    Group_Control_Typography::get_type(),
		    [
		        'name' => 'read_more_style',
		        'label' => __( 'Typography', 'themedraft-core' ),
		        'selector' => '{{WRAPPER}} .td-service-url',
		    ]
		);

		$this->add_group_control(
		    Themedraft_Gradient_Color::get_type(),
		    [
		        'name' => 'read_more_color_type',
		        'selector' => '{{WRAPPER}} .td-service-url',
		    ]
		);

		$this->end_controls_section();

	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();
		$item_col = $settings['desktop_col'] . ' '. $settings['tab_col'];
		?>

		<div class="td-service-one-wrapper">
            <div class="row">

	            <?php if ( $settings['services'] ) {
		            foreach ( $settings['services'] as $service ) {
			            $target   = $service['details_url']['is_external'] ? ' target="_blank"' : '';
			            $nofollow = $service['details_url']['nofollow'] ? ' rel="nofollow"' : '';

			            if($service['box_animation']){
				            $box_animation = 'wow'.' ' . $service['box_animation'];
				            $box_animation_duration = $service['box_animation_duration'];
				            $box_animation_delay = ' data-wow-delay="'.$service['box_animation_delay'].'ms"';
			            }else{
				            $box_animation ='';
				            $box_animation_duration ='';
				            $box_animation_delay ='';
			            }
			            ?>

                        <div class="<?php echo $item_col;?>">
                            <div class="td-single-service-box <?php echo $box_animation;?>" <?php echo $box_animation_duration . $box_animation_delay;?>>
                                <div class="td-service-image">
                                    <img class="td-service-thumb" src="<?php echo esc_url($service['thumb_image']['url']);?>" alt="<?php echo get_post_meta( $service['thumb_image']['id'], '_wp_attachment_image_alt', true ); ?>">
                                </div>

                                <div class="td-service-content">
                                    <div class="td-service-icon">
		                                <?php if ( $service['type'] === 'image' ) :
			                                if ( $service['image']['url'] || $service['image']['id'] ) :
				                                ?>
                                                <div class="td-icon-wrapper td-image-icon">
                                                    <img src="<?php echo $service['image']['url']; ?>"
                                                         alt="<?php echo get_post_meta( $service['image']['id'], '_wp_attachment_image_alt', true ); ?>">
                                                </div>
			                                <?php endif;
                                        elseif ( ! empty( $service['icon'] ) || ! empty( $service['selected_icon'] ) ) : ?>
                                            <div class="td-icon-wrapper td-font-icon">
				                                <?php themedraft_custom_icon_render( $service, 'icon', 'selected_icon' ); ?>
                                            </div>
		                                <?php endif; ?>
                                    </div>

                                    <h4 class="td-service-title"><?php echo nl2br($service['title']);?></h4>

                                    <a class="td-service-url" href="<?php echo $service['details_url']['url'];?>" <?php echo $target . $nofollow?>><?php echo $service['btn_text'];?></a>
                                </div>
                            </div>
                        </div>

			            <?php
		            }
	            } ?>
            </div>
		</div>

		<?php

	}
}

Plugin::instance()->widgets_manager->register( new ThemeDraft_Service_Box_One_Widget );