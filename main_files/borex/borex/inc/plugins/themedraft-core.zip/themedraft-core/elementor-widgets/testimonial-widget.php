<?php
namespace Elementor;

use Themedraft_Gradient_Color;

class ThemeDraft_Testimonial_One_Widget extends Widget_Base {

	public function get_name() {

		return 'themedraft_testimonial_one';
	}

	public function get_title() {
		return esc_html__( 'Testimonial One', 'themedraft-core' );
	}

	public function get_icon() {

		return 'eicon-testimonial';
	}

	public function get_categories() {
		return [ 'themedraft_elements' ];
	}


	protected function register_controls() {
		//Content tab start
		$this->start_controls_section(
			'testimonial_settings',
			[
				'label' => esc_html__( 'Testimonials', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
		    'person_image',
		    [
		        'label'       => __( 'Person Image', 'themedraft-core' ),
		        'type'        => Controls_Manager::MEDIA,
		        'label_block' => true,
		        'default'     => [
		            'url' => Utils::get_placeholder_image_src(),
		        ],
		    ]
		);

		$repeater->add_control(
		    'person_name',
		    [
		        'label'       => __('Person Name', 'themedraft-core'),
		        'type'        => Controls_Manager::TEXT,
		        'default'     => __('Md Nadim Khan', 'themedraft-core'),
		        'label_block' => true,
		    ]
		);

		$repeater->add_control(
		    'person_designation',
		    [
		        'label'       => __('Person Designation', 'themedraft-core'),
		        'type'        => Controls_Manager::TEXT,
		        'default'     => __('Managing Director', 'themedraft-core'),
		        'label_block' => true,
		    ]
		);


		$repeater->add_control(
		    'testimonial_text',
		    [
		        'label'   => __('Testimonial Text', 'themedraft-core'),
		        'type'    => Controls_Manager::WYSIWYG,
		        'default' => __('Labore et dolore magna aliqua ute enim ad min veniam and the nostrud ullamco laboris and nisiut aliquip exea commodos for this consequat.', 'themedraft-core'),
		    ]
		);

		$repeater->add_control(
			'rating',
			[
				'label' => esc_html__( 'Rating', 'themedraft-core' ),
				'type' => Controls_Manager::SELECT,
				'show_label' => true,
				'label_block' => false,

				'options' => [
					'1'  => esc_html__( '1 Star', 'themedraft-core' ),
					'2'  => esc_html__( '2 Star', 'themedraft-core' ),
					'3'  => esc_html__( '3 Star', 'themedraft-core' ),
					'4'  => esc_html__( '4 Star', 'themedraft-core' ),
					'5'  => esc_html__( '5 Star', 'themedraft-core' ),
				],

				'default' => '5',
			]
		);



		$this->add_control(
		    'testimonials',
		    [
		        'label'       => __('Testimonials List', 'themedraft-core'),
		        'type'        => Controls_Manager::REPEATER,
		        'fields'      => $repeater->get_controls(),
		        'default'     => [
		            [
		                'person_name'        => __('Md Nadim Khan', 'themedraft-core'),
		                'person_designation'        => __('Managing Director', 'themedraft-core'),
		                'testimonial_text' => __('Labore et dolore magna aliqua ute enim ad min veniam and the nostrud ullamco laboris and nisiut aliquip exea commodos for this consequat.', 'themedraft-core'),
		            ],
		        ],
		        'title_field' => '{{{ person_name }}}',
		    ]
		);


		$this->add_control(
			'entrance_animation',
			[
				'label' => __( 'Entrance Animation', 'themedraft-core' ),
				'type' => Controls_Manager::ANIMATION,
				'prefix_class' => 'animated ',
			]
		);

		$this->add_control(
			'testi_animation_duration',
			[
				'label'     => __( 'Animation Duration', 'themedraft-core' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'data-wow-duration="1.25s"',
				'options'   => [
					'data-wow-duration="2s"'    => __( 'Slow', 'themedraft-core' ),
					'data-wow-duration="1.25s"' => __( 'Normal', 'themedraft-core' ),
					'data-wow-duration=".75s"'  => __( 'Fast', 'themedraft-core' ),
				],
				'condition' => [
					'entrance_animation!' => '',
				]
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'slider_options',
			[
				'label' => esc_html__( 'Slider Options', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'autoplay',
			[
				'label'       => __( 'Autoplay', 'themedraft-core' ),
				'type'        => Controls_Manager::SWITCHER,
				'show_label'  => true,
				'label_block' => false,
				'default'     => 'yes',
			]
		);

		$this->add_control(
			'autoplay_interval',
			[
				'label'       => __( 'Autoplay Interval', 'themedraft-core' ),
				'type'        => Controls_Manager::SELECT,
				'show_label'  => true,
				'label_block' => false,
				'options'     => [
					'2000'  => __( '2 seconds', 'themedraft-core' ),
					'3000'  => __( '3 seconds', 'themedraft-core' ),
					'4000'  => __( '4 seconds', 'themedraft-core' ),
					'5000'  => __( '5 seconds', 'themedraft-core' ),
					'6000'  => __( '6 seconds', 'themedraft-core' ),
					'7000'  => __( '7 seconds', 'themedraft-core' ),
					'8000'  => __( '8 seconds', 'themedraft-core' ),
					'9000'  => __( '9 seconds', 'themedraft-core' ),
					'10000' => __( '10 seconds', 'themedraft-core' ),
				],
				'default'     => '4000',
				'condition' => [
					'autoplay' => 'yes',
				],
			]
		);

		$this->add_control(
			'infinity_loop',
			[
				'label'       => __( 'Loop', 'themedraft-core' ),
				'type'        => Controls_Manager::SWITCHER,
				'show_label'  => true,
				'label_block' => false,
				'default'     => 'yes',
			]
		);

		$this->add_control(
			'desktop_count',
			[
				'label'       => __( 'Column On Desktop', 'themedraft-core' ),
				'type'        => Controls_Manager::SELECT,
				'show_label'  => true,
				'label_block' => false,
				'options'     => [
					1 => __( '1 Column', 'themedraft-core' ),
					2 => __( '2 Column', 'themedraft-core' ),
					3 => __( '3 Column', 'themedraft-core' ),
					4 => __( '4 Column', 'themedraft-core' ),
				],
				'default'     => 2,
			]
		);

		$this->add_control(
			'tab_count',
			[
				'label'       => __( 'Column On Tablet', 'themedraft-core' ),
				'type'        => Controls_Manager::SELECT,
				'show_label'  => true,
				'label_block' => false,
				'options'     => [
					1 => __( '1 Column', 'themedraft-core' ),
					2 => __( '2 Column', 'themedraft-core' ),
					3 => __( '3 Column', 'themedraft-core' ),
				],
				'default'     => 2,
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
		    'testimonial_style',
		    [
		        'label' => esc_html__( 'Style', 'themedraft-core' ),
		        'tab'   => Controls_Manager::TAB_STYLE,
		    ]
		);

		$this->add_group_control(
		    Themedraft_Gradient_Color::get_type(),
		    [
		        'name' => 'icon_color_type',
		        'selector' => '{{WRAPPER}} .testimonial-text i, {{WRAPPER}} .td-person-name-rating i',
		    ]
		);

		$this->add_control(
		    'text_color',
		    [
		        'label'       => esc_html__('Text Color', 'themedraft-core'),
		        'type'        => Controls_Manager::COLOR,
		        'selectors'   => [
		            '{{WRAPPER}} .testimonial-text, {{WRAPPER}} .designation' => 'color: {{VALUE}};',
		        ],

                'separator' => 'before',
		    ]
		);

		$this->add_control(
			'title_color',
			[
				'label'       => esc_html__('Title Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-person-info .name' => 'color: {{VALUE}};',
				],

				'separator' => 'before',
			]
		);

		$this->add_control(
		    'testimonial_background_color',
		    [
		        'label'       => esc_html__('Background Color', 'themedraft-core'),
		        'type'        => Controls_Manager::COLOR,
		        'selectors'   => [
		            '{{WRAPPER}} .td-testimonial-content-wrapper' => 'background-color: {{VALUE}};',
		        ],

		        'separator' => 'before',
		    ]
		);

		$this->end_controls_section();

	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();
		$slider_id = rand(100, 100000);
		if($settings['entrance_animation']){
			$td_animation = 'wow'.' ' . $settings['entrance_animation'];
			$td_animation_duration = $settings['testi_animation_duration'];
		}else{
			$td_animation ='';
			$td_animation_duration ='';
		}
		?>

		<div class="td-testimonial-slider-wrapper <?php echo $td_animation;?>" <?php echo $td_animation_duration;?>>

			<div id="td-testimonial-slider-<?php echo $slider_id;?>" class="row">

				<?php if ( $settings['testimonials'] ) {
					foreach ( $settings['testimonials'] as $testimonial ) { ?>

                        <div class="td-single-testimonial col-12">
                            <div class="td-testimonial-content-wrapper">
                                <div class="testimonial-text">
                                    <i class="flaticon-business-quote-left"></i>
                                    <?php echo $testimonial['testimonial_text'];?>
                                </div>

                                <div class="td-person-info">
                                    <div class="td-person-image td-cover-bg" style="background-image: url(<?php echo esc_url($testimonial['person_image']['url']);?>)"></div>

                                    <div class="td-person-name-rating">
                                        <h4 class="name"><?php echo $testimonial['person_name'];?></h4>
                                        <p class="designation"><?php echo $testimonial['person_designation'];?></p>
                                        <ul class="td-list-style td-list-inline">
                                            <?php
                                            $star = $testimonial['rating'];

                                            for($x = 1; $x <= $star; $x++){ ?>
                                                <li>
                                                    <i class="fas fa-star"></i>
                                                </li>
                                            <?php }
                                            ?>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
						<?php
					}
				} ?>
			</div>
		</div>

        <script>
            (function ($) {
                "use strict";
                $(document).ready(function () {
                    $("#td-testimonial-slider-<?php echo $slider_id;?>").slick({
                        slidesToShow: <?php echo json_encode( $settings['desktop_count'] )?>,
                        autoplay: <?php echo json_encode( $settings['autoplay'] == 'yes' ? true : false ); ?>,
                        autoplaySpeed: <?php echo json_encode( $settings['autoplay_interval'] )?>, //interval
                        speed: 1500, // slide speed
                        dots: false,
                        arrows: false,
                        infinite: <?php echo json_encode( $settings['infinity_loop'] == 'yes' ? true : false ); ?>,
                        pauseOnHover: false,
                        centerMode: false,
                        responsive: [

                            {
                                breakpoint: 1025,
                                settings: {
                                    slidesToShow: <?php echo json_encode( $settings['tab_count'] )?>, //768-991
                                }
                            },

                            {
                                breakpoint: 992,
                                settings: {
                                    slidesToShow: <?php echo json_encode( $settings['tab_count'] )?>, //768-991
                                    arrows: false
                                }
                            },
                            {
                                breakpoint: 768,
                                settings: {
                                    slidesToShow: 1, // 0 -767
                                    arrows: false
                                }
                            }
                        ]
                    });
                });
            })(jQuery);
        </script>

		<?php

	}

}

Plugin::instance()->widgets_manager->register( new ThemeDraft_Testimonial_One_Widget );