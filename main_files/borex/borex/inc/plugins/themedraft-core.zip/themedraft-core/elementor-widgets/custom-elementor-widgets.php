<?php
use Elementor\Controls_Manager;


if (!defined('ABSPATH')) exit;

require_once ('controls/icons.php');

if(defined( 'ELEMENTOR_PATH' )){
	require_once ('controls/gradient-color.php');
}



class Themedraft_Elementor_Config {

	public function __construct() {
		add_action( 'elementor/frontend/after_register_scripts', array( $this, 'themedraft_core_register_scripts' ) );
	}

	public function themedraft_core_register_scripts() {
		wp_register_script( 'counterup', plugins_url( '/', __FILE__ ) . 'assets/js/counterup.js', array( 'jquery' ), '1.0', true );
		wp_register_script( 'circle-progress', plugins_url( '/', __FILE__ ) . 'assets/js/circle-progress.min.js', array( 'jquery' ), '1.0', false );
	}
}

new Themedraft_Elementor_Config();

class Themedraft_Elementor_Widget {

	private static $instance = null;

	public static function get_instance() {
		if ( ! self::$instance ) {
			self::$instance = new self;
		}

		return self::$instance;
	}

	public function themedraft_add_elementor_widgets() {

		// Check if the Elementor plugin has been installed / activated.
		if ( defined( 'ELEMENTOR_PATH' ) && class_exists( 'Elementor\Widget_Base' ) ) {

			require_once( 'accordion-widget.php' );
			require_once( 'brand-image-slider-widget.php' );
			require_once( 'button-widget.php' );
			require_once( 'circle-progressbar-widget.php' );
			require_once( 'contact-and-subscribe-widget.php' );
			require_once( 'contact-form7-widget.php' );
			require_once( 'contact-info-widget.php' );
			require_once( 'counter-up-one.php' );
			require_once( 'home-banner-widget.php' );
			require_once( 'icon-box-widget.php' );
			require_once( 'icon-list-widget.php' );
			require_once( 'image-text-widget.php' );
			require_once( 'image-text-two-widget.php' );
			require_once( 'popup-video-widget.php' );
			require_once( 'project-gallery-widget.php' );
			require_once( 'projects-widget.php' );
			require_once( 'promo-box-widget.php' );
			require_once( 'recent-post-widget.php' );
			require_once( 'section-title-widget.php' );
			require_once( 'service-box-one.php' );
			require_once( 'service-box-two-widgets.php' );
			require_once( 'team-member-details.php' );
			require_once( 'team-member-widget.php' );
			require_once( 'testimonial-widget.php' );
			require_once( 'testimonial-two-widget.php' );
		}
	}

	public function themedraft_register_controls( Controls_Manager $controls_Manager ) {
		$foreground = 'Themedraft_Gradient_Color';

		$controls_Manager->add_group_control( $foreground::get_type(), new $foreground() );
	}

	public function init() {
		add_action('elementor/widgets/register', array($this, 'themedraft_add_elementor_widgets'));
		// Register custom controls
		add_action( 'elementor/controls/register', [ $this, 'themedraft_register_controls' ] );
	}
}

Themedraft_Elementor_Widget::get_instance()->init();


// Add New Category In Elementor Widget

function themedraft_elementor_widget_categories( $elements_manager ) {

	$elements_manager->add_category(
		'themedraft_elements',
		[
			'title' => __( 'Themedraft Elements', 'themedraft-core' ),
		]
	);

}

add_action('elementor/elements/categories_registered', 'themedraft_elementor_widget_categories');