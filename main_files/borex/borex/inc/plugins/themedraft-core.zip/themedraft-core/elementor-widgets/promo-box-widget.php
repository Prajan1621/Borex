<?php
namespace Elementor;
use Themedraft_Gradient_Color;
class ThemeDraft_Promo_Box_One_Widget extends Widget_Base {

	public function get_name() {

		return 'themedraft_promo_box_one';
	}

	public function get_title() {
		return esc_html__( 'Promo Box One', 'themedraft-core' );
	}

	public function get_icon() {

		return 'flaticon-business-box-2';
	}

	public function get_categories() {
		return [ 'themedraft_elements' ];
	}


	protected function register_controls() {

	    $this->start_controls_section(
	        'promo_box_image',
	        [
	            'label' => esc_html__( 'Image', 'themedraft-core' ),
	            'tab'   => Controls_Manager::TAB_CONTENT,
	        ]
	    );

		$this->add_control(
			'image',
			[
				'label'       => __( 'Image', 'themedraft-core' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
				'description'       => __( 'Use 307px x 307px image for better user experience', 'themedraft-core' ),
			]
		);

		$this->add_control(
			'image_animation',
			[
				'label' => __( 'Entrance Animation', 'themedraft-core' ),
				'type' => Controls_Manager::ANIMATION,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'image_animation_duration',
			[
				'label'     => __( 'Animation Duration', 'themedraft-core' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'data-wow-duration="1.25s"',
				'options'   => [
					'data-wow-duration="2s"'    => __( 'Slow', 'themedraft-core' ),
					'data-wow-duration="1.25s"' => __( 'Normal', 'themedraft-core' ),
					'data-wow-duration=".75s"'  => __( 'Fast', 'themedraft-core' ),
				],
				'condition' => [
					'image_animation!' => '',
				]
			]
		);

		$this->add_control(
			'image_animation_delay',
			[
				'label'       => esc_html__('Animation Delay (ms)', 'themedraft-core'),
				'type'        => Controls_Manager::NUMBER,
				'min'         => 0,
				'max'         => 100000,
				'step'        => 1,
				'default'        => 0,
				'condition' => [
					'image_animation!' => '',
				]
			]
		);

	    $this->end_controls_section();

		//Content tab start
		$this->start_controls_section(
			'promo_box_settings',
			[
				'label' => esc_html__( 'Promo Box', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
		    'title',
		    [
		        'label'       => __( 'Title', 'themedraft-core' ),
		        'type'        => Controls_Manager::TEXTAREA,
		        'rows'        => 5,
		        'default'     => __( 'Budgeting & Planning', 'themedraft-core' ),
		    ]
		);

		$repeater->add_control(
		    'type',
		    [
		        'label'       => __( 'Icon Type', 'themedraft-core' ),
		        'type'        => Controls_Manager::CHOOSE,
		        'label_block' => false,
		        'options'     => [
		            'icon'  => [
		                'title' => __( 'Icon', 'themedraft-core' ),
		                'icon'  => 'fa fa-smile-o',
		            ],
		            'image' => [
		                'title' => __( 'Image', 'themedraft-core' ),
		                'icon'  => 'fa fa-image',
		            ],
		        ],
		        'default'     => 'icon',
		        'toggle'      => false,
		    ]
		);

		$repeater->add_control(
		    'selected_icon',
		    [
		        'label'       => __( 'Select Icon', 'themedraft-core' ),
		        'type'             => Controls_Manager::ICONS,
		        'fa4compatibility' => 'icon',
		        'label_block'      => true,
		        'default'          => [
		            'value'   => 'flaticon-business-up',
		            'library' => 'themedraft-flaticon',
		        ],
		        'condition'        => [
		            'type' => 'icon'
		        ]
		    ]
		);

		$repeater->add_control(
		    'image',
		    [
		        'label'     => __( 'Image', 'themedraft-core' ),
		        'type'      => Controls_Manager::MEDIA,
		        'default'   => [
		            'url' => Utils::get_placeholder_image_src(),
		        ],
		        'condition' => [
		            'type' => 'image'
		        ],
		        'dynamic'   => [
		            'active' => true,
		        ]
		    ]
		);

		$repeater->add_control(
		    'url',
		    [
		        'label'         => __( 'Box URL', 'themedraft-core' ),
		        'type'          => Controls_Manager::URL,
		        'placeholder'   => __( 'https://your-link.com', 'themedraft-core' ),
		        'show_external' => true,
		        'default'       => [
		            'url'         => '',
		            'is_external' => false,
		            'nofollow'    => false,
		        ],
		    ]
		);

		$repeater->add_control(
			'box_animation',
			[
				'label' => __( 'Entrance Animation', 'themedraft-core' ),
				'type' => Controls_Manager::ANIMATION,
				'separator' => 'before',
			]
		);

		$repeater->add_control(
			'box_animation_duration',
			[
				'label'     => __( 'Animation Duration', 'themedraft-core' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'data-wow-duration="1.25s"',
				'options'   => [
					'data-wow-duration="2s"'    => __( 'Slow', 'themedraft-core' ),
					'data-wow-duration="1.25s"' => __( 'Normal', 'themedraft-core' ),
					'data-wow-duration=".75s"'  => __( 'Fast', 'themedraft-core' ),
				],
				'condition' => [
					'box_animation!' => '',
				]
			]
		);

		$repeater->add_control(
			'box_animation_delay',
			[
				'label'       => esc_html__('Animation Delay (ms)', 'themedraft-core'),
				'type'        => Controls_Manager::NUMBER,
				'min'         => 0,
				'max'         => 100000,
				'step'        => 1,
				'default'        => 0,
				'condition' => [
					'box_animation!' => '',
				]
			]
		);

		$this->add_control(
			'promo_boxes',
			[
				'label'       => __('Promo Box List', 'themedraft-core'),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'title'        => __('Budgeting & Planning', 'themedraft-core'),
					],
				],
				'title_field' => '{{{ title }}}',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
		    'promo_box_title_style',
		    [
		        'label' => esc_html__( 'Title', 'themedraft-core' ),
		        'tab'   => Controls_Manager::TAB_STYLE,
		    ]
		);

		$this->add_group_control(
		    Group_Control_Typography::get_type(),
		    [
		        'name' => 'title_typo',
		        'label' => __( 'Typography', 'themedraft-core' ),
		        'selector' => '{{WRAPPER}} .td-promo-title',
		    ]
		);

		$this->add_control(
		    'title_color',
		    [
		        'label'       => esc_html__('Color', 'themedraft-core'),
		        'type'        => Controls_Manager::COLOR,
		        'selectors'   => [
		            '{{WRAPPER}} .td-promo-title' => 'color: {{VALUE}};',
		        ],
		    ]
		);

		$this->end_controls_section();

        $this->start_controls_section(
            'promo_icon',
            [
                'label' => esc_html__( 'Icon', 'themedraft-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

		$this->add_group_control(
			Themedraft_Gradient_Color::get_type(),
			[
				'name' => 'main_icon_color',
				'selector' => '{{WRAPPER}} .td-promo-box-icon,{{WRAPPER}} .td-promo-box-icon svg',
			]
		);

		$this->add_control(
		    'water_icon',
		    [
		        'label'       => esc_html__('Top Icon Color', 'themedraft-core'),
		        'type'        => Controls_Manager::COLOR,
		        'selectors'   => [
		            '{{WRAPPER}} .td-promo-box-watermark-icon' => 'color: {{VALUE}};',
		            '{{WRAPPER}} .td-promo-box-watermark-icon svg' => 'fill: {{VALUE}};',
		        ],
		        'separator' => 'before',
		    ]
		);

		$this->add_control(
		    'details_url_icon',
		    [
		        'label'       => esc_html__('Details Icon Color', 'themedraft-core'),
		        'type'        => Controls_Manager::COLOR,
		        'selectors'   => [
		            '{{WRAPPER}} .td-promo-box-link a' => 'color: {{VALUE}};',
		        ],
		        'separator' => 'before',
		    ]
		);

		$this->add_control(
			'details_url_icon_hover',
			[
				'label'       => esc_html__('Details Icon Hover Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-promo-box-item:hover .td-promo-box-link a' => 'color: {{VALUE}};',
				],
				'separator' => 'before',
			]
		);

        $this->end_controls_section();

	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();

		if($settings['image_animation']){
			$image_animation = 'wow'.' ' . $settings['image_animation'];
			$image_animation_duration = $settings['image_animation_duration'];
			$image_animation_delay = ' data-wow-delay="'.$settings['image_animation_delay'].'ms"';
		}else{
			$image_animation ='';
			$image_animation_duration ='';
			$image_animation_delay ='';
		}
		?>

		<div class="td-promo-box-wrapper">
			<div class="container">
				<div class="row">
                    <?php if($settings['image']['url']) :?>
					<div class="col-lg-3 col-md-6">
                        <div class="td-promo-box-item promo-image-column <?php echo $image_animation;?>" <?php echo $image_animation_duration . $image_animation_delay;?>>
						    <img src="<?php echo esc_url($settings['image']['url'])?>" alt="<?php echo get_post_meta( $settings['image']['id'], '_wp_attachment_image_alt', true ); ?>">
                        </div>
					</div>
                    <?php endif; ?>

					<?php if ( $settings['promo_boxes'] ) {
						foreach ( $settings['promo_boxes'] as $box ) {
						    $target   = $box['url']['is_external'] ? ' target="_blank"' : '';
						    $nofollow = $box['url']['nofollow'] ? ' rel="nofollow"' : '';

							if($box['box_animation']){
								$box_animation = 'wow'.' ' . $box['box_animation'];
								$box_animation_duration = $box['box_animation_duration'];
								$box_animation_delay = ' data-wow-delay="'.$box['box_animation_delay'].'ms"';
							}else{
								$box_animation ='';
								$box_animation_duration ='';
								$box_animation_delay ='';
							}
						    ?>
                            <div class="col-lg-3 col-md-6">
                                <div class="td-promo-box-item <?php echo $box_animation;?>" <?php echo $box_animation_duration . $box_animation_delay;?>>
                                    <h5 class="td-promo-title"><?php echo nl2br($box['title'])?></h5>
                                    <div class="td-promo-box-icon">
                                        <?php if ( $box['type'] === 'image' ) :
                                            if ( $box['image']['url'] || $box['image']['id'] ) :
                                                ?>
                                                <div class="td-icon-wrapper td-image-icon">
                                                    <img src="<?php echo $box['image']['url']; ?>"
                                                         alt="<?php echo get_post_meta( $box['image']['id'], '_wp_attachment_image_alt', true ); ?>">
                                                </div>
                                            <?php endif;
                                        elseif ( ! empty( $box['icon'] ) || ! empty( $box['selected_icon'] ) ) : ?>
                                            <div class="td-icon-wrapper td-font-icon">
                                                <?php themedraft_custom_icon_render( $box, 'icon', 'selected_icon' ); ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>

                                    <div class="td-promo-box-watermark-icon">
	                                    <?php if ( $box['type'] === 'image' ) :
		                                    if ( $box['image']['url'] || $box['image']['id'] ) :
			                                    ?>
                                                <div class="td-icon-wrapper td-image-icon">
                                                    <img src="<?php echo $box['image']['url']; ?>"
                                                         alt="<?php echo get_post_meta( $box['image']['id'], '_wp_attachment_image_alt', true ); ?>">
                                                </div>
		                                    <?php endif;
                                        elseif ( ! empty( $box['icon'] ) || ! empty( $box['selected_icon'] ) ) : ?>
                                            <div class="td-icon-wrapper td-font-icon">
			                                    <?php themedraft_custom_icon_render( $box, 'icon', 'selected_icon' ); ?>
                                            </div>
	                                    <?php endif; ?>
                                    </div>

                                    <div class="td-promo-box-link">
                                        <a href="<?php echo esc_url($box['url']['url']);?>" <?php echo $target . $nofollow?>><i class="flaticon-business-right-arrow"></i></a>
                                    </div>
                                </div>
                            </div>
							<?php
						}
					}; ?>
				</div>
			</div>
		</div>

		<?php

	}
}

Plugin::instance()->widgets_manager->register( new ThemeDraft_Promo_Box_One_Widget );