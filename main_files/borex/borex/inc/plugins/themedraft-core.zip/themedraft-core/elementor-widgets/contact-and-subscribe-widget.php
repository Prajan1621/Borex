<?php
namespace Elementor;

class ThemeDraft_Contact_And_Subscribe_Widget extends Widget_Base {

	public function get_name() {

		return 'themedraft_text_with_title';
	}

	public function get_title() {
		return esc_html__( 'Contact & Subscribe', 'themedraft-core' );
	}

	public function get_icon() {

		return 'flaticon-business-contact';
	}

	public function get_categories() {
		return [ 'themedraft_elements' ];
	}


	protected function register_controls() {

		//Content tab start
		$this->start_controls_section(
			'contact_options_settings',
			[
				'label' => esc_html__( 'Contact', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
		    'contact_title',
		    [
		        'label'       => __( 'Title', 'themedraft-core' ),
		        'type'        => Controls_Manager::TEXTAREA,
		        'rows'        => 5,
		        'default'     => __( 'Need Consultation?', 'themedraft-core' ),
		    ]
		);

		$this->add_control(
		    'desc',
		    [
		        'label'       => __( 'Description', 'themedraft-core' ),
		        'type'        => Controls_Manager::WYSIWYG,
		        'default'     => '<ul><li><a href="tel:1234567890">Phone: +84 935 815 989</a></li><li><a href="mailto:borex@themedraft.net">Email: borex@themedraft.net</a></li></ul>',
		        'description' => __( 'Use unordered list.', 'themedraft-core' ),
		        'label_block' => true,
		    ]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'subscribe_options_settings',
			[
				'label' => esc_html__( 'Subscribe', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'form_title',
			[
				'label'       => __( 'Title', 'themedraft-core' ),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 5,
				'default'     => __( 'Subscribe Newsletter.', 'themedraft-core' ),
			]
		);

		$this->add_control(
		    'subscribe_form',
		    [
		        'label'       => __( 'Subscribe Form Shortcode', 'themedraft-core' ),
		        'label_block'       => true,
		        'type'        => Controls_Manager::TEXT,
		    ]
		);

		$this->end_controls_section();


		$this->start_controls_section(
		    'c_s_colors',
		    [
		        'label' => esc_html__( 'Style', 'themedraft-core' ),
		        'tab'   => Controls_Manager::TAB_STYLE,
		    ]
		);

        $this->add_responsive_control(
            'wrapper_padding',
            [
                'label'      => esc_html__( 'Wrapper Padding', 'themedraft-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .td-contact-and-subscribe-wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

		$this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
		        'name' => 'background',
		        'label' => esc_html__( 'Background Color', 'themedraft-core' ),
		        'types' => [ 'classic', 'gradient'],
		        'selector' => '{{WRAPPER}} .td-contact-and-subscribe-wrapper',
                'exclude' => [
                  'image'
                ],
		    ]
		);

		$this->add_control(
		    'text_color',
		    [
		        'label'       => esc_html__('Text Color', 'themedraft-core'),
		        'type'        => Controls_Manager::COLOR,
		        'selectors'   => [
		            '{{WRAPPER}} .td-contact-and-subscribe-wrapper .td-contact-title, {{WRAPPER}} .td-contact-and-subscribe-wrapper .td-subscribe-title,{{WRAPPER}} .td-contact-and-subscribe-wrapper .td-contact-wrapper ul li,{{WRAPPER}} .td-contact-and-subscribe-wrapper .td-contact-wrapper ul li a' => 'color: {{VALUE}};',
		        ],
		    ]
		);

		$this->add_control(
		    'subscribe_bg',
		    [
		        'label'       => esc_html__('Subscribe Background Color', 'themedraft-core'),
		        'type'        => Controls_Manager::COLOR,
		        'selectors'   => [
		            '{{WRAPPER}} .td-contact-and-subscribe-wrapper .td-subscribe-form input[type="email"]' => 'background-color: {{VALUE}};',
		        ],
		    ]
		);

		$this->add_control(
			'subscribe_placeholder',
			[
				'label'       => esc_html__('Subscribe Placeholder Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-contact-and-subscribe-wrapper ::placeholder' => 'color: {{VALUE}};',
					'{{WRAPPER}} .td-contact-and-subscribe-wrapper :-ms-input-placeholder' => 'color: {{VALUE}};',
					'{{WRAPPER}} .td-contact-and-subscribe-wrapper ::-ms-input-placeholder' => 'color: {{VALUE}};',

				],
			]
		);

		$this->add_control(
		    'subscribe_text_color',
		    [
		        'label'       => esc_html__('Subscribe Text Color', 'themedraft-core'),
		        'type'        => Controls_Manager::COLOR,
		        'selectors'   => [
		            '{{WRAPPER}} .td-contact-and-subscribe-wrapper .td-subscribe-form input[type="email"]' => 'color: {{VALUE}};',
		        ],
		    ]
		);

		$this->add_control(
		    'button_bg',
		    [
		        'label'       => esc_html__('Button Background Color', 'themedraft-core'),
		        'type'        => Controls_Manager::COLOR,
		        'selectors'   => [
		            '{{WRAPPER}} .td-contact-and-subscribe-wrapper .subscribe-button input[type="submit"]' => 'background-color: {{VALUE}};',
		        ],
		    ]
		);

		$this->add_control(
			'button_color',
			[
				'label'       => esc_html__('Button Text Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-contact-and-subscribe-wrapper .subscribe-button input[type="submit"]' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
		    'border_color',
		    [
		        'label'       => esc_html__('Border Color', 'themedraft-core'),
		        'type'        => Controls_Manager::COLOR,
		        'selectors'   => [
		            '{{WRAPPER}} .td-subscribe-wrapper' => 'border-left: 1px solid {{VALUE}};',
		        ],
		    ]
		);

		$this->end_controls_section();

		$this->start_controls_section(
		    'sub_anim_options',
		    [
		        'label' => esc_html__( 'Animations', 'themedraft-core' ),
		        'tab'   => Controls_Manager::TAB_CONTENT,
		    ]
		);

		$this->add_control(
			'box_animation',
			[
				'label' => __( 'Entrance Animation', 'themedraft-core' ),
				'type' => Controls_Manager::ANIMATION,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'box_animation_duration',
			[
				'label'     => __( 'Animation Duration', 'themedraft-core' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'data-wow-duration="1.25s"',
				'options'   => [
					'data-wow-duration="2s"'    => __( 'Slow', 'themedraft-core' ),
					'data-wow-duration="1.25s"' => __( 'Normal', 'themedraft-core' ),
					'data-wow-duration=".75s"'  => __( 'Fast', 'themedraft-core' ),
				],
				'condition' => [
					'box_animation!' => '',
				]
			]
		);

		$this->add_control(
			'box_animation_delay',
			[
				'label'       => esc_html__('Animation Delay (ms)', 'themedraft-core'),
				'type'        => Controls_Manager::NUMBER,
				'min'         => 0,
				'max'         => 100000,
				'step'        => 1,
				'default'        => 0,
				'condition' => [
					'box_animation!' => '',
				]
			]
		);

		$this->end_controls_section();

	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();
		if($settings['box_animation']){
			$box_animation = 'wow'.' ' . $settings['box_animation'];
			$box_animation_duration = $settings['box_animation_duration'];
			$box_animation_delay = ' data-wow-delay="'.$settings['box_animation_delay'].'ms"';
		}else{
			$box_animation ='';
			$box_animation_duration ='';
			$box_animation_delay ='';
		}
		?>
		<div class="td-contact-and-subscribe-wrapper <?php echo $box_animation;?>" <?php echo $box_animation_duration . $box_animation_delay;?>>
		    <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="td-contact-wrapper">
                            <h3 class="td-contact-title"><?php echo $settings['contact_title'];?></h3>

                            <?php echo $settings['desc']?>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="td-subscribe-wrapper">
                            <h3 class="td-subscribe-title"><?php echo $settings['form_title'];?></h3>
                            <div class="td-subscribe-form">
                                <?php echo do_shortcode( esc_html($settings['subscribe_form']));?>
                            </div>
                        </div>

                    </div>
                </div>
			</div>
		</div>
		<?php

	}
}

Plugin::instance()->widgets_manager->register( new ThemeDraft_Contact_And_Subscribe_Widget );