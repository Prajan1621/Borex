<?php

namespace Elementor;

use Themedraft_Gradient_Color;

class ThemeDraft_Projects_Widget extends Widget_Base {

	public function get_name() {

		return 'themedraft_projects';
	}

	public function get_title() {
		return esc_html__( 'Projects', 'themedraft-core' );
	}

	public function get_icon() {

		return 'eicon-gallery-grid';
	}

	public function get_categories() {
		return [ 'themedraft_elements' ];
	}


	protected function register_controls() {

		//Content tab start
		$this->start_controls_section(
			'projects_settings',
			[
				'label' => esc_html__( 'Projects', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'subtitle',
			[
				'label'       => __( 'Subtitle', 'themedraft-core' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Business Strategy', 'themedraft-core' ),
				'label_block' => true,
			]
		);

		$repeater->add_control(
		    'title',
		    [
		        'label'       => __( 'Title', 'themedraft-core' ),
		        'label_block'       => true,
		        'type'        => Controls_Manager::TEXT,
		        'default'     => __( 'Home & Car loan', 'themedraft-core' ),
		    ]
		);

		$repeater->add_control(
			'image',
			[
				'label'       => __( 'Image', 'themedraft-core' ),
				'description'       => __( 'Use 450 by 350 pixels for better user experience.', 'themedraft-core' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
				'default'     => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);

		$repeater->add_control(
		    'details',
		    [
		        'label'         => __( 'Details Url', 'themedraft-core' ),
		        'type'          => Controls_Manager::URL,
		        'placeholder'   => __( 'https://your-link.com', 'themedraft-core' ),
		        'show_external' => true,
		        'default'       => [
		            'url'         => '',
		            'is_external' => false,
		            'nofollow'    => false,
		        ],
		    ]
		);

		$repeater->add_control(
			'box_animation',
			[
				'label' => __( 'Entrance Animation', 'themedraft-core' ),
				'type' => Controls_Manager::ANIMATION,
				'separator' => 'before',
			]
		);

		$repeater->add_control(
			'box_animation_duration',
			[
				'label'     => __( 'Animation Duration', 'themedraft-core' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'data-wow-duration="1.25s"',
				'options'   => [
					'data-wow-duration="2s"'    => __( 'Slow', 'themedraft-core' ),
					'data-wow-duration="1.25s"' => __( 'Normal', 'themedraft-core' ),
					'data-wow-duration=".75s"'  => __( 'Fast', 'themedraft-core' ),
				],
				'condition' => [
					'box_animation!' => '',
				]
			]
		);

		$repeater->add_control(
			'box_animation_delay',
			[
				'label'       => esc_html__('Animation Delay (ms)', 'themedraft-core'),
				'type'        => Controls_Manager::NUMBER,
				'min'         => 0,
				'max'         => 100000,
				'step'        => 1,
				'default'        => 0,
				'condition' => [
					'box_animation!' => '',
				]
			]
		);


		$this->add_control(
			'projects',
			[
				'label'       => __( 'Projects List', 'themedraft-core' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'subtitle' => __( 'Business Strategy', 'themedraft-core' ),
						'title'    => __( 'Home & Car loan', 'themedraft-core' ),
					],
				],
				'title_field' => '{{{ title }}}',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'project_column_settings',
			[
				'label' => esc_html__( 'Column', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'desktop_col',
			[
				'label'   => __( 'Column On Desktop', 'themedraft-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'col-lg-4',
				'options' => [
					'col-lg-12' => __( '1 Column', 'themedraft-core' ),
					'col-lg-6'  => __( '2 Column', 'themedraft-core' ),
					'col-lg-4'  => __( '3 Column', 'themedraft-core' ),
					'col-lg-3'  => __( '4 Column', 'themedraft-core' ),
				],
			]
		);

		$this->add_control(
			'tab_col',
			[
				'label'   => __( 'Column On Tablet', 'themedraft-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'col-md-6',
				'options' => [
					'col-md-12' => __( '1 Column', 'themedraft-core' ),
					'col-md-6'  => __( '2 Column', 'themedraft-core' ),
					'col-md-4'  => __( '3 Column', 'themedraft-core' ),
					'col-md-3'  => __( '4 Column', 'themedraft-core' ),
				],
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'project_title_style',
			[
				'label' => esc_html__( 'Title', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typo',
				'label' => __( 'Typography', 'themedraft-core' ),
				'selector' => '{{WRAPPER}} .td-project-content .td-title',
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'       => esc_html__('Title Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-project-content .td-title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'project_box_subtitle_style',
			[
				'label' => esc_html__( 'Subtitle', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'subtitle_typo',
				'label' => __( 'Typography', 'themedraft-core' ),
				'selector' => '{{WRAPPER}} .td-project-content .td-subtitle',
			]
		);

		$this->add_group_control(
		    Themedraft_Gradient_Color::get_type(),
		    [
		        'name' => 'subtitle_color',
		        'selector' => '{{WRAPPER}} .td-project-content .td-subtitle',
		    ]
		);

		$this->add_control(
		    'left_line',
		    [
		        'label'       => esc_html__('Left Border Color', 'themedraft-core'),
		        'type'        => Controls_Manager::COLOR,
		        'selectors'   => [
		            '{{WRAPPER}} .td-project-content .td-subtitle:before' => 'background-color: {{VALUE}};',
		        ],
		    ]
		);

		$this->end_controls_section();
	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();

		$item_col = $settings['desktop_col'] . ' '. $settings['tab_col'];
		?>
		<div class="td-project-wrapper">

				<div class="row">

					<?php if($settings['projects']){
						foreach ($settings['projects'] as $project){
						    $target   = $project['details']['is_external'] ? ' target="_blank"' : '';
						    $nofollow = $project['details']['nofollow'] ? ' rel="nofollow"' : '';

							if($project['box_animation']){
								$box_animation = 'wow'.' ' . $project['box_animation'];
								$box_animation_duration = $project['box_animation_duration'];
								$box_animation_delay = ' data-wow-delay="'.$project['box_animation_delay'].'ms"';
							}else{
								$box_animation ='';
								$box_animation_duration ='';
								$box_animation_delay ='';
							}
						    ?>
							<div class="<?php echo $item_col;?>">
								<div class="td-single-project-item <?php echo $box_animation;?>" <?php echo $box_animation_duration . $box_animation_delay;?>>

                                    <img src="<?php echo $project['image']['url'];?>" alt="<?php echo get_post_meta( $project['image']['id'], '_wp_attachment_image_alt', true ); ?>">

                                    <div class="td-project-content-wrapper">
                                        <a href="<?php echo $project['details']['url'];?>" class="td-project-details-link" <?php echo $target . $nofollow;?>>
                                            <div class="td-project-content">
                                                <h6 class="td-subtitle"><?php echo $project['subtitle'];?></h6>
                                                <h4 class="td-title"><?php echo nl2br($project['title']);?></h4>
                                            </div>
                                        </a>
                                    </div>
								</div>
							</div>
							<?php

						}
					} ?>


				</div>
		</div>
		<?php

	}
}

Plugin::instance()->widgets_manager->register( new ThemeDraft_Projects_Widget );