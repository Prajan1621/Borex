<?php
namespace Elementor;

class ThemeDraft_Popup_Video_Widget extends Widget_Base {

	public function get_name() {

		return 'themedraft_popup_video';
	}

	public function get_title() {
		return esc_html__( 'Popup Video', 'themedraft-core' );
	}

	public function get_icon() {

		return 'eicon-youtube';
	}

	public function get_categories() {
		return [ 'themedraft_elements' ];
	}


	protected function register_controls() {

		//Content tab start
		$this->start_controls_section(
			'popup_video_settings',
			[
				'label' => esc_html__( 'Popup Video', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
		    'image',
		    [
		        'label'       => __( 'Image', 'themedraft-core' ),
		        'type'        => Controls_Manager::MEDIA,
		        'label_block' => true,
		        'default'     => [
		            'url' => Utils::get_placeholder_image_src(),
		        ],
		    ]
		);

		$this->add_control(
		    'btn_text',
		    [
		        'label'       => __( 'Button Text', 'themedraft-core' ),
		        'label_block'       => true,
		        'type'        => Controls_Manager::TEXT,
		        'default'     => __( 'Play Video', 'themedraft-core' ),
		    ]
		);

		$this->add_control(
		    'video_url',
		    [
		        'label'       => __( 'Video Url', 'themedraft-core' ),
		        'label_block'       => true,
		        'type'        => Controls_Manager::TEXT,
		        'default'     => __( 'https://vimeo.com/280293143', 'themedraft-core' ),
		    ]
		);

		$this->add_responsive_control(
		    'video_height',
		    [
		        'label' => __( 'Height', 'themedraft-core' ),
		        'type' => Controls_Manager::SLIDER,
		        'size_units' => ['px'],
		        'range' => [
		            'px' => [
		                'min' => 200,
		                'max' => 1000,
		            ],
		        ],
		        'devices' => [ 'desktop', 'tablet', 'mobile' ],
		        'selectors' => [
		            '{{WRAPPER}} .td-popup-video-wrapper' => 'Height: {{SIZE}}px;',
		        ],
		    ]
		);

		$this->add_control(
		    'position_toggle',
		    [
		        'label'        => __( 'Position', 'themedraft-core' ),
		        'type'         => Controls_Manager::POPOVER_TOGGLE,
		        'label_off'    => __( 'None', 'themedraft-core' ),
		        'label_on'     => __( 'Custom', 'themedraft-core' ),
		        'return_value' => 'yes',
		    ]
		);

		$this->start_popover();

		$this->add_responsive_control(
		    'vertical_position',
		    [
		        'label'      => __( 'Vertical', 'themedraft-core' ),
		        'type'       => Controls_Manager::SLIDER,
		        'size_units' => [ 'px' ],
		        'range'      => [
		            'px' => [
		                'min' => - 1000,
		                'max' => 1000,
		            ],
		        ],
		        'selectors'  => [
		            '{{WRAPPER}} .popup-video-button-wrapper' => 'top: {{SIZE}}{{UNIT}};',
		        ],
		        'condition'  => [
		            'position_toggle' => 'yes',
		        ]
		    ]
		);

		$this->add_responsive_control(
		    'horizontal_position',
		    [
		        'label'      => __( 'Horizontal', 'themedraft-core' ),
		        'type'       => Controls_Manager::SLIDER,
		        'size_units' => [ 'px' ],
		        'range'      => [
		            'px' => [
		                'min' => - 1000,
		                'max' => 1000,
		            ],
		        ],
		        'selectors'  => [
		            '{{WRAPPER}} .popup-video-button-wrapper' => 'right: {{SIZE}}{{UNIT}};',
		        ],
		        'condition'  => [
		            'position_toggle' => 'yes',
		        ]
		    ]
		);
		$this->end_popover();

		$this->add_control(
			'box_animation',
			[
				'label' => __( 'Entrance Animation', 'themedraft-core' ),
				'type' => Controls_Manager::ANIMATION,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'box_animation_duration',
			[
				'label'     => __( 'Animation Duration', 'themedraft-core' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'data-wow-duration="1.25s"',
				'options'   => [
					'data-wow-duration="2s"'    => __( 'Slow', 'themedraft-core' ),
					'data-wow-duration="1.25s"' => __( 'Normal', 'themedraft-core' ),
					'data-wow-duration=".75s"'  => __( 'Fast', 'themedraft-core' ),
				],
				'condition' => [
					'box_animation!' => '',
				]
			]
		);

		$this->add_control(
			'box_animation_delay',
			[
				'label'       => esc_html__('Animation Delay (ms)', 'themedraft-core'),
				'type'        => Controls_Manager::NUMBER,
				'min'         => 0,
				'max'         => 100000,
				'step'        => 1,
				'default'        => 0,
				'condition' => [
					'box_animation!' => '',
				]
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
		    'video_popup_style',
		    [
		        'label' => esc_html__( 'Colors', 'themedraft-core' ),
		        'tab'   => Controls_Manager::TAB_STYLE,
		    ]
		);

		$this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
		        'name' => 'button_wrapper_background',
		        'label' => esc_html__( 'Background', 'themedraft-core' ),
		        'types' => [ 'classic', 'gradient' ],
		        'selector' => '{{WRAPPER}} .popup-video-button-wrapper',
                'exclude' => [
                        'image'
                ],
		    ]
		);

		$this->add_control(
		    'button_bg_color',
		    [
		        'label'       => esc_html__('Button Background Color', 'themedraft-core'),
		        'type'        => Controls_Manager::COLOR,
		        'selectors'   => [
		            '{{WRAPPER}} .popup-video-button-wrapper a' => 'background-color: {{VALUE}};',
		        ],
		    ]
		);

		$this->add_control(
		    'text_color',
		    [
		        'label'       => esc_html__('Text Color', 'themedraft-core'),
		        'type'        => Controls_Manager::COLOR,
		        'selectors'   => [
		            '{{WRAPPER}} .video-button-text' => 'color: {{VALUE}};',
		        ],
		    ]
		);

		$this->end_controls_section();

	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();
		if($settings['box_animation']){
			$box_animation = 'wow'.' ' . $settings['box_animation'];
			$box_animation_duration = $settings['box_animation_duration'];
			$box_animation_delay = ' data-wow-delay="'.$settings['box_animation_delay'].'ms"';
		}else{
			$box_animation ='';
			$box_animation_duration ='';
			$box_animation_delay ='';
		}
		?>

		<div class="td-popup-video-wrapper td-cover-bg <?php echo $box_animation;?>" <?php echo $box_animation_duration . $box_animation_delay;?> style="background-image: url(<?php echo esc_url($settings['image']['url']);?>)">
			<div class="popup-video-button-wrapper">
				<a href="<?php echo esc_url($settings['video_url']);?>" class="td-popup-video mfp-iframe">
					<i class="fa fa-play"></i>
				</a>
				<span class="video-button-text"><?php echo $settings['btn_text'];?></span>
			</div>
		</div>

		<?php

	}
}

Plugin::instance()->widgets_manager->register( new ThemeDraft_Popup_Video_Widget );