<?php
namespace Elementor;

class Themedraft_Accordion_Widget extends Widget_Base{

	public function get_name(){

		return "themedraft_accordion";
	}
	public function get_title(){
		return esc_html__("Accordion","themedraft-core");
	}
	public function get_icon() {

		return "eicon-accordion";
	}
	public function get_categories() {
		return [ 'themedraft_elements' ];
	}


	protected function register_controls(){
		$this->start_controls_section(
			'accordion_content_options',
			[
				'label' => esc_html__( 'Accordion', 'themedraft-core' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'main_title',
			[
				'label'       => __( 'Main Title', 'themedraft-core' ),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 5,
				'default'     => __( 'Most Asked Question.', 'themedraft-core' ),
			]
		);

		$this->add_control(
			'desc',
			[
				'label'       => __( 'Description', 'themedraft-core' ),
				'type'        => Controls_Manager::WYSIWYG,
				'default'     => __( 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt labore.', 'themedraft-core' ),
				'label_block' => true,
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'accordion_title',
			[
				'label'       => esc_html__( 'Accordion Title', 'themedraft-core' ),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 5,
				'default' => esc_html__( 'Accordion Title Here' , 'themedraft-core' ),
				'placeholder' => esc_html__( 'Type Accordion Title Here', 'themedraft-core' ),
			]
		);

		$repeater->add_control(
			'accordion_content', [
				'label' => esc_html__( 'Accordion Content', 'themedraft-core' ),
				'type' => Controls_Manager::WYSIWYG,
				'default' => esc_html__( 'Accordion content here' , 'themedraft-core' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'accordion_list',
			[
				'label' => __( 'Accordion Lists', 'themedraft-core' ),
				'type' => Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'list_title' => esc_html__( 'Accordion Title Here', 'themedraft-core' ),
					],
				],
				'title_field' => '{{{ accordion_title }}}',
			]
		);

		$this->add_control(
			'open_by_default',
			[
				'label'       => esc_html__('Open By Default', 'themedraft-core'),
				'type'        => Controls_Manager::NUMBER,
				'min'         => 1,
				'max'         => 1000,
				'step'        => 1,
				'default'     => 1,
				'separator'     => 'before',
				'description' => esc_html__('Which accordion you want to open by default.', 'themedraft-core'),
			]
		);

		$this->add_control(
			'show_accordion_number',
			[
				'label'     => esc_html__( 'Show Number', 'themedraft-core' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_on'  => esc_html__( 'Yes', 'themedraft-core' ),
				'label_off' => esc_html__( 'No', 'themedraft-core' ),
				'default'   => 'yes',
			]
		);

		$this->end_controls_section();

	}

	//Render In HTML
	protected function render() {
		$settings = $this->get_settings_for_display();
		?>
        <div class="td-accordion-wrapper">
			<?php if($settings['main_title']) : ?>
                <h3 class="td-accordion-title"><?php echo $settings['main_title'];?></h3>
			<?php endif;?>

			<?php if($settings['desc']) : ?>
                <div class="td-accordion-desc">
					<?php echo $settings['desc'];?>
                </div>
			<?php endif;?>

            <div class="accordion" id="td-accordion">

				<?php
				if($settings['accordion_list']){
					$i = 0;
					foreach($settings['accordion_list'] as $accordionItem){
						$i++;

						if ($i < 10){
							$numb = '0' . $i;
						}else{
							$numb =  $i;
						}

						if($i == $settings['open_by_default']){
							$active = 'active';
							$show = 'show';
							$open = 'true';
						}else{
							$active = '';
							$show = '';
							$open = 'false';
						}

						?>
                        <div class="card">
                            <div class="card-header <?php echo $active;?>">
                                <h2 class="card-title">
                                    <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapse-<?php echo $i;?>" aria-expanded="<?php echo $open;?>">
										<?php
										if($settings['show_accordion_number'] == 'yes'){
											echo $numb .'. ' .$accordionItem['accordion_title'];
										}else{
											echo $accordionItem['accordion_title'];
										}
										?>
                                    </button>
                                </h2>
                            </div>

                            <div id="collapse-<?php echo $i;?>" class="collapse <?php echo $show ?>" data-parent="#td-accordion">
                                <div class="card-body">
									<?php echo wp_kses_post( $accordionItem['accordion_content']) ?>
                                </div>
                            </div>
                        </div>
						<?php
					}
				}
				?>
            </div>
        </div>

        <script>
            (function ($) {
                "use strict";
                jQuery(document).ready(function($){
                    $(".td-accordion-wrapper .card-header").on("click", function () {
                        if ($(this).hasClass("active")){
                            $(this).removeClass("active");
                        }else{
                            $(".td-accordion-wrapper .card-header").removeClass("active");
                            $(this).addClass("active");
                        }
                    });
                });
            }(jQuery));
        </script>
		<?php
	}

	//Template
	protected function content_template() { ?>
        <div class="td-accordion-wrapper">
            <# if ( settings.main_title ) { #>
            <h3 class="td-accordion-title">{{{settings.main_title}}}</h3>
            <# } #>

            <# if ( settings.desc ) { #>
            <div class="td-accordion-desc">{{{settings.desc}}}</div>
            <# } #>
            <div class="accordion" id="td-accordion">

                <# if ( settings.accordion_list.length ) { $i = 0; #>
                <# _.each( settings.accordion_list, function( accordionItem ) { $i++ #>
                <# if($i == settings.open_by_default){
                $active = 'active';
                $show = 'show';
                $open = 'true';
                }else{
                $active = '';
                $show = '';
                $open = 'false';
                } #>

                <div class="card">
                    <div class="card-header {{{$active}}}">
                        <h2 class="card-title">
                            <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapse-{{{$i}}}" aria-expanded="{{{$open}}}">
                                <# if(settings.show_accordion_number == "yes"){ #>
                                <# if($i < 10 ) { #> 0<# } #>{{{$i}}}. {{{accordionItem.accordion_title}}}
                                <# }else{ #>
                                {{{accordionItem.accordion_title}}}
                                <# } #>
                            </button>
                        </h2>
                    </div>

                    <div id="collapse-{{{$i}}}" class="collapse {{{$show}}}" data-parent="#td-accordion">
                        <div class="card-body">
                            {{{accordionItem.accordion_content}}}
                        </div>
                    </div>
                </div>

                <# }); #>
                <# } #>
            </div>
        </div>

        <script>
            (function ($) {
                "use strict";
                jQuery(document).ready(function($){
                    $(".td-accordion-wrapper .card-header").on("click", function () {
                        if ($(this).hasClass("active")){
                            $(this).removeClass("active");
                        }else{
                            $(".td-accordion-wrapper .card-header").removeClass("active");
                            $(this).addClass("active");
                        }
                    });
                });
            }(jQuery));
        </script>

		<?php
	}
}
Plugin::instance()->widgets_manager->register( new Themedraft_Accordion_Widget );