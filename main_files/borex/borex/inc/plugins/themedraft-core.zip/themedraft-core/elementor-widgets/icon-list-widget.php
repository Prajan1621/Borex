<?php
namespace Elementor;

class ThemeDraft_Icon_List_Widget extends Widget_Base {

	public function get_name() {

		return 'themedraft_icon_list';
	}

	public function get_title() {
		return esc_html__( 'Icon List', 'themedraft-core' );
	}

	public function get_icon() {

		return 'eicon-bullet-list';
	}

	public function get_categories() {
		return [ 'themedraft_elements' ];
	}


	protected function register_controls() {

		//Content tab start
		$this->start_controls_section(
			'icon_list_settings',
			[
				'label' => esc_html__( 'List', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
		    'list_layout',
		    [
		        'label'       => esc_html__('Layout', 'themedraft-core'),
		        'type'        => Controls_Manager::CHOOSE,
		        'label_block' => false,

		        'options' => [
		            'default_layout' => [
		                'title' => __('Default', 'themedraft-core'),
		                'icon'  => 'eicon-editor-list-ul',
		            ],

		            'inline_layout' => [
		                'title' => __('Inline', 'themedraft-core'),
		                'icon'  => 'eicon-ellipsis-h',
		            ],

		        ],
		    ]
		);

		$repeater = new Repeater();

		$repeater->add_control(
		    'text',
		    [
		        'label'       => __('Text', 'themedraft-core'),
		        'type'        => Controls_Manager::TEXT,
		        'default'     => __('List Item Text', 'themedraft-core'),
		        'label_block' => true,
		    ]
		);


		$repeater->add_control(
		    'selected_icon',
		    [
		        'label'       => __('Icon', 'themedraft-core'),
		        'type'             => Controls_Manager::ICONS,
		        'fa4compatibility' => 'icon',
		        'label_block'      => true,
		        'default'          => [
		            'value'   => 'far fa-dot-circle',
		            'library' => 'regular',
		        ],
		    ]
		);

		$repeater->add_control(
		    'item_link',
		    [
		        'label'         => __( 'Link', 'themedraft-core' ),
		        'type'          => Controls_Manager::URL,
		        'placeholder'   => __( 'https://your-link.com', 'themedraft-core' ),
		        'show_external' => true,
		        'default'       => [
		            'url'         => '',
		            'is_external' => false,
		            'nofollow'    => false,
		        ],
		    ]
		);

		$this->add_control(
		    'list_items',
		    [
		        'label'       => __('List', 'themedraft-core'),
		        'type'        => Controls_Manager::REPEATER,
		        'fields'      => $repeater->get_controls(),
		        'default'     => [
		            [
		                'text'        => __('List Item Text', 'themedraft-core'),
                    ],
		        ],
		        'title_field' => '{{{ text }}}',
		    ]
		);

		$this->end_controls_section();

		$this->start_controls_section(
		    'td_icon_list_list_style',
		    [
		        'label' => esc_html__( 'List', 'themedraft-core' ),
		        'tab'   => Controls_Manager::TAB_STYLE,
		    ]
		);

		$this->add_responsive_control(
		    'space_between',
		    [
		        'label' => __( 'Space Between', 'themedraft-core' ),
		        'type' => Controls_Manager::SLIDER,
		        'size_units' => ['px'],
		        'range' => [
		            'px' => [
		                'min' => 0,
		                'max' => 100,
		            ],
		        ],
		        'devices' => [ 'desktop', 'tablet', 'mobile' ],

		        'selectors' => [
		            '{{WRAPPER}} .td-icon-list-wrapper .td-list-default-layout li' => 'margin-bottom: {{SIZE}}{{UNIT}};',
		            '{{WRAPPER}} .td-icon-list-wrapper .td-list-inline-layout li' => 'margin-right: {{SIZE}}{{UNIT}};',
		        ],
		    ]
		);

		$this->add_responsive_control(
		    'wrapper_margin',
		    [
		        'label'      => esc_html__( 'List Wrapper Margin', 'themedraft-core' ),
		        'type'       => Controls_Manager::DIMENSIONS,
		        'size_units' => [ 'px', '%', 'em' ],
		        'selectors'  => [
		            '{{WRAPPER}} .td-icon-list-wrapper' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
		        ],
		    ]
		);

		$this->end_controls_section();

		$this->start_controls_section(
		    'td_icon_list_icon_style',
		    [
		        'label' => esc_html__( 'Icon', 'themedraft-core' ),
		        'tab'   => Controls_Manager::TAB_STYLE,
		    ]
		);

		$this->add_control(
		    'icon_default_color',
		    [
		        'label'       => esc_html__('Color', 'themedraft-core'),
		        'type'        => Controls_Manager::COLOR,
		        'selectors'   => [
		            '{{WRAPPER}} .td-icon-list-icon' => 'color: {{VALUE}};',
		        ],
		    ]
		);

		$this->add_control(
			'icon_hover_color',
			[
				'label'       => esc_html__('Hover Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-icon-list-item:hover .td-icon-list-icon' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'icon_size',
			[
				'label' => __( 'Icon Size', 'themedraft-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range' => [
					'px' => [
						'min' => 16,
						'max' => 100,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],

				'selectors' => [
					'{{WRAPPER}} .td-icon-list-icon' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
		    'td_icon_list_text_style',
		    [
		        'label' => esc_html__( 'Text', 'themedraft-core' ),
		        'tab'   => Controls_Manager::TAB_STYLE,
		    ]
		);

		$this->add_group_control(
		    Group_Control_Typography::get_type(),
		    [
		        'name' => 'text_typo',
		        'label' => __( 'Typography', 'themedraft-core' ),
		        'selector' => '{{WRAPPER}} .td-icon-list-text',
		    ]
		);

		$this->add_control(
			'text_color',
			[
				'label'       => esc_html__('Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-icon-list-text' => 'color: {{VALUE}};',
					'{{WRAPPER}} .td-icon-list-text a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'text_hover_color',
			[
				'label'       => esc_html__('Hover Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-icon-list-text a:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'space_from_icon',
			[
				'label' => __( 'Space From Icon', 'themedraft-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],

				'selectors' => [
					'{{WRAPPER}} .td-icon-list-text' => 'padding-left: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();

		if($settings['list_layout'] == 'inline_layout' ){
			$list_layout = 'td-list-inline-layout';
		}else{
			$list_layout = 'td-list-default-layout';
		}
		?>

		<div class="td-icon-list-wrapper">
			<ul class="td-list-style <?php echo $list_layout;?>">
                <?php
                    if($settings['list_items']){
	                    foreach ($settings['list_items'] as $list_item){ ?>
                            <li class="td-icon-list-item">
                                <span class="td-icon-list-icon">
	                                <?php ThemeDraft_Custom_Icon_Render( $list_item, 'icon', 'selected_icon' ); ?>
                                </span>
	                            <span class="td-icon-list-text">
	                            <?php if(!empty($list_item['item_link']['url'])) :
                                    $target   = $list_item['item_link']['is_external'] ? ' target="_blank"' : '';
                                    $nofollow = $list_item['item_link']['nofollow'] ? ' rel="nofollow"' : '';
                                ?>
                                <a href="<?php echo $list_item['item_link']['url'];?>" <?php echo $target . $nofollow;?>>
                                <?php endif;?>
	                                <?php echo $list_item['text'];?>
		                        <?php if(!empty($list_item['item_link']['url'])) : ?>
                                </a>
                                <?php endif;?>
                                </span>
                            </li>
                        <?php
                        }
                    }
                ?>
			</ul>
		</div>
		<?php
	}
}

Plugin::instance()->widgets_manager->register( new ThemeDraft_Icon_List_Widget );