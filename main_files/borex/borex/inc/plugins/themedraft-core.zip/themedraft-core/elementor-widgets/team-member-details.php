<?php
namespace Elementor;

class ThemeDraft_Team_Member_Info_Widget extends Widget_Base {

	public function get_name() {

		return 'themedraft_team_member_info';
	}

	public function get_title() {
		return esc_html__( 'Team Member Info', 'themedraft-core' );
	}

	public function get_icon() {

		return 'flaticon-business-professions-and-jobs';
	}

	public function get_categories() {
		return [ 'themedraft_elements' ];
	}


	protected function register_controls() {

		//Content tab start
		$this->start_controls_section(
			'member_info_settings',
			[
				'label' => esc_html__( 'Member Info', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'member_name',
			[
				'label'       => __( 'Member Name', 'themedraft-core' ),
				'label_block'       => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Md Nadim Khan', 'themedraft-core' ),
			]
		);

		$this->add_control(
			'member_image',
			[
				'label'       => __( 'Member Image', 'themedraft-core' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
				'default'     => [
					'url' => Utils::get_placeholder_image_src(),
				],
				'description' => __('Use 370 x 400 size image for better user experience', 'themedraft-core'),
			]
		);

		$this->add_control(
			'member_details',
			[
				'label'       => __( '', 'themedraft-core' ),
				'type'        => Controls_Manager::WYSIWYG,
				'default'     => __( '<ul>
                                <li><strong>Designation</strong>Senior Manager</li>
                                <li><strong>Expertise</strong>Planning, Strategy</li>
                                <li><strong>Experience</strong>25+ Years</li>
                            </ul>
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusm dolore mag na the aliqua
                            veniam, quis nostrud exercit ex ea commodo consequat. Duis aute irure dolor inn reprehenderit
                            occaecat cupidatat non proident. Lorem ipsum dolor sit amiet, conisectet adipiscing elit seda
                            veniam nostrud commodo.', 'themedraft-core' ),
				'description' => __( 'Use Unordered list, Bold/Strong tag and paragraph.', 'themedraft-core' ),
				'label_block' => true,
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'member_social_options',
			[
				'label' => esc_html__( 'Social Icons', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'site_name',
			[
				'label'       => __('Site Name', 'themedraft-core'),
				'type'        => Controls_Manager::TEXT,
				'default'     => __('Facebook', 'themedraft-core'),
				'label_block' => true,
				'description' => __('This field is optional.', 'themedraft-core'),
			]
		);


		$repeater->add_control(
			'selected_icon',
			[
				'label'       => __( 'Select Icon', 'themedraft-core' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'label_block'      => true,
				'default'          => [
					'value'   => 'fab fa-facebook-f',
					'library' => 'brands',
				],
			]
		);

		$repeater->add_control(
			'profile',
			[
				'label'         => __( 'Profile Url', 'themedraft-core' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => __( 'https://your-link.com', 'themedraft-core' ),
				'show_external' => true,
				'default'       => [
					'url'         => '#',
					'is_external' => true,
					'nofollow'    => false,
				],
			]
		);


		$this->add_control(
			'socials',
			[
				'label'       => __('Icon List', 'themedraft-core'),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'site_name'        => __('Facebook', 'themedraft-core'),
					],
				],
				'title_field' => '{{{ site_name }}}',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'member_image_options',
			[
				'label' => esc_html__( 'Image', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'image_shape_color',
			[
				'label'       => esc_html__('Shape Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-member-details-info-wrapper .td-member-image-shape' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'border_color',
			[
				'label'       => esc_html__('Border Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-member-details-info-wrapper .td-member-image' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'title_and_text',
			[
				'label' => esc_html__( 'Title & Text', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'       => esc_html__('Title Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-member-name' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'text_color',
			[
				'label'       => esc_html__('Text Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-member-details-info-wrapper .td-quick-info' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'bold_text_color',
			[
				'label'       => esc_html__('Bold Text Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-member-details-info-wrapper .td-quick-info ul li strong' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'social_icons',
			[
				'label' => esc_html__( 'Social', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'icon_color',
			[
				'label'       => esc_html__('Icon Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-member-details-info-wrapper .td-member-social-info a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'icon_border_color',
			[
				'label'       => esc_html__('Icon Border Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-member-details-info-wrapper .td-member-social-info a' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'icon_color_on_hover',
			[
				'label'       => esc_html__('Icon Color On Hover', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-member-details-info-wrapper .td-member-social-info a:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'icon_border_color_on_hover',
			[
				'label'       => esc_html__('Icon Border Color On Hover', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-member-details-info-wrapper .td-member-social-info a:hover' => 'background-color: {{VALUE}};border-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();
	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();
		?>

		<div class="td-member-details-info-wrapper">
			<div class="row">
				<div class="col-lg-12 td-member-details-info-col">
					<div class="td-member-photo-and-social">
						<div class="td-member-image-shape"></div>
						<div class="td-member-image">
							<img src="<?php echo esc_url( $settings['member_image']['url']);?>" alt="<?php echo get_post_meta( $settings['member_image']['id'], '_wp_attachment_image_alt', true ); ?>">

						</div>

						<div class="td-member-social-info">
							<ul class="td-list-style td-list-inline">
								<?php if($settings['socials']){
									foreach ($settings['socials'] as $social){
										$target   = $social['profile']['is_external'] ? ' target="_blank"' : '';
										$nofollow = $social['profile']['nofollow'] ? ' rel="nofollow"' : '';
										?>
										<li>
											<a href="<?php echo $social['profile']['url'];?>" <?php echo $target . $nofollow;?>>
												<?php themedraft_custom_icon_render( $social, 'icon', 'selected_icon' ); ?>
											</a>
										</li>
										<?php

									}
								}?>


							</ul>
						</div>
					</div>

					<div class="td-member-details-wrapper">
						<h3 class="td-member-name"><?php echo $settings['member_name'];?></h3>
						<div class="td-quick-info">
							<?php echo $settings['member_details'];?>
						</div>
					</div>
				</div>
			</div>
		</div>

		<?php

	}
}

Plugin::instance()->widgets_manager->register( new ThemeDraft_Team_Member_Info_Widget );