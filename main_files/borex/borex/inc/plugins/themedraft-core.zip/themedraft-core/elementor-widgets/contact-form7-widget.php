<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // If this file is called directly, abort.

class ThemeDraft_ContactForm7_Widget extends Widget_Base {

	public function get_name() {
		return 'themedraft_contact_form_seven';
	}

	public function get_title() {
		return __( 'Contact Form7', 'themedraft-core' );
	}

	public function get_icon() {
		return 'eicon-mail';
	}
	public function get_categories() {
		return array( 'themedraft_elements' );
	}


	protected function register_controls() {


		$this->start_controls_section(
			'contact_form_accordion',
			[
				'label' => __( 'Contact Form', 'themedraft-core' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
		    'form_title',
		    [
		        'label'       => __( 'Form Title', 'themedraft-core' ),
		        'type'        => Controls_Manager::TEXTAREA,
		        'rows'        => 5,
		        'default'     => __( 'Get In Touch', 'themedraft-core' ),
		        'placeholder' => __( '', 'themedraft-core' ),
		    ]
		);

		$this->add_control(
			'desc',
			[
				'label'       => __( 'Description', 'themedraft-core' ),
				'type'        => Controls_Manager::WYSIWYG,
				'default'     => __( 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt labore.', 'themedraft-core' ),
				'label_block' => true,
			]
		);
		
		$this->add_control(
			'wpcf7_form_list',
			[
				'label' => __( 'Select Contact Form', 'themedraft-core' ),
				'label_block' => true,
				'type' => Controls_Manager::SELECT,
				'options' => $this->themedraft_contact_form(),
			]
		);

		$this->add_control(
			'td_extra_css_class',
			[
				'label' => esc_html__( 'Extra Css Classes', 'themedraft-core' ),
				'type' => Controls_Manager::TEXT,
				'description' => esc_html__( 'If you want to use extra css classes type class name here', 'themedraft-core' ),
				'label_block' => true,
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
		    'wrapper_style',
		    [
		        'label' => esc_html__( 'Wrapper', 'themedraft-core' ),
		        'tab'   => Controls_Manager::TAB_STYLE,
		    ]
		);

		$this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
		        'name' => 'background',
		        'label' => esc_html__( 'Background', 'themedraft-core' ),
		        'types' => [ 'classic', 'gradient'],
		        'selector' => '{{WRAPPER}} .themedraft-contact-form-container',
		    ]
		);

		$this->add_responsive_control(
		    'wrapper_padding',
		    [
		        'label'      => esc_html__( 'Wrapper Padding', 'themedraft-core' ),
		        'type'       => Controls_Manager::DIMENSIONS,
		        'size_units' => [ 'px', '%', 'em' ],
		        'selectors'  => [
		            '{{WRAPPER}} .themedraft-contact-form-container' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
		        ],
		    ]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'themedraft_contact_field_style',
			[
				'label' => __( 'Field Style', 'themedraft-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'field_bg_color',
			[
				'label'       => esc_html__('Field Background Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .themedraft-contact-form-container select' => 'background-color: {{VALUE}};',
					'{{WRAPPER}} .themedraft-contact-form-container input' => 'background-color: {{VALUE}};',
					'{{WRAPPER}} .themedraft-contact-form-container textarea' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'field_border_color',
			[
				'label'       => esc_html__('Field Border Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .themedraft-contact-form-container select' => 'border-color: {{VALUE}};',
					'{{WRAPPER}} .themedraft-contact-form-container input' => 'border-color: {{VALUE}};',
					'{{WRAPPER}} .themedraft-contact-form-container textarea' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'field_border_color_on_focus',
			[
				'label'       => esc_html__('Field Border Color On Focus', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .themedraft-contact-form-container select:focus' => 'border-color: {{VALUE}};',
					'{{WRAPPER}} .themedraft-contact-form-container input:focus' => 'border-color: {{VALUE}};',
					'{{WRAPPER}} .themedraft-contact-form-container textarea:focus' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'field_placeholder_color',
			[
				'label'       => esc_html__('Field Placeholder Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .themedraft-contact-form-container ::placeholder' => 'color: {{VALUE}};',
					'{{WRAPPER}} .themedraft-contact-form-container :-ms-input-placeholder' => 'color: {{VALUE}};',
					'{{WRAPPER}} .themedraft-contact-form-container ::-ms-input-placeholder' => 'color: {{VALUE}};',

				],
			]
		);

		$this->add_control(
			'field_text_color',
			[
				'label'       => esc_html__('Field Text Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .themedraft-contact-form-container select' => 'color: {{VALUE}};',
					'{{WRAPPER}} .themedraft-contact-form-container input' => 'color: {{VALUE}};',
					'{{WRAPPER}} .themedraft-contact-form-container textarea' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
		    'textarea_height',
		    [
		        'label' => __( 'Textarea Height', 'themedraft-core' ),
		        'type' => Controls_Manager::SLIDER,
		        'size_units' => ['px'],
		        'range' => [
		            'px' => [
		                'min' => 100,
		                'max' => 1000,
		            ],
		        ],
		        'devices' => [ 'desktop', 'tablet', 'mobile' ],
		        'selectors' => [
		            '{{WRAPPER}} .themedraft-contact-form-container textarea' => 'height: {{SIZE}}px;',
		        ],
		    ]
		);


		$this->end_controls_section();

		$this->start_controls_section(
			'themedraft_contact_submit_style',
			[
				'label' => __( 'Submit Button', 'themedraft-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		//Normal & hover option start
		$this->start_controls_tabs('td_btn_styles');

		//Normal style start
		$this->start_controls_tab(
			'btn_normal_style',
			[
				'label' => esc_html__('Normal', 'themedraft-core'),
			]
		);

		$this->add_control(
			'normal_txt_color',
			[
				'label'     => esc_html__('Text Color', 'themedraft-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .themedraft-contact-form-container input[type="submit"]' => 'color: {{VALUE}};',
					'{{WRAPPER}} .themedraft-contact-form-container button[type="submit"]' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'normal_bg_color',
				'label' => esc_html__( 'Background', 'themedraft-core' ),
				'types' => [ 'classic', 'gradient'],
				'selector' => '{{WRAPPER}} .themedraft-contact-form-container input[type="submit"],{{WRAPPER}} .themedraft-contact-form-container button[type="submit"]',
				'exclude' => [
					'image'
				]
			]
		);

		$this->end_controls_tab();
		//Normal style end

		//Hover style start
		$this->start_controls_tab(
			'btn_hover_style',
			[
				'label' => esc_html__('Hover', 'themedraft-core'),
			]
		);

		$this->add_control(
			'hover_txt_color',
			[
				'label'     => esc_html__('Text Color', 'themedraft-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .themedraft-contact-form-container input[type="submit"]:hover' => 'color: {{VALUE}};',
					'{{WRAPPER}} .themedraft-contact-form-container button[type="submit"]:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'hover_bg_color',
				'label' => esc_html__( 'Background', 'themedraft-core' ),
				'types' => [ 'classic', 'gradient'],
				'selector' => '{{WRAPPER}} .themedraft-contact-form-container input[type="submit"]:hover,{{WRAPPER}} .themedraft-contact-form-container button[type="submit"]:hover',
				'exclude' => [
					'image'
				]
			]
		);

		$this->add_control(
			'btn_hover_border_color',
			[
				'label'       => esc_html__('Border Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .themedraft-contact-form-container input[type="submit"]:hover:before,{{WRAPPER}} .themedraft-contact-form-container button[type="submit"]:hover:before' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();
		//Hover style end
		$this->end_controls_tabs();
		//Normal & hover option end

		$this->end_controls_section();

	}

	protected function themedraft_contact_form( ) {

		if ( ! class_exists( 'WPCF7_ContactForm' ) ) {
			return array();
		}

		$forms = \WPCF7_ContactForm::find( array(
			'orderby' => 'title',
			'order'   => 'ASC',
		) );

		if ( empty( $forms ) ) {
			return array();
		}

		$result = array();

		foreach ( $forms as $item ) {
			$key            = sprintf( '%1$s::%2$s', $item->id(), $item->title() );
			$result[ $key ] = $item->title();
		}

		return $result;
	}


	protected function render()  {

		$settings = $this->get_settings();

		if ( ! empty( $settings['wpcf7_form_list'] ) ) {?>

			<div class="themedraft-contact-form-container <?php echo $settings['td_extra_css_class'];?>">
                <h3 class="td-form-title"><?php echo $settings['form_title'];?></h3>

				<?php if($settings['desc']) : ?>
                    <div class="td-form-desc">
						<?php echo $settings['desc'];?>
                    </div>
				<?php endif;?>

				<?php echo do_shortcode( '[contact-form-7 id="' . $settings['wpcf7_form_list'] . '" ]' );?>
			</div>

			<?php
		}

	}
}

Plugin::instance()->widgets_manager->register( new ThemeDraft_ContactForm7_Widget );