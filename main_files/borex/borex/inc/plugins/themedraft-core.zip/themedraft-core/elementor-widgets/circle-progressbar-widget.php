<?php
namespace Elementor;

class ThemeDraft_Circle_Progress_Bar_Widget extends Widget_Base {

	public function get_name() {

		return 'themedraft_circle_progress_bar';
	}

	public function get_title() {
		return esc_html__( 'Circle Progress Bar', 'themedraft-core' );
	}

	public function get_icon() {

		return 'far fa-circle';
	}

	public function get_categories() {
		return [ 'themedraft_elements' ];
	}

	public function get_script_depends() {
		return ['circle-progress','counterup'];
	}


	protected function register_controls() {

		//Content tab start
		$this->start_controls_section(
			'circle_progress_bar_settings',
			[
				'label' => esc_html__( 'Circle Progress Bar', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'title',
			[
				'label'       => __('Title', 'themedraft-core'),
				'type'        => Controls_Manager::TEXT,
				'default'     => __('Projects Completed', 'themedraft-core'),
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'number',
			[
				'label'       => esc_html__('Percentage Number', 'themedraft-core'),
				'type'        => Controls_Manager::NUMBER,
				'min'         => 1,
				'max'         => 100,
				'step'        => 1,
				'default'     => 90,
			]
		);

		$repeater->add_control(
			'unit',
			[
				'label'       => __('Unit', 'themedraft-core'),
				'type'        => Controls_Manager::TEXT,
				'default'     => '%',
			]
		);

		$repeater->add_control(
			'border',
			[
				'label'     => esc_html__( 'Enable Border', 'themedraft-core' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_on'  => esc_html__( 'Yes', 'themedraft-core' ),
				'label_off' => esc_html__( 'No', 'themedraft-core' ),
				'default'   => 'yes',
			]
		);

		$repeater->add_control(
			'box_animation',
			[
				'label' => __( 'Entrance Animation', 'themedraft-core' ),
				'type' => Controls_Manager::ANIMATION,
				'separator' => 'before',
			]
		);

		$repeater->add_control(
			'box_animation_duration',
			[
				'label'     => __( 'Animation Duration', 'themedraft-core' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'data-wow-duration="1.25s"',
				'options'   => [
					'data-wow-duration="2s"'    => __( 'Slow', 'themedraft-core' ),
					'data-wow-duration="1.25s"' => __( 'Normal', 'themedraft-core' ),
					'data-wow-duration=".75s"'  => __( 'Fast', 'themedraft-core' ),
				],
				'condition' => [
					'box_animation!' => '',
				]
			]
		);

		$repeater->add_control(
			'box_animation_delay',
			[
				'label'       => esc_html__('Animation Delay (ms)', 'themedraft-core'),
				'type'        => Controls_Manager::NUMBER,
				'min'         => 0,
				'max'         => 100000,
				'step'        => 1,
				'default'        => 0,
				'condition' => [
					'box_animation!' => '',
				]
			]
		);

		$this->add_control(
			'progress_bars',
			[
				'label'       => __('Progress List', 'themedraft-core'),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'title'        => __('Projects Completed', 'themedraft-core'),
						'number'        => 90,
						'unit'        => '%',
					],
				],
				'title_field' => '{{{ title }}}',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'project_column_settings',
			[
				'label' => esc_html__( 'Column', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'desktop_col',
			[
				'label'   => __( 'Column On Desktop', 'themedraft-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'col-xl-3',
				'options' => [
					'col-xl-12' => __( '1 Column', 'themedraft-core' ),
					'col-xl-6'  => __( '2 Column', 'themedraft-core' ),
					'col-xl-4'  => __( '3 Column', 'themedraft-core' ),
					'col-xl-3'  => __( '4 Column', 'themedraft-core' ),
				],
			]
		);


		$this->add_control(
			'ipad_pro',
			[
				'label'   => __( 'Column On iPad Pro', 'themedraft-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'col-lg-3',
				'options' => [
					'col-lg-12' => __( '1 Column', 'themedraft-core' ),
					'col-lg-6'  => __( '2 Column', 'themedraft-core' ),
					'col-lg-4'  => __( '3 Column', 'themedraft-core' ),
					'col-lg-3'  => __( '4 Column', 'themedraft-core' ),
				],
			]
		);

		$this->add_control(
			'tab_col',
			[
				'label'   => __( 'Column On Tablet', 'themedraft-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'col-md-4',
				'options' => [
					'col-md-12' => __( '1 Column', 'themedraft-core' ),
					'col-md-6'  => __( '2 Column', 'themedraft-core' ),
					'col-md-4'  => __( '3 Column', 'themedraft-core' ),
					'col-md-3'  => __( '4 Column', 'themedraft-core' ),
				],
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'circle_box_style',
			[
				'label' => esc_html__( 'Style', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'background_color',
			[
				'label'       => esc_html__('Background Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'default'   => '#cbdced'
			]
		);

		$this->add_control(
			'fill_color_1',
			[
				'label'       => esc_html__('Fill Color One', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'default'   => '#428cd4'
			]
		);

		$this->add_control(
			'fill_color_2',
			[
				'label'       => esc_html__('Fill Color Two', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'default'   => '#004e9a'
			]
		);

		$this->end_controls_section();

	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();
		$item_col = $settings['desktop_col'] . ' '. $settings['ipad_pro'] . ' '. $settings['tab_col'];
		$count_id = rand(100, 10000);
		?>

        <div id="count-id-<?php echo $count_id;?>"  class="td-circle-progress-wrapper">
            <div class="row">
				<?php
				if ($settings['progress_bars']) {
					$bar_number = 0;
					foreach ($settings['progress_bars'] as $bar) {
						$bar_number++;
						if($bar['box_animation']){
							$box_animation = 'wow'.' ' . $bar['box_animation'];
							$box_animation_duration = $bar['box_animation_duration'];
							$box_animation_delay = ' data-wow-delay="'.$bar['box_animation_delay'].'ms"';
						}else{
							$box_animation ='';
							$box_animation_duration ='';
							$box_animation_delay ='';
						}

						if($bar['number'] == 100){
						    $output_number = 1;
                        }else if($bar['number'] < 10){
							$output_number = '.0'.$bar['number'];
                        }else{
							$output_number = '.'.$bar['number'];
						}
						?>

                        <div class="<?php echo $item_col;?>">
                            <div class="td-single-circle-progress <?php if($bar['border'] == 'yes'){ echo 'td-border';}?> <?php echo $box_animation;?>" <?php echo $box_animation_duration . $box_animation_delay;?>>
                                <div class="td-circle-progress-item">
                                    <div class="td-circle-progress-box">
                                        <div id="bar-<?php echo $count_id.$bar_number;?>"></div>
                                        <div class="td-count-number-unit">
                                            <span class="td-count-number"><?php echo $bar['number'];?></span>
                                            <span><?php echo $bar['unit'];?></span>
                                        </div>
                                    </div>
                                    <p class="td-bar-title"><?php echo $bar['title'];?></p>
                                </div>

                                <script>
                                    (function ($) {
                                        "use strict";
                                        jQuery(document).ready(function ($) {
                                            $('#bar-<?php echo $count_id.$bar_number;?>').circleProgress({
                                                value: "<?php echo $output_number;?>",
                                                size: 170,
                                                lineCap: "round",
                                                emptyFill: "<?php echo $settings['background_color'];?>",
                                                thickness: "10",
                                                fill: {
                                                    gradient: ["<?php echo $settings['fill_color_1'];?>", "<?php echo $settings['fill_color_2'];?>"]
                                                }
                                            });
                                        });
                                    }(jQuery));
                                </script>
                            </div>
                        </div>
					<?php }
				}
				?>
            </div>
        </div>

        <script>
            (function ($) {
                "use strict";
                jQuery(document).ready(function($){
                    $("#count-id-<?php echo $count_id;?> .td-count-number").counterUp({
                        delay: 10,
                        time: 2000
                    });
                });
            }(jQuery));
        </script>

		<?php

	}

}

Plugin::instance()->widgets_manager->register( new ThemeDraft_Circle_Progress_Bar_Widget );