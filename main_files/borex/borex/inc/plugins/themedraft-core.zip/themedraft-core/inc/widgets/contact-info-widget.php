<?php
class Themedraft_Contact_Info_Widget extends WP_Widget{
	public function __construct(){

		parent::__construct('themedraft_contact_info_widget', esc_html__('ThemeDraft : Contact Info', 'themedraft-core'), array(
			'description'   =>  esc_html__('ThemeDraft contact info widget', 'themedraft-core'),
		));
	}


	public function widget($args, $instance){
		echo wp_kses_post( $args['before_widget'] );

		if(!empty($instance['title'])){
			echo  wp_kses_post( $args['before_title'] ).apply_filters('widget_title', esc_html($instance['title'])).wp_kses_post( $args['after_title'] );
		};?>

		<?php if(!empty($instance['short_desc'])){ ?>
            <div class="widget-short-desc">
                <div class="widget-short-dsc">
					<?php echo wpautop(esc_html($instance['short_desc']));?>
                </div>
            </div>
		<?php }?>

        <ul class="td-list-style widget-contact-info-list">
			<?php if(!empty($instance['address_desc'])){ ?>
                <li class="widget-address-desc">
                    <i class="fas fa-map-marker-alt"></i>
                    <div class="widget-addr-dsc">
						<?php echo wpautop(esc_html($instance['address_desc']));?>
                    </div>
                </li>
			<?php } ?>

			<?php if(!empty($instance['mobile'])){ ?>
                <li><a href="tel:<?php echo esc_html($instance['mobile']);?>"><i class="fas fa-mobile-alt"></i><?php echo esc_html($instance['mobile']);?></a></li>
			<?php } ?>

			<?php if(!empty($instance['email'])){ ?>
                <li><a href="mailto:<?php echo esc_html($instance['email']);?>"><i class="fas fa-paper-plane"></i><?php echo esc_html($instance['email']);?></a></li>
			<?php } ?>

			<?php if(!empty($instance['fax'])){ ?>
                <li><a href="fax:<?php echo esc_html($instance['fax']);?>"><i class="fas fa-fax"></i><?php echo esc_html($instance['fax']);?></a></li>
			<?php } ?>
        </ul>

		<?php

		echo wp_kses_post( $args['after_widget'] );
	}

	public function form($instance){
		$title = ! empty($instance['title']) ? $instance['title'] : '';

		$short_description = ! empty($instance['short_desc']) ? $instance['short_desc'] : '';
		$address_description = ! empty($instance['address_desc']) ? $instance['address_desc'] : '';
		$mobile = ! empty($instance['mobile']) ? $instance['mobile'] : '';

		$email = ! empty($instance['email']) ? $instance['email'] : '';
		$fax = ! empty($instance['fax']) ? $instance['fax'] : '';
		?>

        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title'));?>"> <?php echo esc_html__( 'Title', 'themedraft-core' );?></label>

            <input id="<?php echo esc_attr($this->get_field_id('title'));?>" class="widefat" type="text" name="<?php echo esc_attr($this->get_field_name('title'));?>" value="<?php echo esc_attr($title); ?>">
        </p>

        <p>
            <label for="<?php echo esc_attr($this->get_field_id('short_desc'));?>"> <?php echo esc_html__( 'Short Description', 'themedraft-core' );?></label>

            <textarea  cols="30" rows="3" id="<?php echo esc_attr($this->get_field_id('short_desc'));?>" class="widefat" type="textarea" name="<?php echo esc_attr($this->get_field_name('short_desc'));?>"><?php echo esc_html($short_description); ?></textarea>
        </p>

        <p>
            <label for="<?php echo esc_attr($this->get_field_id('address_desc'));?>"> <?php echo esc_html__( 'Location Description', 'themedraft-core' );?></label>

            <textarea  cols="30" rows="3" id="<?php echo esc_attr($this->get_field_id('address_desc'));?>" class="widefat" type="textarea" name="<?php echo esc_attr($this->get_field_name('address_desc'));?>"><?php echo esc_html($address_description); ?></textarea>
        </p>

        <p>
            <label for="<?php echo esc_attr($this->get_field_id('mobile'));?>"> <?php echo esc_html__( 'Mobile', 'themedraft-core' );?></label>

            <input id="<?php echo esc_attr($this->get_field_id('mobile'));?>" class="widefat" type="text" name="<?php echo esc_attr($this->get_field_name('mobile'));?>" value="<?php echo esc_attr($mobile); ?>">
        </p>

        <p>
            <label for="<?php echo esc_attr($this->get_field_id('email'));?>"> <?php echo esc_html__( 'Email', 'themedraft-core' );?></label>

            <input id="<?php echo esc_attr($this->get_field_id('email'));?>" class="widefat" type="text" name="<?php echo esc_attr($this->get_field_name('email'));?>" value="<?php echo esc_attr($email); ?>">
        </p>

        <p>
            <label for="<?php echo esc_attr($this->get_field_id('fax'));?>"> <?php echo esc_html__( 'Fax', 'themedraft-core' );?></label>

            <input id="<?php echo esc_attr($this->get_field_id('fax'));?>" class="widefat" type="text" name="<?php echo esc_attr($this->get_field_name('fax'));?>" value="<?php echo esc_attr($fax); ?>">
        </p>

	<?php }

	public function update( $new_instance, $old_instance ){
		$instance                  = $old_instance;

		$instance['title']         = ( ! empty( $new_instance['title'] ) ) ? sanitize_text_field( $new_instance['title'] ) : '';
		$instance['short_desc']         = ( ! empty( $new_instance['short_desc'] ) ) ? wp_kses_post( $new_instance['short_desc'] ) : '';
		$instance['address_desc']         = ( ! empty( $new_instance['address_desc'] ) ) ? wp_kses_post( $new_instance['address_desc'] ) : '';

		$instance['mobile']         = ( ! empty( $new_instance['mobile'] ) ) ? sanitize_text_field( $new_instance['mobile'] ) : '';

		$instance['email']         = ( ! empty( $new_instance['email'] ) ) ? sanitize_text_field( $new_instance['email'] ) : '';

		$instance['fax']         = ( ! empty( $new_instance['fax'] ) ) ? sanitize_text_field( $new_instance['fax'] ) : '';
		return $instance;
	}
}

function themedraft_init_mailchimp_widget(){
	register_widget('Themedraft_Contact_Info_Widget');
}

add_action('widgets_init', 'themedraft_init_mailchimp_widget');