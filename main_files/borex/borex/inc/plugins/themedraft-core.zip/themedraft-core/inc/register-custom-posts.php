<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
function themedraft_register_custom_posts() {

	// Services
	register_post_type( 'borex_service',
		array(
			'labels'       => array(
				'name'                  => __( 'Services', 'themedraft-core' ),
				'singular_name'         => __( 'Service', 'themedraft-core' ),
				'add_new_item'          => __( 'Add New Service', 'themedraft-core' ),
				'all_items'             => __( 'All Services', 'themedraft-core' ),
				'add_new'               => __( 'Add New', 'themedraft-core' ),
				'edit_item'             => __( 'Edit Service', 'themedraft-core' ),
				'featured_image'        => __( 'Service Image', 'themedraft-core' ),
				'set_featured_image'    => __( 'Set Service Image', 'themedraft-core' ),
				'remove_featured_image' => __( 'Remove Service Image', 'themedraft-core' ),
				'use_featured_image'    => __( 'Use as services image', 'themedraft-core' ),
			),
			'rewrite'      => array(
				'slug'       => 'service',
				'with_front' => true
			),
			'hierarchical' => true,
			'public'       => true,
			'menu_icon'    => 'dashicons-schedule',
			'supports'     => array( 'title', 'editor', 'thumbnail', 'page-attributes' ),
		)
	);

	register_taxonomy(
		'borex_service_cat',
		'borex_service',
		array(
			'hierarchical'      => true,
			'label'             => __( 'Service Categories', 'themedraft-core' ),
			'query_var'         => true,
			'show_admin_column' => true,
			'rewrite'           => array(
				'slug'       => 'service-category',
				'with_front' => true
			)
		)
	);

	register_taxonomy(
		'borex_service_tag',
		'borex_service',
		array(
		'hierarchical'          => false,
		'label'                 => __( 'Service Tags', 'themedraft-core' ),
		'show_ui'               => true,
		'show_admin_column'          => true,
		'query_var'             => true,
		'rewrite'               => array(
			'slug'       => 'service-tag',
			'with_front' => true,
		),
	) );


	//Team Members
	register_post_type('borex_team',
		array(
			'labels'       => array(
				'name'                  => __('Team Members', 'themedraft-core'),
				'singular_name'         => __('Team Member', 'themedraft-core'),
				'add_new_item'          => __('Add New Member', 'themedraft-core'),
				'all_items'             => __('All Members', 'themedraft-core'),
				'add_new'               => __('Add New', 'themedraft-core'),
				'edit_item'             => __('Edit Member', 'themedraft-core'),
				'featured_image'        => __('Member Image', 'themedraft-core'),
				'set_featured_image'    => __('Set member image', 'themedraft-core'),
				'remove_featured_image' => __('Remove member image', 'themedraft-core'),
				'use_featured_image'    => __('Use as member image', 'themedraft-core'),
			),
			'rewrite'      => array(
				'slug'       => 'team',
				'with_front' => true
			),
			'hierarchical' => true,
			'public'       => true,
			'menu_icon'    => 'dashicons-businessman',
			'supports'     => array('title', 'editor', 'thumbnail', 'page-attributes'),
		)
	);

	register_taxonomy(
		'borex_team_cat',
		'borex_team',
		array(
			'hierarchical'      => true,
			'label'             => __('Team Categories', 'themedraft-core'),
			'query_var'         => true,
			'show_admin_column' => true,
			'rewrite'           => array(
				'slug'       => 'team-category',
				'with_front' => true
			)
		)
	);

	register_taxonomy(
		'borex_team_tag',
		'borex_team',
		array(
			'hierarchical'          => false,
			'label'                 => __( 'Team Tags', 'themedraft-core' ),
			'show_ui'               => true,
			'show_admin_column'          => true,
			'query_var'             => true,
			'rewrite'               => array(
				'slug'       => 'team-tag',
				'with_front' => true,
			),
		)
	);

	// Project
	register_post_type( 'borex_project',
		array(
			'labels'       => array(
				'name'                  => __( 'Projects', 'themedraft-core' ),
				'singular_name'         => __( 'Project', 'themedraft-core' ),
				'add_new_item'          => __( 'Add New Project', 'themedraft-core' ),
				'all_items'             => __( 'All Projects', 'themedraft-core' ),
				'add_new'               => __( 'Add New', 'themedraft-core' ),
				'edit_item'             => __( 'Edit Project', 'themedraft-core' ),
				'featured_image'        => __( 'Project Image', 'themedraft-core' ),
				'set_featured_image'    => __( 'Set Project Image', 'themedraft-core' ),
				'remove_featured_image' => __( 'Remove Project Image', 'themedraft-core' ),
				'use_featured_image'    => __( 'Use as project image', 'themedraft-core' ),
			),
			'rewrite'      => array(
				'slug'       => 'project',
				'with_front' => true
			),
			'hierarchical' => true,
			'public'       => true,
			'menu_icon'    => 'dashicons-schedule',
			'supports'     => array( 'title', 'editor', 'thumbnail', 'page-attributes' ),
		)
	);

	register_taxonomy(
		'borex_project_cat',
		'borex_project',
		array(
			'hierarchical'      => true,
			'label'             => __( 'Project Categories', 'themedraft-core' ),
			'query_var'         => true,
			'show_admin_column' => true,
			'rewrite'           => array(
				'slug'       => 'project-category',
				'with_front' => true
			)
		)
	);

	register_taxonomy(
		'borex_project_tag',
		'borex_project',
		array(
			'hierarchical'          => false,
			'label'                 => __( 'Project Tags', 'themedraft-core' ),
			'show_ui'               => true,
			'show_admin_column'          => true,
			'query_var'             => true,
			'rewrite'               => array(
				'slug'       => 'project-tag',
				'with_front' => true,
			),
		)
	);
}

add_action( 'init', 'themedraft_register_custom_posts' );