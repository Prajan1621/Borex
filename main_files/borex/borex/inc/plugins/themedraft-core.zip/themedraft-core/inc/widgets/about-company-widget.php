<?php

class Themedraft_About_Company_Widget extends WP_Widget {
	public function __construct() {

		parent::__construct( 'themedraft_about_company_widget', esc_html__( 'ThemeDraft : About Company', 'themedraft-core' ), array(
			'description' => esc_html__( 'ThemeDraft about company widget.', 'themedraft-core' ),
		) );
	}

	public function widget( $args, $instance ) {

		$display_image = false;
		if ( ! empty( $instance['image'] ) ) {
			$display_image = 1;
			$image_src     = wp_get_attachment_image_src( $instance['image'], "full" );
		}

		echo wp_kses_post( $args['before_widget'] );

		if ( ! empty( $instance['title'] ) ) {
			echo wp_kses_post( $args['before_title'] ) . apply_filters( 'widget_title', esc_html( $instance['title'] ) ) . wp_kses_post( $args['after_title'] );
		}; ?>

        <?php

		if ( is_page() || is_singular( 'post' ) || borex_custom_post_types() && get_post_meta( get_the_ID(), 'borex_common_meta', true ) ) {
			$common_meta = get_post_meta( get_the_ID(), 'borex_common_meta', true );
		} else {
			$common_meta = array();
		}

		if (is_array($common_meta) && array_key_exists('footer_logo_meta', $common_meta) && !empty($common_meta['footer_logo_meta']['url'])) {
			$footer_logo_img = $common_meta['footer_logo_meta']; ?>
            <div class="about-info-img">

				<?php if ( $instance['image_url'] ) { ?>
                    <a href='<?php echo esc_url( $instance['image_url'] ); ?>'><img
                                src="<?php echo esc_url($footer_logo_img['url']); ?>"
                                alt="<?php echo esc_attr( get_post_meta( $footer_logo_img['id'], '_wp_attachment_image_alt', true )); ?>"></a>
				<?php } else { ?>

                    <img src="<?php echo esc_url($footer_logo_img['url']); ?>"
                         alt="<?php echo esc_attr( get_post_meta( $footer_logo_img['id'], '_wp_attachment_image_alt', true )); ?>">
				<?php } ?>

            </div>
            <?php
		} else  {
			 if ( $display_image ) { ?>
                <div class="about-info-img">

					<?php if ( $instance['image_url'] ) { ?>
                        <a href='<?php echo esc_url( $instance['image_url'] ); ?>'><img
                                    src="<?php echo esc_url( $image_src[0] ); ?>"
                                    alt="<?php echo get_post_meta( borex_image_id_by_url( $image_src[0] ), '_wp_attachment_image_alt', true ); ?>"></a>
					<?php } else { ?>

                        <img src="<?php echo esc_url( $image_src[0] ); ?>"
                             alt="<?php echo get_post_meta( borex_image_id_by_url( $image_src[0] ), '_wp_attachment_image_alt', true ); ?>">
					<?php } ?>

                </div>
			<?php }
		}
        ?>


		<?php if ( ! empty( $instance['footer_desc'] ) ) { ?>

            <div class="widget-about-description">
				<?php echo wpautop( esc_html( $instance['footer_desc'] ) ); ?>
            </div>

		<?php } ?>

        <ul class="widget-social-icons footer-social-icon td-list-inline">
			<?php
			if(!empty($instance['facebook'])){ ?>
                <li><a class="facebook" href="<?php echo esc_url( $instance['facebook'] ); ?>" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
			<?php }
			?>

			<?php
			if(!empty($instance['twitter'])){ ?>
                <li><a class="twitter" href="<?php echo esc_url( $instance['twitter'] ); ?>" target="_blank"><i class="fab fa-twitter"></i></a></li>
			<?php }
			?>

			<?php
			if(!empty($instance['linkedin'])){ ?>
                <li><a class="linkedin" href="<?php echo esc_url( $instance['linkedin'] ); ?>" target="_blank"><i class="fab fa-linkedin-in"></i></a></li>
			<?php }
			?>

			<?php
			if(!empty($instance['pinterest'])){ ?>
                <li><a class="pinterest" href="<?php echo esc_url( $instance['pinterest'] ); ?>" target="_blank"><i class="fab fa-pinterest-p"></i></a></li>
			<?php }
			?>

			<?php
			if(!empty($instance['instagram'])){ ?>
                <li><a class="instagram" href="<?php echo esc_url( $instance['instagram'] ); ?>" target="_blank"><i class="fab  fa-instagram"></i></a></li>
			<?php }
			?>
        </ul>

		<?php echo wp_kses_post( $args['after_widget'] );
	}


	public function form( $instance ) {

		$title = ! empty( $instance['title'] ) ? $instance['title'] : '';


		$image = ! empty( $instance['image'] ) ? $instance['image'] : '';

		$imageUrl = ! empty( $instance['image_url'] ) ? $instance['image_url'] : '';

		$short_desc = ! empty( $instance['footer_desc'] ) ? $instance['footer_desc'] : '';

		$facebook_url = ! empty($instance['facebook']) ? $instance['facebook'] : '';

		$twitter_url = ! empty($instance['twitter']) ? $instance['twitter'] : '';

		$linkedin_url = ! empty($instance['linkedin']) ? $instance['linkedin'] : '';

		$pinterest_url = ! empty($instance['pinterest']) ? $instance['pinterest'] : '';

		$instagram_url = ! empty($instance['instagram']) ? $instance['instagram'] : '';
		?>


        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"> <?php echo esc_html__( 'Title', 'themedraft-core' ); ?></label>

            <input id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" class="widefat" type="text"
                   name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>"
                   value="<?php echo esc_attr( $title ); ?>">
        </p>


        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'image' ) ); ?>"><?php _e( 'Image:', 'themedraft-core' ); ?></label>
            <br>
            <span class="imgpreview"></span>
        <input class="imgph" type="hidden" id="<?php echo esc_attr( $this->get_field_id( 'image' ) ); ?>"
               name="<?php echo esc_attr( $this->get_field_name( 'image' ) ); ?>"
               value="<?php echo esc_attr( $image ); ?>"/>
        <input type="button" class="button btn-primary widgetuploader"
               value="<?php _e( 'Add Image', 'themedraft-core' ); ?>"/>
        </p>


        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'image_url' ) ); ?>"> <?php echo esc_html__( 'Image Url', 'themedraft-core' ); ?></label>

            <input id="<?php echo esc_attr( $this->get_field_id( 'image_url' ) ); ?>" class="widefat" type="text"
                   name="<?php echo esc_attr( $this->get_field_name( 'image_url' ) ); ?>"
                   value="<?php echo esc_url( $imageUrl ); ?>">
        </p>


        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'footer_desc' ) ); ?>"> <?php echo esc_html__( 'Short Description', 'themedraft-core' ); ?></label>

            <textarea cols="30" rows="3" id="<?php echo esc_attr( $this->get_field_id( 'footer_desc' ) ); ?>"
                      class="widefat" type="textarea"
                      name="<?php echo esc_attr( $this->get_field_name( 'footer_desc' ) ); ?>"><?php echo esc_html( $short_desc ); ?></textarea>
        </p>

        <p>
            <label for="<?php echo esc_attr($this->get_field_id('facebook'));?>"> <?php echo esc_html__( 'Facebook URL', 'themedraft-core' );?></label>

            <input id="<?php echo esc_attr($this->get_field_id('facebook'));?>" class="widefat" type="text" name="<?php echo esc_attr($this->get_field_name('facebook'));?>" value="<?php echo esc_url($facebook_url); ?>">
        </p>

        <p>
            <label for="<?php echo esc_attr($this->get_field_id('twitter'));?>"> <?php echo esc_html__( 'Twitter URL', 'themedraft-core' );?></label>

            <input id="<?php echo esc_attr($this->get_field_id('twitter'));?>" class="widefat" type="text" name="<?php echo esc_attr($this->get_field_name('twitter'));?>" value="<?php echo esc_url($twitter_url); ?>">
        </p>

        <p>
            <label for="<?php echo esc_attr($this->get_field_id('linkedin'));?>"> <?php echo esc_html__( 'Linkedin URL', 'themedraft-core' );?></label>

            <input id="<?php echo esc_attr($this->get_field_id('linkedin'));?>" class="widefat" type="text" name="<?php echo esc_attr($this->get_field_name('linkedin'));?>" value="<?php echo esc_url($linkedin_url); ?>">
        </p>

        <p>
            <label for="<?php echo esc_attr($this->get_field_id('pinterest'));?>"> <?php echo esc_html__( 'Pinterest URL', 'themedraft-core' );?></label>

            <input id="<?php echo esc_attr($this->get_field_id('pinterest'));?>" class="widefat" type="text" name="<?php echo esc_attr($this->get_field_name('pinterest'));?>" value="<?php echo esc_url($pinterest_url); ?>">
        </p>

        <p>
            <label for="<?php echo esc_attr($this->get_field_id('instagram'));?>"> <?php echo esc_html__( 'Instagram URL', 'themedraft-core' );?></label>

            <input id="<?php echo esc_attr($this->get_field_id('instagram'));?>" class="widefat" type="text" name="<?php echo esc_attr($this->get_field_name('instagram'));?>" value="<?php echo esc_url($instagram_url); ?>">
        </p>

	<?php }


	public function update( $new_instance, $old_instance ) {
		$instance = $old_instance;

		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? sanitize_text_field( $new_instance['title'] ) : '';

		$instance['image'] = ( ! empty( $new_instance['image'] ) ) ? sanitize_text_field( $new_instance['image'] ) : '';

		$instance['image_url'] = ( ! empty( $new_instance['image_url'] ) ) ? sanitize_text_field( $new_instance['image_url'] ) : '';

		$instance['footer_desc'] = ( ! empty( $new_instance['footer_desc'] ) ) ? wp_kses_post( $new_instance['footer_desc'] ) : '';

		$instance['facebook']      = ( ! empty( $new_instance['facebook'] ) ) ? sanitize_text_field( $new_instance['facebook'] ) : '';

		$instance['twitter']       = ( ! empty( $new_instance['twitter'] ) ) ? sanitize_text_field( $new_instance['twitter'] ) : '';

		$instance['linkedin']      = ( ! empty( $new_instance['linkedin'] ) ) ? sanitize_text_field( $new_instance['linkedin'] ) : '';

		$instance['pinterest']     = ( ! empty( $new_instance['pinterest'] ) ) ? sanitize_text_field( $new_instance['pinterest'] ) : '';

		$instance['instagram']     = ( ! empty( $new_instance['instagram'] ) ) ? sanitize_text_field( $new_instance['instagram'] ) : '';

		return $instance;
	}
}


function themedraft_about_company_widget() {
	register_widget( 'Themedraft_About_Company_Widget' );
}

add_action( 'widgets_init', 'themedraft_about_company_widget' );