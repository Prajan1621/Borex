<?php

class Themedraft_Cta_Button_Widget extends WP_Widget {
	public function __construct() {

		parent::__construct( 'themedraft_cta_button_widget', esc_html__( 'ThemeDraft : CTA Button', 'themedraft-core' ), array(
			'description' => esc_html__( 'ThemeDraft CTA button widget.', 'themedraft-core' ),
		) );
	}

	public function widget( $args, $instance ) {
		$display_image = false;
		if ( ! empty( $instance['image'] ) ) {
			$display_image = 1;
			$image_src     = wp_get_attachment_image_src( $instance['image'], "full" );
		}

		echo wp_kses_post( $args['before_widget'] );

		if ( ! empty( $instance['title'] ) ) {
			echo wp_kses_post( $args['before_title'] ) . apply_filters( 'widget_title', esc_html( $instance['title'] ) ) . wp_kses_post( $args['after_title'] );
		}; ?>


		<div class="cta-widget-wrapper">
			<div class="cta-widget-content td-cover-bg" <?php if($display_image) : ?> style="background-image: url('<?php echo esc_url( $image_src[0] ); ?>')" <?php endif;?>>

				<?php if ( ! empty( $instance['cta_title'] ) ) { ?>

					<h3 class="cta-title">
						<?php echo esc_html( $instance['cta_title'] ); ?>
					</h3>

				<?php } ?>

				<?php if ( ! empty( $instance['mobile_number'] ) ) { ?>

                <a href="tel:<?php echo $instance['mobile_number'];?>" class="cta-widget-button"><i class="fas fa-phone-volume"></i></a>
                    <div></div>
					<a href="tel:<?php echo $instance['mobile_number'];?>" class="cta-widget-number"><?php echo $instance['mobile_number'];?></a>
				<?php } ?>
			</div>
		</div>

		<?php echo wp_kses_post( $args['after_widget'] );
	}


	public function form( $instance ) {

		$title = ! empty( $instance['title'] ) ? $instance['title'] : '';


		$image = ! empty( $instance['image'] ) ? $instance['image'] : '';

		$cta_title = ! empty( $instance['cta_title'] ) ? $instance['cta_title'] : '';

		$mobile_number = ! empty( $instance['mobile_number'] ) ? $instance['mobile_number'] : '';
		?>


		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"> <?php echo esc_html__( 'Title', 'themedraft-core' ); ?></label>

			<input id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" class="widefat" type="text"
			       name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>"
			       value="<?php echo esc_attr( $title ); ?>">
		</p>


		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'image' ) ); ?>"><?php _e( 'Image:', 'themedraft-core' ); ?></label>
			<br>
			<span class="imgpreview"></span>
			<input class="imgph" type="hidden" id="<?php echo esc_attr( $this->get_field_id( 'image' ) ); ?>"
			       name="<?php echo esc_attr( $this->get_field_name( 'image' ) ); ?>"
			       value="<?php echo esc_attr( $image ); ?>"/>
			<input type="button" class="button btn-primary widgetuploader"
			       value="<?php _e( 'Add Image', 'themedraft-core' ); ?>"/>
		</p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'cta_title' ) ); ?>"> <?php echo esc_html__( 'CTA Title', 'themedraft-core' ); ?></label>

			<textarea cols="30" rows="3" id="<?php echo esc_attr( $this->get_field_id( 'cta_title' ) ); ?>"
			          class="widefat" type="textarea"
			          name="<?php echo esc_attr( $this->get_field_name( 'cta_title' ) ); ?>"><?php echo esc_html( $cta_title ); ?></textarea>
		</p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'mobile_number' ) ); ?>"> <?php echo esc_html__( 'Mobile Number', 'themedraft-core' ); ?></label>

			<input id="<?php echo esc_attr( $this->get_field_id( 'mobile_number' ) ); ?>" class="widefat" type="text"
			       name="<?php echo esc_attr( $this->get_field_name( 'mobile_number' ) ); ?>"
			       value="<?php echo esc_attr( $mobile_number ); ?>">
		</p>
	<?php }


	public function update( $new_instance, $old_instance ) {
		$instance = $old_instance;

		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? sanitize_text_field( $new_instance['title'] ) : '';

		$instance['image'] = ( ! empty( $new_instance['image'] ) ) ? sanitize_text_field( $new_instance['image'] ) : '';

		$instance['cta_title'] = ( ! empty( $new_instance['cta_title'] ) ) ? sanitize_text_field( $new_instance['cta_title'] ) : '';

		$instance['mobile_number'] = ( ! empty( $new_instance['mobile_number'] ) ) ? wp_kses_post( $new_instance['mobile_number'] ) : '';

		return $instance;
	}
}


function themedraft_init_cta_button_widget() {
	register_widget( 'Themedraft_Cta_Button_Widget' );
}

add_action( 'widgets_init', 'themedraft_init_cta_button_widget' );