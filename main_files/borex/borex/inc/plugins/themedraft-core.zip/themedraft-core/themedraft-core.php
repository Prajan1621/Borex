<?php
/*
Plugin Name: ThemeDraft Core
Author: ThemeDraft
Author URI: https://themedraft.net/
Version: 1.1.3
Description: This plugin is required for borex WordPress theme
Text Domain: themedraft-core
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

define( 'THEMEDRAFT_CORE_VERSION', '1.1.3' );

define( 'THEMEDRAFT_CORE', WP_PLUGIN_URL . '/' . plugin_basename( dirname( __FILE__ ) ) .'/');

define( 'THEMEDRAFT_CORE_ELEMENTOR_ASSETS', trailingslashit( THEMEDRAFT_CORE . 'elementor-widgets/assets' ) );


/*
 * Translate direction
 */
load_plugin_textdomain( 'themedraft-core', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );


/*
 * ThemeDraft core functions
 */
require_once('inc/themedraft-core-functions.php' );

/*
 * Register Custom Widget
 */
require_once('inc/widgets/wp-custom-widgets.php' );

/*
 * Register Custom Post
 */
require_once('inc/register-custom-posts.php' );

/*
 * Elementor Widgets
 */
require_once('elementor-widgets/custom-elementor-widgets.php' );